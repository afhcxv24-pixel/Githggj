import requests , time , binascii , json , urllib3 , random
from datetime import datetime
from Black import *
from multiprocessing.dummy import Pool as ThreadPool

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Ua():
    TmP = "GarenaMSDK/4.0.13 ({}; {}; {};)"
    return TmP.format(random.choice(["iPhone 13 Pro", "iPhone 14", "iPhone XR", "Galaxy S22", "Note 20", "OnePlus 9", "Mi 11"]) , 
                     random.choice(["iOS 17", "iOS 18", "Android 13", "Android 14"]) , 
                     random.choice(["en-SG", "en-US", "fr-FR", "id-ID", "th-TH", "vi-VN"]))

def xGeT(u, p):
    """الدالة المعدلة لاستخدام UID و PW مباشرة من السكريبت الرئيسي"""
    print(f"جاري توليد التوكن لـ UID: {u}")
    try:
        r = requests.Session().post(
            "https://100067.connect.garena.com/oauth/guest/token/grant",
            headers={
                "Host": "100067.connect.garena.com",
                "User-Agent": Ua(),
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "close"
            },
            data={
                "uid": u,
                "password": p,
                "response_type": "token",
                "client_type": "2",
                "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
                "client_id": "100067"
            },
            verify=False
        )
        
        if r.status_code == 200:
            T = r.json()
            print("تم الحصول على التوكن بنجاح من Garena")
            a, o = T["access_token"], T["open_id"]
            jwt_token = xJwT(a, o)
            if jwt_token:
                print("تم توليد JWT بنجاح")
                return jwt_token
            else:
                print("فشل في توليد JWT")
                return None
        else:
            print(f"خطأ في الاستجابة من Garena: {r.status_code}")
            return None
    except Exception as e:
        print(f"حدث خطأ في xGeT: {str(e)}")
        return None

def xJwT(a, o):
    """دالة توليد JWT باستخدام التوكن المباشر"""
    try:
        dT = bytes.fromhex('1a13323032352d30332d30362030363a32343a3135220966726565206669726528013a07312e3130392e354232416e64726f6964204f532039202f204150492d3238202850492f72656c2e636a772e32303232303531382e313134313333294a0848616e6468656c64520d41542654204d6f62696c6974795a045749464960800a68d00572033234307a2d7838362d3634205353453320535345342e3120535345342e32204156582041565832207c2032343030207c20348001e61e8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e309a012b476f6f676c657c31623833656335362d363635662d343064392d613436372d303637396438623762306231a2010d37342e3230382e3139372e3230aa0102656eb201206332303962666537343263306532613363613339656631313366336663613430ba010134c2010848616e6468656c64ca01104173757320415355535f493030354441ea014063643030633331363466373361393935373964306238363032643932653137636437353863383262306265353239303839376564346638663161353665333937f00101ca020d41542654204d6f62696c697479d2020457494649ca03203161633462383065636630343738613434323033626638666163363132306635e003a28c02e803bdef01f003af13f80392078004e9fa018804a28c029004e9fa019804a28c02b00404c80401d2043d2f646174612f6170702f636f6d2e6474732e667265656669726574682d4a775553566677524542514277456c7045704d3455673d3d2f6c69622f61726de00401ea045f35623839326161616264363838653537316636383830353331313861313632627c2f646174612f6170702f636f6d2e6474732e667265656669726574682d4a775553566677524542514277456c7045704d3455673d3d2f626173652e61706bf00406f804018a050233329a050a32303139313138313035a80503b205094f70656e474c455332b805ff01c00504ca0522450147130554590145045d1009044c5945395b0455040d6c5c515760020e6f010f30e005e6b201ea05093372645f7061727479f2055c4b717348547a4232754c4c5351667a71317453626639565049307555466b683673596b556d7735516a78526230396a35663644366e6177466f367249666a302b57736f725a32655a5737556138444b556f546375626862435651513df805e7e4068806019006019a060134a2060134')
        
        # تحديث البيانات الديناميكية
        dT = dT.replace(b'2025-07-30 14:11:20', str(datetime.now())[:-7].encode())
        dT = dT.replace(b'c621f2d621430dac1a782a0dab64e6c80a974a6bc728cf2e6b1224d186c9b7af', a.encode())
        dT = dT.replace(b'9e71fabf43d88c06b79f548104c7fcb7', o.encode())
        
        PyL = bytes.fromhex(EnC_AEs(dT.hex()))
        r = requests.Session().post(
            "https://loginbp.common.ggbluefox.com/MajorLogin",
            headers={
                "Expect": "100-continue",
                "X-Unity-Version": "2018.4.11f1",
                "X-GA": "v1 1",
                "ReleaseVersion": "OB50",
                "Authorization": "Bearer ",
                "Host": "loginbp.common.ggbluefox.com"
            },
            data=PyL,
            verify=False
        )
        
        if r.status_code == 200:
            response_data = json.loads(DeCode_PackEt(binascii.hexlify(r.content).decode('utf-8')))
            return response_data['8']['data']
        else:
            print(f"خطأ في MajorLogin: {r.status_code}")
            return None
    except Exception as e:
        print(f"حدث خطأ في xJwT: {str(e)}")
        return None