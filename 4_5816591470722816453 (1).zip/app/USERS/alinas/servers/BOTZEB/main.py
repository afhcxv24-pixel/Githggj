import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import os
import sys
import io
import re
import ssl
import json
import html
import time
import gzip
import shutil
import socket
import random
import base64
import zipfile
import logging
import asyncio
import binascii
import threading
import traceback
import http.client
import string
import hmac
import hashlib

from io import BytesIO
from urllib.parse import quote
from typing import Dict, List, Tuple
from datetime import datetime, timedelta, timezone, date
from html import escape
# Third-party
import aiohttp
import psutil
import requests
import telebot
import jwt as pyjwt

from telebot import types, apihelper
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

from requests.exceptions import Timeout, ConnectionError

from dateutil import parser

from Crypto.Cipher import AES
from Crypto.Cipher import AES as _AES

from Crypto.Util.Padding import pad, unpad
from Crypto.Util.Padding import pad as _pad
from Crypto.Util.Padding import unpad as _unpad

from google.protobuf.timestamp_pb2 import Timestamp
from google.protobuf.json_format import MessageToJson
from google.protobuf.message import DecodeError
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

from protobuf_decoder.protobuf_decoder import Parser

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from Crypto.Cipher import AES as _AES
from byte import Encrypt_ID, encrypt_api
from datetime import datetime as _dt2
# =========================
# UTC FUNCTION
# =========================

def utc_now():
    """ترجع الوقت الحالي مع UTC aware"""
    return datetime.now(timezone.utc)


# =========================
# BOT CONFIG
# =========================

BOT_TOKEN = "8704528970:AAGETIZVhK_4VmRJ9k8BBVs5B1Q12LvsqX8"
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")

DEV_ID = 7641872299
OWNER_ID = 8311110459
OWNER_USERNAME = "AlInAs_sAnIlAx"
ADMIN_ID = 8261004918
MAX_ACCOUNTS = 15
MAX_SPAM_PER_DAY = 3
SPAM_COOLDOWN = 24 * 60 * 60  # 24 ساعة بالثواني
CHANNEL_ID = "@x_5_c_h"
# =========================
# FILES
# =========================

ALLOWED_GROUPS_FILE = "allowed_groups.json"
DATA_FILE = "data.json"
NOTE_FILE = "global_note.json"
USERS_FILE = "users.json"
DEVELOPERS_FILE = "developers.json"
GROUPS_FILE = "groups.json"
SETTINGS_FILE = "settings.json"
users_file = "users_file.json"
WELCOME_FILE = "welcome_note.json"
LEFT_FILE = "left.json"
# =========================
# WATERMARK
# =========================

WATERMARK = (
    "<b>Contact Developers:</b>\n"
    "DEV BY ⚙️<a href='https://t.me/xAlInAs_sAnIlAx'>xAlInAs_sAnIlAx</a>"
)


# =========================
# GROUPS + CHANNELS
# =========================

MAIN_GROUP_ID = -1003807969967

CHANNELS = {
    "𝘼𝙇𝙄𝙉𝘼𝙎ㅤㅤ⫹⚝⫺ㅤㅤ𝘽𝙄𝙊": "-1003608252830",
    "𝘼𝙇𝙄𝙉𝘼𝙎ㅤㅤ⫹⚝⫺ㅤㅤ𝘾𝙃𝘼𝙉𝙉𝙀𝙇": "-1003795949425",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦": "-1003975683687",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦 ²": "-1003950521807",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦 ³": "-1003578506259",
}

CHANNEL_URLS = {
    "𝘼𝙇𝙄𝙉𝘼𝙎ㅤㅤ⫹⚝⫺ㅤㅤ𝘽𝙄𝙊": "https://t.me/x_b_i_o",
    "𝘼𝙇𝙄𝙉𝘼𝙎ㅤㅤ⫹⚝⫺ㅤㅤ𝘾𝙃𝘼𝙉𝙉𝙀𝙇": "https://t.me/x_5_c_h",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦": "https://t.me/x_5_2_1",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦 ²": "https://t.me/x_5_2_2",
    "𝗙𝗙 𝗖𝗢𝗠𝗠𝗨𝗡𝗜𝗧𝗬 𝗕𝗬 𝗔𝗟𝗜𝗡𝗔𝗦 ³": "https://t.me/x_5_2_3",
}


# =========================
# API CONFIG
# =========================

EMOTE_ICON_URL = "https://cdn.jsdelivr.net/gh/ShahGCreator/icon@main/PNG/{id}.png"
API_URL = "https://api-info-nrml-alinas.vercel.app/player-info"

JWT_TOKENS = {}
TOKEN_REFRESH_INTERVAL = 29100


# =========================
# JWT SERVERS
# =========================

SERVERS = [
    {
        "name": "serv_1",
        "uid": "4703271957",
        "password": "Alinas2XEDTHBVY",
        "url": "https://api-get-jwt-by-alinas.vercel.app"
    },
    {
        "name": "serv_2",
        "uid": "4703273026",
        "password": "AlinasPCPKUQJBM",
        "url": "https://api-get-jwt-by-alinas.vercel.app"
    },
    {
        "name": "serv_3",
        "uid": "4703273956",
        "password": "AlinasAMEHKSL5A",
        "url": "https://api-get-jwt-by-alinas.vercel.app"
    }
]


# =========================
# LOGIN CONFIG
# =========================

_LK = b'Yg&tc%DEuh6%Zc^8'
_LIV = b'6oyZDr22E3ychjM%'
_LGN = 'https://loginbp.ggpolarbear.com/MajorLogin'
_OB = 'OB53'
_VER = '1.123.1'

_LHD = {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'gzip',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Expect': '100-continue',
    'X-Unity-Version': '2018.4.11f1',
    'X-GA': 'v1 1',
    'ReleaseVersion': _OB,
}


# =========================
# AES CONFIG
# =========================

AES_KEY = bytes([
    89, 103, 38, 116, 99, 37, 68, 69,
    117, 104, 54, 37, 90, 99, 94, 56
])

AES_IV = bytes([
    54, 111, 121, 90, 68, 114, 50, 50,
    69, 51, 121, 99, 104, 106, 77, 37
])


# =========================
# TARGET OWNERS
# =========================

_target_owners = {}
_target_owners_lock = threading.Lock()
spam_usage = {}

# =========================
# DEFAULT SETTINGS
# =========================

DEFAULT_SETTINGS = {
    "maintenance_mode": False,
    "bot_description": (
        "HELLO IN SPAM BOT ALINAS\n\n"
        "TO SPAM ANYONE SEND :\n"
        "++ {uid}\n\n"
        "TO STOP SPAM :\n"
        "-- {uid}"
    ),
    "start_command": "++",
    "stop_command": "--",
    "broadcast_message": "تم ارجاع جميع البوتات للعمل",
    "max_accounts": 341,

    "start_message_template": (
        "SPAM ROOM DONE\n\n"
        "DONE : UNLIMITED\n\n"
        "UID : {uid}\n"
        "NAME : {name}\n"
        "LEVEL : {level}\n"
        "REGION : {region}\n\n"
        "AlInAs"
    ),

    "stop_message_template": (
        "SPAM ROOM STOPED\n\n"
        "UID : {uid}\n"
        "NAME : {name}\n"
        "LEVEL : {level}\n"
        "REGION : {region}\n\n"
        "AlInAs"
    )
}

_settings = {}
_settings_lock = threading.Lock()

_active_count = 0
_active_lock = threading.Lock()
_max_active = 15

_clis = []
_clis_lock = threading.Lock()

SETTINGS_FILE = "settings.json"

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    level=logging.INFO)
logger = logging.getLogger(__name__)


def load_settings():
    global _settings, _max_active

    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)

            # 🔥 safe merge + fallback
            _settings = DEFAULT_SETTINGS.copy()
            _settings.update(loaded)

            print(f"[SETTINGS] Loaded from file: {SETTINGS_FILE}")

        else:
            _settings = DEFAULT_SETTINGS.copy()
            save_settings()
            print(f"[SETTINGS] Created new file: {SETTINGS_FILE}")

        # 🔐 safe int conversion
        try:
            _max_active = int(_settings.get("max_accounts", 15))
        except:
            _max_active = 15

        print(f"[SETTINGS] Max accounts set to: {_max_active}")

    except Exception as e:
        print(f"[SETTINGS ERROR] {e}, using defaults")
        _settings = DEFAULT_SETTINGS.copy()
        _max_active = 15


def save_settings():
    try:
        with _settings_lock:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(_settings, f, indent=2, ensure_ascii=False)

        print("[SETTINGS] Saved to file")
        return True

    except Exception as e:
        print(f"[SETTINGS SAVE ERROR] {e}")
        return False

def update_setting(key, value):
    """Update setting and save to file immediately"""
    global _settings, _max_active
    with _settings_lock:
        _settings[key] = value
        if key == "max_accounts":
            _max_active = value
    save_settings()
    print(f"[SETTINGS] Updated {key} = {value}")

def get_settings():
    """Get current settings"""
    with _settings_lock:
        return _settings.copy()

def ua():
    versions = ['4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
                '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
                '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3']
    models = ['SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 'SM-M215F', 'SM-M325FV',
              'Redmi 9A', 'Redmi 9C', 'POCO M3', 'POCO M4 Pro', 'RMX2185', 'RMX3085',
              'moto g(9) play', 'CPH2239', 'V2027', 'OnePlus Nord', 'ASUS_Z01QD']
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    return f"GarenaMSDK/{random.choice(versions)}({random.choice(models)};Android {random.choice(android_versions)};{random.choice(languages)};{random.choice(countries)};)"

def encAEs(hexStr):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(bytes.fromhex(hexStr), AES.block_size)).hex()

def decAEs(hexStr):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return unpad(cipher.decrypt(bytes.fromhex(hexStr)), AES.block_size).hex()

def encPacket(hexStr, k, iv):
    return AES.new(k, AES.MODE_CBC, iv).encrypt(pad(bytes.fromhex(hexStr), 16)).hex()

def decPacket(hexStr, k, iv):
    return unpad(AES.new(k, AES.MODE_CBC, iv).decrypt(bytes.fromhex(hexStr)), 16).hex()

def encUid(h, tp):
    e, h = [], int(h)
    while h:
        e.append((h & 0x7F) | (0x80 if h > 0x7F else 0))
        h >>= 7
    return bytes(e).hex() if tp == 'Uid' else None

def encVarint(n):
    if n < 0: return b''
    h = []
    while True:
        b = n & 0x7F
        n >>= 7
        if n: b |= 0x80
        h.append(b)
        if not n: break
    return bytes(h)

def decUid(h):
    n = s = 0
    for b in bytes.fromhex(h):
        n |= (b & 0x7F) << s
        if not b & 0x80: break
        s += 7
    return n

def createVarint(field, value):
    return encVarint((field << 3) | 0) + encVarint(value)

def createLength(field, value):
    hdr = encVarint((field << 3) | 2)
    enc = value.encode() if isinstance(value, str) else value
    return hdr + encVarint(len(enc)) + enc

def createProto(fields):
    pkt = bytearray()
    for f, v in fields.items():
        if isinstance(v, dict):
            nested = createProto(v)
            pkt.extend(createLength(f, nested))
        elif isinstance(v, int):
            pkt.extend(createVarint(f, v))
        elif isinstance(v, (str, bytes)):
            pkt.extend(createLength(f, v))
    return pkt

def decodeHex(h):
    r = hex(h)[2:]
    return "0" + r if len(r) == 1 else r

def fixParsed(parsed):
    d = {}
    for r in parsed:
        fd = {'wire_type': r.wire_type}
        if r.wire_type in ("varint", "string", "bytes"):
            fd['data'] = r.data
        elif r.wire_type == 'length_delimited':
            fd['data'] = fixParsed(r.data.results)
        d[r.field] = fd
    return d

def decodePacket(hexInput):
    try:
        parsed = Parser().parse(hexInput)
        return json.dumps(fixParsed(parsed))
    except Exception:
        return None

def xBunner():
    av = ['902000016', '902000031', '902000011', '902000065',
          '902000204', '902000192', '902000191', '902000179',
          '902000133', '902045001', '902038023', '902048004',
          '902039014', '902000063', '902000306', '902047009']
    return int(random.choice(av))

def genPkt(pkt, n, k, iv):
    enc = encPacket(pkt, k, iv)
    l = decodeHex(len(enc) // 2)
    if len(l) == 2: hdr = n + "000000"
    elif len(l) == 3: hdr = n + "00000"
    elif len(l) == 4: hdr = n + "0000"
    elif len(l) == 5: hdr = n + "000"
    else: hdr = n + "000000"
    return bytes.fromhex(hdr + l + enc)

def openRoom(k, iv):
    f = {1: 2, 2: {1: 1, 2: 15, 3: 5, 4: "ALINAS", 5: "1", 6: 12, 7: 1,
                    8: 1, 9: 1, 11: 1, 12: 2, 14: 36981056,
                    15: {1: "IDC3", 2: 126, 3: "ME"},
                    16: "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000f\u000e\u0016\u0019\u001a \u001d",
                    18: 2368584, 27: 1, 34: "\u0000\u0001", 40: "en", 48: 1,
                    49: {1: 21}, 50: {1: 36981056, 2: 2368584, 5: 2}}}
    return genPkt(str(createProto(f).hex()), '0E15', k, iv)

def spmRoom(k, iv, uid):
    f = {1: 22, 2: {1: int(uid)}}
    return genPkt(str(createProto(f).hex()), '0E15', k, iv)

def gAccess(u, p):
    r = requests.post("https://100067.connect.garena.com/oauth/guest/token/grant",
                      headers={"Host": "100067.connect.garena.com", "User-Agent": ua(),
                               "Content-Type": "application/x-www-form-urlencoded",
                               "Accept-Encoding": "gzip, deflate, br", "Connection": "close"},
                      data={"uid": str(u), "password": str(p), "response_type": "token",
                            "client_type": "2",
                            "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
                            "client_id": "100067"},
                      verify=False)
    if r.status_code == 200:
        return r.json()['access_token'], r.json()['open_id']
    return None, None

def majorLogin(pyl):
    ctx = ssl._create_unverified_context()
    # تم تغيير السيرفر إلى loginbp.ggpolarbear.com
    conn = http.client.HTTPSConnection("loginbp.ggpolarbear.com", context=ctx)
    conn.request("POST", "/MajorLogin", body=pyl, headers={
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB53',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Content-Length': str(len(pyl)),
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
        'Host': 'loginbp.ggpolarbear.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip'
    })
    resp = conn.getresponse()
    raw = resp.read()
    if resp.getheader('Content-Encoding') == 'gzip':
        raw = gzip.GzipFile(fileobj=BytesIO(raw)).read()
    conn.close()
    return raw if resp.status in [200, 201] else None
    
def getPorts(tok, pyl):
    r = requests.post('https://clientbp.ggpolarbear.com/GetLoginData',
                      headers={'Expect': '100-continue', 'Authorization': f'Bearer {tok}',
                               'X-Unity-Version': '2018.4.11f1', 'X-GA': 'v1 1',
                               'ReleaseVersion': 'OB53',
                               'Content-Type': 'application/x-www-form-urlencoded',
                               'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
                               'Host': 'clientbp.ggpolarbear.com', 'Connection': 'Keep-Alive',
                               'Accept-Encoding': 'gzip'},
                      data=pyl, verify=False)
    d = json.loads(decodePacket(r.content.hex()))
    a1, a2 = d['32']['data'], d['14']['data']
    return a1[:len(a1)-6], a1[len(a1)-5:], a2[:len(a2)-6], a2[len(a2)-5:]

class _runtime_version:
    class Domain: PUBLIC = 0
    @staticmethod
    def ValidateProtobufRuntimeVersion(*args, **kwargs): return True

_runtime_version.ValidateProtobufRuntimeVersion()
_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x10my_message.proto">\n\tMyMessage\x12\x0f\n\x07\x66ield21\x18\x15 \x01(\x03\x12\x0f\n\x07\x66ield22\x18\x16 \x01(\x0c\x12\x0f\n\x07\x66ield23\x18\x17 \x01(\x0cb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'my_message_pb2', _globals)
MyMessage = _globals['MyMessage']

def getKiv(raw):
    m = MyMessage()
    m.ParseFromString(raw)
    ts = Timestamp()
    ts.FromNanoseconds(m.field21)
    return ts.seconds * 1_000_000_000 + ts.nanos, m.field22, m.field23

def buildAuth(jwtTok, k, iv, ts):
    dec = pyjwt.decode(jwtTok, options={"verify_signature": False})
    enc = hex(dec['account_id'])[2:]
    tsH = decodeHex(ts)
    jH = jwtTok.encode().hex()
    hLen = hex(len(encPacket(jH, k, iv)) // 2)[2:]
    padMap = {9: '0000000', 8: '00000000', 10: '000000', 7: '000000000'}
    pad = padMap.get(len(enc), '00000000')
    return f'0115{pad}{enc}{tsH}00000{hLen}' + encPacket(jH, k, iv)

def login(u, p):
    at, oid = gAccess(u, p)
    if not at: return None
    
    # تم تحديث البيلود بالكامل مع التاريخ الجديد 2026-04-08
    dT = bytes.fromhex('1a13323032362d30342d30382031313a35363a3438220966726565206669726528013a07312e3132332e314232416e64726f6964204f532039202f204150492d3238202850492f72656c2e636a772e32303232303531382e313134313333294a0848616e6468656c64520c4d544e2f537061636574656c5a045749464960800a68d00572033234307a2d7838362d3634205353453320535345342e3120535345342e32204156582041565832207c2032343030207c20348001e61e8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e329a012b476f6f676c657c36323566373136662d393161372d343935622d396631362d303866653964336336353333a2010e3137362e32382e3133392e313835aa01026172b201203433303632343537393364653836646134323561353263616164663231656564ba010134c2010848616e6468656c64ca010d4f6e65506c7573204135303130ea014063363961653230386661643732373338623637346232383437623530613361316466613235643161313966616537343566633736616334613065343134633934f00101ca020c4d544e2f537061636574656cd2020457494649ca03203161633462383065636630343738613434323033626638666163363132306635e003b5ee02e8039a8002f003af13f80384078004a78f028804b5ee029004a78f029804b5ee02b00404c80401d2043d2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f6c69622f61726de00401ea045f65363261623933353464386662356662303831646233333861636233333439317c2f646174612f6170702f636f6d2e6474732e667265656669726574682d66705843537068495636644b43376a4c2d574f7952413d3d2f626173652e61706bf00406f804018a050233329a050a32303139313139303236a80503b205094f70656e474c455332b805ff01c00504e005be7eea05093372645f7061727479f205704b717348543857393347646347335a6f7a454e6646775648746d377171316552554e6149444e67526f626f7a4942744c4f695943633459367a767670634943787a514632734f453463627974774c7334785a62526e70524d706d5752514b6d654f35766373386e51594268777148374bf805e7e4068806019006019a060134a2060134b2062213521146500e590349510e460900115843395f005b510f685b560a6107576d0f0366')
    
    dT = dT.replace(b'2025-11-26 01:51:28', str(datetime.now())[:-7].encode())
    dT = dT.replace(b'c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94', at.encode())
    dT = dT.replace(b'4306245793de86da425a52caadf21eed', oid.encode())
    pyl = bytes.fromhex(encAEs(dT.hex()))
    raw = majorLogin(pyl)
    if not raw: return None
    d = json.loads(decodePacket(raw.hex()))
    jwtTok = d['8']['data']
    ts, k, iv = getKiv(raw)
    ip, port, ip2, port2 = getPorts(jwtTok, pyl)
    auth = buildAuth(jwtTok, k, iv, ts)
    return auth, k, iv, ip, port, ip2, port2

_tasks = {}

def can_add_connection():
    """Check if we can add a new connection"""
    global _active_count
    with _active_lock:
        return _active_count < _max_active

def acquire_connection():
    """Try to acquire a connection slot"""
    global _active_count
    with _active_lock:
        if _active_count < _max_active:
            _active_count += 1
            return True
        return False

def release_connection():
    """Release a connection slot"""
    global _active_count
    with _active_lock:
        if _active_count > 0:
            _active_count -= 1

class Cli:
    def __init__(self, u, p):
        self.u = u
        self.p = p
        self.key = self.iv = None
        self.sock1 = self.sock2 = None
        self.alive = False
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        while True:
            acquired = False
            try:
                while not acquire_connection():
                    time.sleep(5)
                acquired = True

                res = login(self.u, self.p)
                if not res:
                    release_connection()
                    acquired = False
                    time.sleep(10)
                    continue
                auth, k, iv, ip, port, ip2, port2 = res
                self.key, self.iv = k, iv

                self.sock1 = socket.create_connection((ip, int(port)), timeout=30)
                self.sock1.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                self.sock1.send(bytes.fromhex(auth))
                time.sleep(0.3)
                self.sock1.recv(1024)

                self.sock2 = socket.create_connection((ip2, int(port2)), timeout=30)
                self.sock2.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                self.sock2.send(bytes.fromhex(auth))
                time.sleep(0.2)

                self.alive = True
                with _clis_lock:
                    _clis.append(self)
                print(f'[+] {self.u} connected')

                self.sock1.settimeout(30)
                while self.alive:
                    try:
                        data = self.sock1.recv(4096)
                        if not data: break
                    except socket.timeout:
                        continue
                    except:
                        break

            except socket.timeout:
                pass
            except Exception as e:
                print(f'[-] {self.u}: {e}')
            finally:
                self.alive = False
                with _clis_lock:
                    if self in _clis: _clis.remove(self)
                for s in (self.sock1, self.sock2):
                    try:
                        if s: s.close()
                    except: pass
                self.sock1 = self.sock2 = None

                if acquired:
                    release_connection()
                    acquired = False
            time.sleep(5)

def _spamLoop(uid, stop):
    while not stop.is_set():
        with _clis_lock:
            snap = [(c.sock2, c.key, c.iv, c.u) for c in _clis if c.alive and c.sock2 and c.key]
        if not snap:
            stop.wait(1)
            continue
        for s2, k, iv, u in snap:
            if stop.is_set(): break
            try:
                roomPkt = openRoom(k, iv)
                spmPkt = spmRoom(k, iv, uid)
                s2.send(roomPkt)
                for _ in range(5):
                    if stop.is_set(): break
                    s2.send(spmPkt)
                    time.sleep(0.1)
            except:
                pass
        stop.wait(0.5)

def get_player_info(uid):
    try:
        url = f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME"
        response = requests.get(url, timeout=10)

        # 🔐 تحقق من status code
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}")

        # 🔐 حماية JSON parsing
        try:
            data = response.json()
        except Exception:
            data = {}

        if not isinstance(data, dict):
            data = {}

        info = data.get("basicInfo", {}) or {}

        return {
            "name": info.get("nickname") or info.get("name") or "Unknown",
            "uid": str(uid),
            "level": info.get("level") or "N/A",
            "region": info.get("region") or "N/A"
        }

    except Exception as e:
        print("GET PLAYER INFO ERROR:", e)
        return {
            "name": "Unknown",
            "uid": str(uid),
            "level": "N/A",
            "region": "N/A"
        }
        
def format_player_message(uid, action):
    settings = get_settings()
    info = get_player_info(uid) or {}

    # اختيار التمبلات بشكل آمن
    if action == "SPAM ROOM DONE":
        template = settings.get("start_message_template")
    else:
        template = settings.get("stop_message_template")

    if not template:
        return f"{action} -> {uid}"

    try:
        return template.format(
            uid=info.get("uid", uid),
            name=info.get("nickname") or info.get("name", "Unknown"),
            level=info.get("level", "N/A"),
            region=info.get("region", "N/A")
        )

    except Exception as e:
        print("FORMAT ERROR:", e)
        return f"{action} -> {uid}"
        
def add(uid, owner_id, owner_username):
    if uid in _tasks: return False
    with _target_owners_lock:
        _target_owners[uid] = (owner_id, owner_username)
    stop = threading.Event()
    t = threading.Thread(target=_spamLoop, args=(uid, stop), daemon=True)
    t.start()
    _tasks[uid] = (t, stop)
    return True

def remove(uid, requester_id):
    if uid not in _tasks: return False
    with _target_owners_lock:
        owner_id, _ = _target_owners.get(uid, (None, None))
    if requester_id != owner_id and requester_id != DEV_ID:
        return False
    _, stop = _tasks.pop(uid)
    stop.set()
    with _target_owners_lock:
        if uid in _target_owners:
            del _target_owners[uid]
    return True

def active():
    return list(_tasks.keys())

def restart_accounts():
    """Restart all account connections without stopping the bot"""
    global _clis, _active_count

    with _clis_lock:
        for c in _clis[:]:
            c.alive = False
            try:
                if c.sock1: c.sock1.close()
                if c.sock2: c.sock2.close()
            except: pass
        _clis.clear()

    with _active_lock:
        _active_count = 0

    time.sleep(2)

    try:
        with open("accs.json") as f:
            accs = json.load(f)
        max_to_use = min(len(accs), _max_active)
        print(f"[RESTART] Loading {max_to_use} accounts (max: {_max_active})")
        for u, p in list(accs.items())[:max_to_use]:
            Cli(u, p)
            time.sleep(0.5)
        return max_to_use
    except Exception as e:
        print(f"[RESTART ERROR] {e}")
        return 0

def init():
    """Initialize bot on startup"""
    global _max_active

    load_settings()

    try:
        with open("accs.json") as f:
            accs = json.load(f)
        max_to_use = min(len(accs), _max_active)
        print(f"[INIT] Loading {max_to_use} accounts (max: {_max_active}, total in file: {len(accs)})")
        for u, p in list(accs.items())[:max_to_use]:
            Cli(u, p)
            time.sleep(0.5)
    except Exception as e:
        print(f"[INIT ERROR] no accs.json found or error: {e}")

def owner_panel_keyboard():
    kb = types.InlineKeyboardMarkup(row_width=2)
    settings = get_settings()

    maintenance_text = "🔴 STOP BOT" if not settings['maintenance_mode'] else "🟢 START BOT"
    kb.add(types.InlineKeyboardButton(maintenance_text, callback_data="toggle_maintenance"))
    kb.add(types.InlineKeyboardButton("✏️ Edit Description", callback_data="edit_desc"))
    kb.add(types.InlineKeyboardButton("📢 Broadcast", callback_data="broadcast"))
    kb.add(types.InlineKeyboardButton("⚙️ Change Commands", callback_data="change_cmds"))
    kb.add(types.InlineKeyboardButton("👥 Max Accounts", callback_data="max_accounts"))
    kb.add(types.InlineKeyboardButton("🔄 Restart Accs", callback_data="restart_accounts"))
    kb.add(types.InlineKeyboardButton("📊 Bot Status", callback_data="bot_status"))
    kb.add(types.InlineKeyboardButton("💬 Edit Messages", callback_data="edit_messages"))
    kb.add(types.InlineKeyboardButton("❌ Close Panel", callback_data="close_panel"))
    return kb

def messages_keyboard():
    """Keyboard for editing message templates"""
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(types.InlineKeyboardButton("🚀 Edit Start Message", callback_data="edit_start_msg"))
    kb.add(types.InlineKeyboardButton("🛑 Edit Stop Message", callback_data="edit_stop_msg"))
    kb.add(types.InlineKeyboardButton("📋 Preview Messages", callback_data="preview_messages"))
    kb.add(types.InlineKeyboardButton("🔙 Back", callback_data="back_to_panel"))
    return kb

def _vr(n):
    h = []
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        h.append(b)
        if not n: break
    return bytes(h)

def _proto(d):
    r = b''
    for k, v in d.items():
        k = int(k)
        if isinstance(v, int): r += _vr(k<<3) + _vr(v)
        elif isinstance(v, str): ve = v.encode(); r += _vr(k<<3|2) + _vr(len(ve)) + ve
        elif isinstance(v, bytes): r += _vr(k<<3|2) + _vr(len(v)) + v
        elif isinstance(v, dict): n = _proto(v); r += _vr(k<<3|2) + _vr(len(n)) + n
    return r

def _pbR(data):
    out = {}; pos = 0
    def vi():
        nonlocal pos
        x = s = 0
        while pos < len(data):
            b = data[pos]; pos += 1
            x |= (b & 0x7F) << s; s += 7
            if not b & 0x80: break
        return x
    while pos < len(data):
        try:
            tag = data[pos]; pos += 1
            fn = tag >> 3; wt = tag & 7
            if wt == 0: out[fn] = vi()
            elif wt == 2: ln = vi(); out[fn] = data[pos:pos+ln]; pos += ln
            elif wt == 5: out[fn] = data[pos:pos+4]; pos += 4
            elif wt == 1: out[fn] = data[pos:pos+8]; pos += 8
            else: break
        except: break
    return out

def _mkPL(oid, atk):
    return _proto({
        3: str(_dt2.now())[:-7], 4: 'free fire', 5: 1, 7: _VER,
        8: 'Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)',
        9: 'Handheld', 10: 'Verizon', 11: 'WIFI', 12: 1920, 13: 1080,
        14: '280', 15: 'x86-64 SSE3 SSE4.1 SSE4.2 AVX AVX2 | 2400 | 4', 16: 3003,
        17: 'Adreno (TM) 640', 18: 'OpenGL ES 3.2',
        19: 'Google|625f716f-91a7-495b-9f16-08fe9d3c6533',
        20: '176.28.139.185', 21: 'ar', 22: oid, 23: '4', 24: 'Handheld',
        25: {6: 55, 8: 81}, 29: atk, 30: 1, 73: 3, 78: 3, 79: 2,
        81: '64', 93: 'android', 97: 1, 98: 1, 99: '4', 100: '4',
    })

def _getJwt(uid, pw):
    r = requests.post(
        'https://100067.connect.garena.com/oauth/guest/token/grant',
        headers={'User-Agent': _LHD['User-Agent'], 'Content-Type': 'application/x-www-form-urlencoded'},
        data={'uid': uid, 'password': pw, 'response_type': 'token', 'client_type': '2',
              'client_secret': '2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3',
              'client_id': '100067'},
        verify=False, timeout=15)
    if r.status_code != 200: raise Exception(f'OAuth {r.status_code}')
    d = r.json()
    at = d['access_token']; oid = d['open_id']
    enc = _AES.new(_LK, _AES.MODE_CBC, _LIV).encrypt(_pad(_mkPL(oid, at), 16))
    r2 = requests.post(_LGN, data=enc, headers=_LHD, verify=False, timeout=20)
    if r2.status_code != 200: raise Exception(f'MajorLogin {r2.status_code}')
    tok = _pbR(r2.content).get(8, b'')
    if isinstance(tok, bytes): tok = tok.decode()
    if not tok: raise Exception('no jwt')
    return str(tok).strip()

def get_random_emotes():
    return [
        909000063, 909000068, 909000075, 909000081, 909000085, 909000090,
        909000098, 909000145, 909033001, 909035007, 909037011, 909038010,
        909038012, 909039011, 909040010, 909041005, 909042008, 909045001,
        909049010
    ]

try:
    with open("masry.json", "r", encoding="utf-8") as f:
        EMOTES_DATA = json.load(f)
except Exception as e:
    EMOTES_DATA = {}
    print("❌ Failed to load masry.json:", e)
def escape_markdown(text):
    return re.sub(r'([_*[\]()~`>#+-=|{}.!])', r'\\\1', text)

def h(text):
    return html.escape(str(text))

def format_time(timestamp):

    if not timestamp:
        return "Unknown"

    try:
        ts = int(timestamp)

        if ts > 1e12:  
            ts = ts / 1000
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except:
        return "Unknown"

def send_with_global_note(chat_id, reply_msg, wait_msg_id=None):
    try:
        note = get_global_note()

        if isinstance(note, dict) and note:
            note_type = note.get("type")
            content = note.get("content")

            # حماية من HTML tags غير المدعومة
            safe_content = escape(str(content)) if content else ""

            if note_type == "photo":
                bot.send_photo(
                    chat_id,
                    content,
                    caption=reply_msg,
                    parse_mode="HTML"
                )

            elif note_type == "video":
                bot.send_video(
                    chat_id,
                    content,
                    caption=reply_msg,
                    parse_mode="HTML"
                )

            else:
                bot.send_message(
                    chat_id,
                    f"{reply_msg}\n\n📌 NOTE: {safe_content}",
                    parse_mode="HTML"
                )
        else:
            bot.send_message(
                chat_id,
                reply_msg,
                parse_mode="HTML"
            )

    except Exception as e:
        print("send_with_global_note ERROR:", e)
        try:
            bot.send_message(
                chat_id,
                reply_msg,
                parse_mode="HTML"
            )
        except Exception as e2:
            print("FALLBACK SEND ERROR:", e2)

    if wait_msg_id:
        try:
            bot.delete_message(chat_id, wait_msg_id)
        except Exception as e:
            print("DELETE MESSAGE ERROR:", e)

def load_groups():
    try:
        with open(ALLOWED_GROUPS_FILE, "r") as f:
            return json.load(f).get("groups", {})
    except:
        return {}

def save_groups(groups):
    try:
        with open(ALLOWED_GROUPS_FILE, "w") as f:
            json.dump({"groups": groups}, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"[Error] save_groups: {e}")

def add_group(group_id, days, activated_by):
    groups = load_groups()
    expiry = int(time.time()) + days * 3600 
    groups[str(group_id)] = {"expiry": expiry, "activated_by": activated_by}
    save_groups(groups)
    return expiry

def remove_group(group_id):
    groups = load_groups()
    if str(group_id) in groups:
        del groups[str(group_id)]
        save_groups(groups)
        return True
    return False

def is_group_active(group_id):
    groups = load_groups()
    info = groups.get(str(group_id))
    if not info:
        return False
    if int(time.time()) > info["expiry"]:
        remove_group(group_id)
        return False
    return True

def append_global_note(reply_msg: str) -> str:
    note = get_global_note()
    if note:
        reply_msg += f"\n📝 Note: {note}"
    else:
        reply_msg += "\n📝 Note: No notes available."
    return reply_msg

def save_allowed_groups(data):
    with open(ALLOWED_GROUPS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def escape_md(text: str) -> str:
    if not text:
        return ""
    special_chars = r'_*\[\]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(special_chars)}])', r'\\\1', str(text))

def set_global_note(note_type, content):

    data = {
        "type": note_type,
        "content": content,
    }
    with open(NOTE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)

def get_global_note():
    try:
        with open(NOTE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None

    if not data:
        return None
    return data

def clear_global_note():
    with open(NOTE_FILE, "w", encoding="utf-8") as f:
        json.dump({}, f)
    
def safe_edit_message(bot, call, text, new_markup=None, parse_mode="HTML"):
    try:
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=text,
            reply_markup=new_markup,
            parse_mode=parse_mode
        )

    except telebot.apihelper.ApiTelegramException as e:
        error_text = str(e)

        # 🔴 تجاهل هذا الخطأ لأنه طبيعي
        if "message is not modified" in error_text:
            return

        print(f"[Telegram Error] edit_message failed: {error_text}")

        try:
            bot.reply_to(
                call.message,
                text,
                parse_mode=parse_mode,
                reply_markup=new_markup
            )
        except Exception as e2:
            print(f"[Error] reply_to also failed: {e2}")

    except Exception as e:
        print(f"[Unexpected Error] edit_message failed: {e}")

def check_user_in_channel(user_id, channel_value):
    try:
        if channel_value.startswith("-100"):
            chat_id = int(channel_value)
            member = bot.get_chat_member(chat_id, user_id)
        else:
            username = channel_value if channel_value.startswith("@") else f"@{channel_value}"
            member = bot.get_chat_member(username, user_id)
        return member.status in ["member", "administrator", "creator"]
    except Exception as e:
        print(f"[Error] Checking channel {channel_value}: {e}")
        return False

def check_all_channel_memberships(user_id):
    return {name: check_user_in_channel(user_id, value) for name, value in CHANNELS.items()}

def create_channel_verification_keyboard(missing_channels):
    markup = types.InlineKeyboardMarkup(row_width=1)
    for name in missing_channels:
        url = CHANNEL_URLS.get(name, f"https://t.me/{CHANNELS[name]}")
        markup.add(types.InlineKeyboardButton(text=f" Join {name}", url=url))
    markup.add(types.InlineKeyboardButton(text="✅ I've Joined All Channels", callback_data="verify_channels"))
    return markup

@bot.callback_query_handler(func=lambda call: call.data == "verify_channels")
def handle_channel_verification_callback(call):
    user_id = call.from_user.id
    username = call.from_user.username or call.from_user.first_name
    membership_status = check_all_channel_memberships(user_id)
    missing = [name for name, joined in membership_status.items() if not joined]

    if not missing:
        text = "<b>✅ CHANNEL VERIFICATION COMPLETE!</b>\n\n<b>YOU HAVE JOINED ALL REQUIRED CHANNELS</b>\n<b>YOU CAN NOW USE ALL BOT COMMANDS</b>"
        safe_edit_message(bot, call, text)
        print(f"✅ User {username} ({user_id}) verified successfully")
    else:
        missing_text = "\n".join([f"❌ {name}" for name in missing])
        markup = create_channel_verification_keyboard(missing)
        text = f"<b>⚠️ YOU HAVEN'T JOINED ALL CHANNELS</b>\n\n<b>MISSING CHANNELS:</b>\n{missing_text}\n\n<b>PLEASE JOIN ALL CHANNELS THEN CLICK 'I\'VE JOINED ALL'</b>"
        safe_edit_message(bot, call, text, new_markup=markup)
        print(f"❌ User {username} ({user_id}) still missing: {', '.join(missing)}")

def verify_user_channels(message):
    user_id = message.from_user.id
    membership_status = check_all_channel_memberships(user_id)
    missing = [name for name, joined in membership_status.items() if not joined]
    if not missing:
        return True
    missing_text = "\n".join([f"❌ {name}" for name in missing])
    markup = create_channel_verification_keyboard(missing)
    bot.reply_to(
        message,
        f"<b>🔒 CHANNEL VERIFICATION REQUIRED</b>\n\n<b>TO USE THIS BOT, YOU MUST JOIN ALL CHANNELS:</b>\n\n{missing_text}\n\n<b>AFTER JOINING, CLICK THE BUTTON BELOW:</b>",
        parse_mode="HTML",
        reply_markup=markup
    )
    return False

def require_membership(func):
    def wrapper(message, *args, **kwargs):
        if not verify_user_channels(message):
            return  
        return func(message, *args, **kwargs)
    return wrapper

def load_allowed_groups():
    if not os.path.isfile(ALLOWED_GROUPS_FILE):
        return {}
    with open(ALLOWED_GROUPS_FILE, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

def save_allowed_groups(data):
    with open(ALLOWED_GROUPS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def clean_expired_groups():
    groups = load_allowed_groups()
    now = datetime.now(timezone.utc)
    changed = False
    for chat_id, info in list(groups.items()):
        try:
            if isinstance(info, str):
                expiry = datetime.fromisoformat(info)
            elif isinstance(info, dict) and "expiry" in info:
                expiry = datetime.fromisoformat(info["expiry"])
            else:
                del groups[chat_id]
                changed = True
                continue
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if now > expiry:
                del groups[chat_id]
                changed = True
        except Exception:
            del groups[chat_id]
            changed = True
    if changed:
        save_allowed_groups(groups)
    return groups

def is_allowed(message):
    try:
        user_id = int(message.from_user.id)
        if message.chat.type == 'private':
            return user_id == int(OWNER_ID)
        else:
            groups = clean_expired_groups()
            return str(message.chat.id) in groups
    except Exception as e:
        print(f"[Error] in is_allowed: {e}")
        return False

def process_send(chat_id, message):
    try:
        # 🔐 حماية من أنواع خاطئة
        if isinstance(message, str):
            text = message
        elif hasattr(message, "text"):
            text = message.text
        else:
            text = str(message)

        bot.send_message(int(chat_id), text)

    except telebot.apihelper.ApiTelegramException as e:
        try:
            if e.result_json:
                description = e.result_json.get("description", "")

                if "kicked" in description or "not enough rights" in description:
                    print(f"⚠️ Bot has no rights in group {chat_id}, message skipped")
                else:
                    print("Telegram API error:", description)
                    raise
            else:
                raise

        except Exception as inner:
            print("process_send nested error:", inner)

    except Exception as e:
        print("process_send ERROR:", e)

def load_json(file=None):
    import os

    if file is None:
        file = GROUPS_FILE

    if not os.path.exists(file):
        return {}

    with open(file, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}

def save_json(data, file=None):
    if file is None:
        file = GROUPS_FILE

    with open(file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def add_group(chat_id, days, owner_id):
    data = load_json()
    expiry = int(time.time()) + days * 86400
    data["groups"] = data.get("groups", {})
    data["groups"][str(chat_id)] = {
        "owner": owner_id,
        "expiry": expiry,
        "status": "active"
    }
    save_json(data)
    return expiry

def remove_group(chat_id):
    data = load_json()
    if "groups" in data and str(chat_id) in data["groups"]:
        del data["groups"][str(chat_id)]
        save_json(data)
        return True
    return False

def is_group_active(chat_id):
    data = load_json()
    groups = data.get("groups", {})
    info = groups.get(str(chat_id))
    if not info:
        return False
    if int(time.time()) > info["expiry"]:
        remove_group(chat_id)
        return False
    return True

def fetch_tokens(retry_count=0):
    global JWT_TOKENS
    JWT_TOKENS = {}
    for server in SERVERS:
        uid = server.get("uid", "").strip()
        pw  = server.get("password", "").strip()
        if not uid or not pw:
            continue
        try:
            tok = _getJwt(uid, pw)
            if tok:
                JWT_TOKENS[server["name"]] = tok
                print(f"[+] {server['name']} ready")
        except Exception as e:
            print(f"[-] {server['name']} failed: {e}")
    wait_time = TOKEN_REFRESH_INTERVAL if JWT_TOKENS else min(60 * (2 ** retry_count), 29100)
    threading.Timer(wait_time, fetch_tokens, args=[retry_count + (0 if JWT_TOKENS else 1)]).start()

def get_server_token(server_index):
    server_name = f"serv_{server_index}"
    token = JWT_TOKENS.get(server_name)
    return server_name, token

fetch_tokens()
time.sleep(8)  

def save_user(user_id, uid, server_name, days=1):
    users = load_users()
    user_id = str(user_id)
    uid = str(uid)
    if user_id not in users:
        users[user_id] = {}

    expiry = int(time.time()) + days * 24 * 60 * 60
    users[user_id][uid] = {
        "expiry": expiry,
        "server": server_name  
    }
    save_users(users)

def remove_user(user_id, uid):
    users = load_users()
    user_id = str(user_id)
    uid = str(uid)
    if user_id in users and uid in users[user_id]:
        server_name = users[user_id][uid].get("server", "غير معروف")
        del users[user_id][uid]
        if not users[user_id]:
            del users[user_id]
        save_users(users)
        return f"✅ تم حذف UID {uid} من المستخدم {user_id} (كان في السيرفر {server_name})"
    return f"🚫 لم يتم العثور على UID {uid} للمستخدم {user_id}"

def remove_all_user(user_id):
    users = load_users()
    user_id = str(user_id)
    if user_id in users:
        del users[user_id]
        save_users(users)
        return f"✅ تم حذف جميع UID الخاصة بالمستخدم {user_id}"
    return f"🚫 لم يتم العثور على أي UID للمستخدم {user_id}"

users_file = "users.json"

def load_users():
    if not os.path.exists(users_file):
        return {}
    try:
        with open(users_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    with open(users_file, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)
        
def ensure_user_exists(user_id):
    users = load_users() 
    if user_id not in users:
        users[user_id] = {}  
        save_users(users)           

def remove_expired_users():
    users = load_users()
    now = int(time.time())
    changed = False

    for user_id in list(users.keys()):
        for uid in list(users[user_id].keys()):
            if users[user_id][uid].get("expiry", 0) < now:
                del users[user_id][uid]
                changed = True
        if not users[user_id]:
            del users[user_id]
            changed = True

    if changed:
        save_users(users)

def format_remaining_time(expiry):
    now = int(time.time())
    remaining = expiry - now
    if remaining <= 0:
        return "❌ انتهى"
    days = remaining // 86400
    hours = (remaining % 86400) // 3600
    minutes = (remaining % 3600) // 60
    result = ""
    if days > 0:
        result += f"{days} يوم "
    if hours > 0:
        result += f"{hours} ساعة "
    result += f"{minutes} دقيقة"
    return result.strip()

def get_user_friends(user_id):
    users = load_users()
    return users.get(str(user_id), {})

def format_remaining_time(expiry_time):
    remaining_seconds = int(expiry_time - time.time())
    if remaining_seconds <= 0:
        return "⛔ انتهت الصلاحية"
    days = remaining_seconds // 86400
    hours = (remaining_seconds % 86400) // 3600
    minutes = (remaining_seconds % 3600) // 60
    return f"📅 {days} يوم و {hours} ساعة و {minutes} دقيقة"

def schedule_removal(user_id, uid, expiry_timestamp, server_name):
    delay = max(expiry_timestamp - time.time(), 0)
    t = threading.Timer(delay, remove_expired_uid, args=(user_id, uid, server_name))
    t.daemon = True
    t.start()

def remove_expired_uid(user_id, uid, server_name):
    try:
        server_name_used, remove_msg = remove_friend(uid, server_name)

        if isinstance(remove_msg, str) and remove_msg.startswith("✅"):
            print(f"[🗑️] تم حذف UID {uid} من السيرفر {server_name_used} (انتهت الصلاحية)")

            users = load_users()

            if isinstance(users, dict) and user_id in users and uid in users[user_id]:
                del users[user_id][uid]

                if not users[user_id]:
                    del users[user_id]
                    print(f"[🗑️] تم إزالة user {user_id} (لا أصدقاء)")

                save_users(users)

            try:
                bot.send_message(
                    DEV_ID,
                    f"🗑️ تم حذف UID منتهي:\n\n"
                    f"🆔 {uid}\n"
                    f"🖥️ السيرفر: {server_name_used}\n"
                    f"⏳ السبب: انتهت الصلاحية\n\n"
                    f"🔰 DEV BY ⚙️ :ALINAS"
                )
            except Exception as e:
                print(f"[⚠️] فشل إرسال إشعار للتليجرام: {e}")

        else:
            print(f"[⚠️] فشل حذف UID {uid} من السيرفر {server_name_used}: {remove_msg}")

    except Exception as e:
        print(f"[⚠️] Error in remove_expired_uid: {e}")

def auto_check_expiry():
    """
    يفحص كل UID الموجود ويجدده بالـ Timer المناسب للحذف
    """
    try:
        users = load_users()
        for user_id in list(users.keys()):
            for uid, info in users[user_id].items():
                if not isinstance(info, dict):
                    continue

                expiry = info.get("expiry", 0)
                server_name = info.get("server", "Unknown")
                schedule_removal(user_id, uid, expiry, server_name)

    except Exception as e:
        print(f"[⚠️] Error in auto_check_expiry: {e}")

def parse_protobuf_raw(data):
    result = {}
    pos = 0
    def read_varint():
        nonlocal pos
        value = 0
        shift = 0
        while True:
            if pos >= len(data):
                break
            byte_val = data[pos]
            pos += 1
            value |= (byte_val & 0x7F) << shift
            if not (byte_val & 0x80):
                break
            shift += 7
        return value
    while pos < len(data):
        try:
            first_byte = data[pos]
            pos += 1
            field_number = first_byte >> 3
            wire_type = first_byte & 0x07
            if wire_type == 0:
                value = read_varint()
                result.setdefault(field_number, []).append(value)
            elif wire_type == 2:
                length = read_varint()
                chunk = data[pos:pos+length]
                pos += length
                try:
                    string_value = chunk.decode('utf-8')
                    result.setdefault(field_number, []).append(string_value)
                except:
                    nested = parse_protobuf_raw(chunk)
                    result.setdefault(field_number, []).append(nested)
        except:
            break
    for k, v in list(result.items()):
        if isinstance(v, list) and len(v) == 1:
            result[k] = v[0]
    return result

def clean_value(val):
    if isinstance(val, list):
        val = val[0]
    if isinstance(val, dict):
        return str(val.get(1, "unknown"))
    if isinstance(val, int):
        return str(val)
    if isinstance(val, bytes):
        try:
            return val.decode("utf-8", errors="ignore")
        except:
            return "unknown"
    return str(val).strip()

def get_friends_list(server_name):
    token = JWT_TOKENS.get(server_name)
    if not token:
        return []

    url = "https://clientbp.ggpolarbear.com/GetFriend"
    headers = {
        "Authorization": f"Bearer {token}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB53",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "Connection": "Keep-Alive",
    }
    payload = b'\x59\x8F\xCA\xF0\x78\x39\x30\x8F\xF2\x87\xAC\xA3\xAE\x0A\x06\x17'

    response = requests.post(url, headers=headers, data=payload, timeout=10)
    parsed = parse_protobuf_raw(response.content)

    friends_raw = parsed.get(1, [])
    if isinstance(friends_raw, dict):
        friends_raw = [friends_raw]

    friends = []
    for fr in friends_raw:
        if isinstance(fr, dict):
            friends.append({
                "user_id": clean_value(fr.get(1)),
                "nickname": clean_value(fr.get(3))
            })

    return friends

def show_friends(call, server_name, page=1, per_page=10):
    token = JWT_TOKENS.get(server_name)

    if not token or not isinstance(token, str) or not token.strip():
        return bot.answer_callback_query(
            call.id,
            f"❌ Token unavailable for server: {server_name}"
        )

    url = "https://clientbp.ggpolarbear.com/GetFriend"
    headers = {
        "Authorization": f"Bearer {token}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB53",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "Connection": "Keep-Alive",
    }

    payload = b'\x59\x8F\xCA\xF0\x78\x39\x30\x8F\xF2\x87\xAC\xA3\xAE\x0A\x06\x17'

    try:
        response = requests.post(url, headers=headers, data=payload, timeout=10)
        parsed_data = parse_protobuf_raw(response.content)

        friends_raw = parsed_data.get(1, [])
        if isinstance(friends_raw, dict):
            friends_raw = [friends_raw]

        friends_list = []
        for fr in friends_raw:
            if isinstance(fr, dict):
                friends_list.append({
                    "user_id": clean_value(fr.get(1)),
                    "nickname": clean_value(fr.get(3))
                })

        if not friends_list:
            return bot.edit_message_text(
                "No friends found.",
                call.message.chat.id,
                call.message.message_id
            )

        total = len(friends_list)
        total_pages = max(1, (total - 1) // per_page + 1)

        page = max(1, min(page, total_pages))

        start = (page - 1) * per_page
        end = start + per_page
        page_friends = friends_list[start:end]

        text = f"<b>Friends on {server_name}</b>\nPage {page}/{total_pages}\n\n"
        keyboard = types.InlineKeyboardMarkup(row_width=1)

        for fr in page_friends:
            text += f"{fr['nickname']} — <code>{fr['user_id']}</code>\n"

            if call.from_user.id == OWNER_ID:
                keyboard.add(
                    types.InlineKeyboardButton(
                        f"Delete {fr['nickname']}",
                        callback_data=f"del|{server_name}|{fr['user_id']}|{page}"
                    )
                )

        nav = []
        if page > 1:
            nav.append(
                types.InlineKeyboardButton(
                    "Previous",
                    callback_data=f"friends|{server_name}|{page-1}"
                )
            )
        if page < total_pages:
            nav.append(
                types.InlineKeyboardButton(
                    "Next",
                    callback_data=f"friends|{server_name}|{page+1}"
                )
            )

        if nav:
            keyboard.row(*nav)

        keyboard.add(
            types.InlineKeyboardButton(
                "CLEAN SERVER",
                callback_data=f"clear|{server_name}"
            ),
            types.InlineKeyboardButton(
                "⬅️ Back",
                callback_data=f"account|{server_name}"
            )
        )

        new_text = text

        # 🔴 الحماية من error "message is not modified"
        try:
            if call.message.text == new_text:
                return

            bot.edit_message_text(
                new_text,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=keyboard,
                parse_mode="HTML"
            )

        except telebot.apihelper.ApiTelegramException as e:
            if "message is not modified" in str(e):
                return
            raise

    except Exception as e:
        bot.answer_callback_query(
            call.id,
            f"Error fetching friends: {e}"
        )
    
def request_add_friend(player_id, server_index):

    server_name = f"serv_{server_index}"
    token = JWT_TOKENS.get(server_name)

    if not token:
        return server_index, server_name, "🚫 السيرفر لا يحتوي توكن"

    try:
        encrypted_id = Encrypt_ID(player_id)

        if not encrypted_id:
            return server_index, server_name, "❌ Encrypt_ID failed"

        payload = f"08a7c4839f1e10{encrypted_id}1801"

        encrypted_payload = encrypt_api(payload)

        if not encrypted_payload:
            return server_index, server_name, "❌ encrypt_api returned empty"

        payload_bytes = bytes.fromhex(encrypted_payload)

        url = "https://clientbp.ggpolarbear.com/RequestAddingFriend"

        headers = {
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "ReleaseVersion": "OB53",
            "Content-Type": "application/x-www-form-urlencoded",
            'Expect': '100-continue',
            'X-GA': 'v1 1',
            'Host': 'clientbp.ggpolarbear.com',
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
            "Connection": "Keep-Alive",
        }

        response = requests.post(
            url,
            headers=headers,
            data=payload_bytes,
            timeout=15   # 🔥 مهم جدًا
        )

        if response.status_code == 200:
            return server_index, server_name, "✅ تمت الإضافة"

        return server_index, server_name, f"⚠️ API Error {response.status_code}"

    except Exception as e:
        return server_index, server_name, f"❌ Exception: {e}"

def remove_friend(player_id, stored_server_name):

    token = JWT_TOKENS.get(stored_server_name)

    if not token or not token.strip():
        return stored_server_name, f"📩 🚫 Token غير متاح حالياً على {stored_server_name}"

    try:
        encrypted_id = Encrypt_ID(player_id)

        if not encrypted_id:
            return stored_server_name, "❌ Encrypt_ID فشل"

        payload = f"08a7c4839f1e10{encrypted_id}1801"

        encrypted_payload = encrypt_api(payload)

        if not encrypted_payload:
            return stored_server_name, "❌ encrypt_api فشل"

        payload_bytes = bytes.fromhex(encrypted_payload)

        url = "https://clientbp.ggpolarbear.com/RemoveFriend"

        headers = {
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "ReleaseVersion": "OB53",
            "Content-Type": "application/x-www-form-urlencoded",
            'Expect': '100-continue',
            'X-GA': 'v1 1',
            'Host': 'clientbp.ggpolarbear.com',
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
            "Connection": "Keep-Alive",
        }

        response = requests.post(
            url,
            headers=headers,
            data=payload_bytes,
            timeout=15   # 🔥 مهم جدًا باش ما يعلقش
        )

        if response.status_code == 200:

            try:
                json_resp = response.json()
            except:
                json_resp = {}

            print("RAW RESPONSE:", response.content)

            if json_resp.get("success", False) or "تم" in str(json_resp):
                return stored_server_name, "✅ تمت إزالة اللاعب من الأصدقاء"

            return stored_server_name, "✅ تمت الإزالة (رد غير واضح من السيرفر)"

        elif response.status_code == 401:
            return stored_server_name, f"⚠️ Unauthorized (401) على {stored_server_name}"

        else:
            return stored_server_name, f"⚠️ API Error {response.status_code}"

    except Exception as e:
        print("REMOVE FRIEND ERROR:", e)
        return stored_server_name, f"❌ Exception: {e}"


def get_user_entries(users, user_id, now, is_dev=False):
    entries = []
    for uid, info in list(users.get(user_id, {}).items()):
        if not isinstance(info, dict):
            continue
        expiry = info.get("expiry", 0)
        server = info.get("server", "Unknown")
        if expiry > now:
            remaining = format_remaining_time(expiry)
            if is_dev:
                entries.append(
                    f"👤 User {user_id}\n🆔 <b>{uid}</b>\n🖥️ سيرفر: {html.escape(server)}\n⏳ {remaining}\n"
                )
            else:
                entries.append(
                    f"🆔 <b>{uid}</b>\n🖥️ سيرفر: {html.escape(server)}\n⏳ {remaining}\n"
                )
    return entries

def format_bar(exp, level):
    # fallback بسيط (لأن API ما تعطي next exp)
    next_exp = exp + 50000

    percent = int((exp / next_exp) * 100)
    total = 14
    filled = int(percent / 100 * total)

    bar = "█" * filled + "░" * (total - filled)

    return percent, bar, next_exp

def set_welcome_note(note_type, content):
    try:
        with open(WELCOME_FILE, "w", encoding="utf-8") as f:
            json.dump({
                "type": note_type,
                "content": content
            }, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("SET WELCOME ERROR:", e)


def get_welcome_note():
    try:
        if not os.path.exists(WELCOME_FILE):
            return None

        with open(WELCOME_FILE, "r", encoding="utf-8") as f:
            data = f.read().strip()
            if not data:
                return None

            return json.loads(data)

    except Exception as e:
        print("GET WELCOME ERROR:", e)
        return None


def clear_welcome_note():
    try:
        if os.path.exists(WELCOME_FILE):
            os.remove(WELCOME_FILE)   # الأفضل من كتابة ملف فارغ
    except Exception as e:
        print("CLEAR WELCOME ERROR:", e)

@bot.message_handler(commands=['alinas'])
def show_main_panel(message, from_callback=False):
    if not from_callback and message.from_user.id != OWNER_ID:
        return

    keyboard = types.InlineKeyboardMarkup(row_width=2)

    # ================= GROUP SECTION =================
    keyboard.add(
        types.InlineKeyboardButton(" GROUP COMMANDS", callback_data="section_groups"),
        types.InlineKeyboardButton(" NOTE SECTION", callback_data="section_note"),
    )

    # ================= NOTE SPLIT =================
    keyboard.add(
        types.InlineKeyboardButton(" WELCOME NOTE", callback_data="section_note_welcome"),
        types.InlineKeyboardButton(" LEFT NOTE", callback_data="section_note_global"),
    )

    # ================= BROADCAST =================
    keyboard.add(
        types.InlineKeyboardButton(" BROADCAST SECTION", callback_data="section_broadcast"),
    )

    # ================= SYSTEM =================
    keyboard.add(
        types.InlineKeyboardButton(" ACTIVATION PANEL", callback_data="section_activation_panel"),
        types.InlineKeyboardButton(" SERVERS MANAGER", callback_data="servers_panel")
    )

    # ================= TASKS =================
    keyboard.add(
        types.InlineKeyboardButton(" TASKS", callback_data="section_tasks")
    )

    # ================= CONTROL =================
    keyboard.add(
        types.InlineKeyboardButton(" LEAVE GROUP", callback_data="leave_group"),
        types.InlineKeyboardButton(" RESTART BOT", callback_data="restart_bot")
    )

    keyboard.add(
        types.InlineKeyboardButton(" CLOSE PANEL", callback_data="close_panel")
    )

    text = "<b>CONTROL PANEL</b>"

    try:
        if from_callback:
            if message.text == text:
                return

            bot.edit_message_text(
                text,
                chat_id=message.chat.id,
                message_id=message.message_id,
                reply_markup=keyboard,
                parse_mode="HTML"
            )
        else:
            bot.reply_to(
                message,
                text,
                reply_markup=keyboard,
                parse_mode="HTML"
            )

    except telebot.apihelper.ApiTelegramException as e:
        if "message is not modified" in str(e):
            return
        raise


@bot.callback_query_handler(func=lambda call: call.data == "section_tasks")
def show_tasks_panel(call):
    keyboard = types.InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        types.InlineKeyboardButton("ADD TASK", callback_data="task_add"),
        types.InlineKeyboardButton("REMOVE TASK", callback_data="task_remove"),
        types.InlineKeyboardButton("SHOW TASKS", callback_data="task_show"),
        types.InlineKeyboardButton("REMOVE ALL", callback_data="task_remove_all"),
        types.InlineKeyboardButton("DISABLE ALL TASKS", callback_data="task_disable_all"),
        types.InlineKeyboardButton("BACK", callback_data="alinas_back")
    )

    text = "<b>TASK MANAGEMENT PANEL</b>\nSelect an action:"

    try:
        # 🔴 حماية من نفس المشكلة
        if call.message.text == text:
            return

        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard,
            parse_mode="HTML"
        )

    except telebot.apihelper.ApiTelegramException as e:
        if "message is not modified" in str(e):
            return
        raise

@bot.callback_query_handler(func=lambda call: call.data == "servers_panel")
def servers_panel(call):
    if call.from_user.id != OWNER_ID:
        return

    keyboard = types.InlineKeyboardMarkup(row_width=2)

    buttons = []
    for server in SERVERS:
        name = server["name"]
        token = JWT_TOKENS.get(name)
        status = "🟢 Online" if token else "🔴 Offline"

        buttons.append(
            types.InlineKeyboardButton(
                f"{name} | {status}",
                callback_data=f"account|{name}"
            )
        )

    for i in range(0, len(buttons), 2):
        keyboard.add(*buttons[i:i + 2])

    keyboard.add(
        types.InlineKeyboardButton("⬅️ Back", callback_data="back_main")
    )

    bot.edit_message_text(
        "📡 Account Management Panel\nSelect an account 👇",
        call.message.chat.id,
        call.message.message_id,
        reply_markup=keyboard
    )

def update_account_panel(call, name):
    token = JWT_TOKENS.get(name)
    status = "🟢 Online" if token else "🔴 Offline"

    text = f" Account: <b>{name}</b>\nStatus: {status}"

    keyboard = types.InlineKeyboardMarkup(row_width=2)

    if not token:
        keyboard.add(
            types.InlineKeyboardButton("▶️ Start Server", callback_data=f"start|{name}")
        )
    else:
        keyboard.add(
            types.InlineKeyboardButton("♻️ Refresh Token", callback_data=f"refresh|{name}"),
            types.InlineKeyboardButton("⛔ Stop Server", callback_data=f"stop|{name}")
        )

    keyboard.add(
        types.InlineKeyboardButton("👥 View Friends", callback_data=f"friends|{name}|1"),
        types.InlineKeyboardButton("⬅️ Back", callback_data="servers_panel")
    )

    try:
        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    except telebot.apihelper.ApiTelegramException as e:
        if "message is not modified" in str(e):
            return  # تجاهل الخطأ
        raise

@bot.callback_query_handler(func=lambda call: call.data.startswith("account|"))
def account_details(call):
    if call.from_user.id != OWNER_ID:
        return

    name = call.data.split("|", 1)[1]
    update_account_panel(call, name)

@bot.callback_query_handler(func=lambda call: call.data.startswith("stop|"))
def stop_account(call):
    if call.from_user.id != OWNER_ID:
        return

    name = call.data.split("|", 1)[1]
    JWT_TOKENS.pop(name, None)
    update_account_panel(call, name)

@bot.callback_query_handler(func=lambda call: call.data.startswith("start|"))
def start_account(call):
    if call.from_user.id != OWNER_ID:
        return

    name = call.data.split("|", 1)[1]
    server = next((s for s in SERVERS if s["name"] == name), None)
    if not server:
        return

    try:
        tok = _getJwt(server["uid"], server["password"])
        if not tok:
            return
        JWT_TOKENS[name] = tok
    except:
        return

    update_account_panel(call, name)

@bot.callback_query_handler(func=lambda call: call.data.startswith("refresh|"))
def refresh_account(call):
    if call.from_user.id != OWNER_ID:
        return

    name = call.data.split("|", 1)[1]
    server = next((s for s in SERVERS if s["name"] == name), None)
    if not server:
        return

    try:
        tok = _getJwt(server["uid"], server["password"])
        if tok:
            JWT_TOKENS[name] = tok
    except:
        return

    update_account_panel(call, name)

def clean_string(val):
    if isinstance(val, list):
        val = val[0]
    if isinstance(val, bytes):
        try:
            val = val.decode("utf-8", errors="ignore")
        except:
            return "Unknown"
    return str(val).strip()

def clean_user_id(val):
    if isinstance(val, list):
        val = val[0]

    try:
        return str(int(val))
    except:
        return None

def extract_user_id(val):
    if isinstance(val, list):
        val = val[0]

    try:
        return str(int(val))
    except:
        return None

@bot.callback_query_handler(func=lambda call: call.data.startswith("friends|"))
def friends_handler(call):
    if call.from_user.id != OWNER_ID:
        return

    _, server_name, page = call.data.split("|")
    show_friends(call, server_name, int(page))

@bot.callback_query_handler(func=lambda call: call.data.startswith("del|"))
def delete_single_friend(call):
    if call.from_user.id != OWNER_ID:
        return

    _, server_name, user_id, page = call.data.split("|")
    page = int(page)

    returned_server, msg = remove_friend(user_id, server_name)

    if msg.startswith("🚫 Token") or msg.startswith("⚠️") or msg.startswith("❌"):
        bot.edit_message_text(
            f"⚠️ {msg}",
            call.message.chat.id,
            call.message.message_id
        )
        update_account_panel(call, returned_server)
        return

    show_friends(call, returned_server, page)

@bot.callback_query_handler(func=lambda call: call.data.startswith("clear|"))
def delete_all_friends(call):
    if call.from_user.id != OWNER_ID:
        return

    _, server_name = call.data.split("|", 1)

    friends = get_friends_list(server_name)
    if not friends:
        return bot.answer_callback_query(call.id, "No friends found.")

    errors = []

    for fr in friends:
        user_id = fr.get("user_id")
        if not user_id:
            continue

        returned_server, msg = remove_friend(user_id, server_name)

        if msg.startswith(("🚫", "⚠️", "❌")):
            errors.append(f"{user_id}: {msg}")
            continue

    if errors:
        try:
            bot.answer_callback_query(
                call.id,
                f"Finished with {len(errors)} errors",
                show_alert=False
            )
        except:
            pass

    show_friends(call, server_name, page=1)
    

@bot.callback_query_handler(func=lambda call: call.data == "section_activation_panel")
def activation_panel(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    keyboard = types.InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        types.InlineKeyboardButton("⚡ التفعيل", callback_data="activation_days"),
        types.InlineKeyboardButton("❌ إلغاء التفعيل", callback_data="section_deactivation"),
    )
    keyboard.add(
        types.InlineKeyboardButton("📋 قائمة الجروبات", callback_data="section_groups_list"),
        types.InlineKeyboardButton("📂 الملف الداخلي", callback_data="section_file"),
    )
    keyboard.add(
        types.InlineKeyboardButton("⬅️ رجوع", callback_data="back_main")
    )

    bot.edit_message_text(
        "⚡ قسم التفعيل:\nاختر إجراء من القائمة 👇",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard
    )

@bot.callback_query_handler(func=lambda call: call.data == "section_activation_panel")
def activation_panel(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    bot.answer_callback_query(call.id)  

    keyboard = types.InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        types.InlineKeyboardButton("⚡ التفعيل", callback_data="activation_days"),
        types.InlineKeyboardButton("❌ إلغاء التفعيل", callback_data="section_deactivation"),
    )
    keyboard.add(
        types.InlineKeyboardButton("📋 قائمة الجروبات", callback_data="section_groups_list"),
        types.InlineKeyboardButton("📂 الملف الداخلي", callback_data="section_file"),
    )
    keyboard.add(types.InlineKeyboardButton("⬅️ رجوع", callback_data="back_main"))

    try:
        bot.edit_message_text(
            "⚡ قسم التفعيل:\nاختر إجراء من القائمة 👇",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"[Error] activation_panel edit_message_text failed: {e}")

def is_allowed(chat_id, groups):
    if chat_id not in groups:
        return False

    expiry_str = groups[chat_id].get("expiry")
    if not expiry_str:
        return False

    try:
        expiry = parser.isoparse(expiry_str)

        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)

        now = datetime.now(timezone.utc)
        return now <= expiry

    except Exception as e:
        print(f"[Error] is_allowed failed for chat_id {chat_id}: {e}")
        return False

@bot.callback_query_handler(func=lambda call: call.data == "activation_days")
def activation_days(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    bot.answer_callback_query(call.id)

    keyboard = types.InlineKeyboardMarkup(row_width=3)
    days_options = [1, 5, 10, 20, 50, 100, 250, 500, 1000]
    buttons = [types.InlineKeyboardButton(f"{d} يوم", callback_data=f"activate_{d}") for d in days_options]
    keyboard.add(*buttons)
    keyboard.add(types.InlineKeyboardButton("BACK", callback_data="section_activation_panel"))

    try:
        bot.edit_message_text(
            "⚡ اختر مدة التفعيل للجروب:",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"[Error] activation_days edit_message_text failed: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith("activate_"))
def activate_group_btn(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    bot.answer_callback_query(call.id)

    try:
        days = int(call.data.split("_")[1])

        expiry_datetime = datetime.now(timezone.utc) + timedelta(days=days)

        add_group(call.message.chat.id, days, call.from_user.id)

        text = (
            f"✅ تم تفعيل الجروب بنجاح!\n"
            f"🆔 معرف الجروب: <b>{call.message.chat.id}</b>\n"
            f"⏰ مدة التفعيل: <b>{days}</b> يوم\n"
            f"📅 ينتهي في: <b>{expiry_datetime.strftime('%Y-%m-%d %H:%M:%S %Z')}</b>"
        )

        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            parse_mode="HTML"
        )
    except Exception as e:
        print(f"[Error] activate_group_btn failed: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "section_deactivation")
def deactivation_panel(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    bot.answer_callback_query(call.id)

    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(
        types.InlineKeyboardButton("❌ إلغاء تفعيل الجروب", callback_data="deactivate_group"),
        types.InlineKeyboardButton("⬅️ رجوع", callback_data="section_activation_panel")
    )

    try:
        bot.edit_message_text(
            "🚫 هل تريد إلغاء تفعيل هذا الجروب؟",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard
        )
    except Exception as e:
        print(f"[Error] deactivation_panel edit_message_text failed: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "deactivate_group")
def deactivate_group_btn(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    bot.answer_callback_query(call.id)

    try:
        if remove_group(call.message.chat.id):
            text = f"❌ تم إلغاء تفعيل الجروب بنجاح!\n🆔 معرف الجروب: <b>{call.message.chat.id}</b>"
        else:
            text = "ℹ️ هذه المجموعة غير مفعلة من الأساس."

        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton("⬅️ رجوع", callback_data="section_activation_panel"))

        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    except Exception as e:
        print(f"[Error] deactivate_group_btn edit_message_text failed: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "section_groups_list")
def list_active_groups(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    data = load_json()
    groups = data.get("groups", {})

    if not groups:
        text = "ℹ️ لا توجد جروبات مسجلة حالياً."
    else:
        text = "📋 قائمة الجروبات المفعلة:\n\n"
        for gid, info in groups.items():
            expiry = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(info.get("expiry", 0)))
            status = "✅ مفعل" if info.get("status", "inactive") == "active" else "❌ منتهي"
            text += f"🆔 {gid} | ⏰ {expiry} | {status}\n"

    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("⬅️ رجوع", callback_data="section_activation_panel"))

    bot.edit_message_text(
        text,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=keyboard
    )

@bot.callback_query_handler(func=lambda call: call.data == "section_file")
def show_config_file(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    try:
        with open(groups_file, "r", encoding="utf-8") as f:
            content = f.read()
    except FileNotFoundError:
        content = "{}"

    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("⬅️ رجوع", callback_data="section_activation_panel"))

    if len(content) > 4000:
        with open(groups_file, "rb") as f:
            bot.send_document(call.message.chat.id, f, caption="📂 ملف الجروبات والداتا")
    else:
        bot.edit_message_text(
            f"📂 محتوى {groups_file}:\n\n<pre>{content}</pre>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode="HTML",
            reply_markup=keyboard
        )

@bot.callback_query_handler(func=lambda call: call.data == "back_main")
def back_to_main(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")
    show_main_panel(call.message, from_callback=True)

@bot.callback_query_handler(func=lambda call: call.data == "back_to_main")
def back_to_main(call):
    show_main_panel(call.message, from_callback=True)

@bot.callback_query_handler(func=lambda call: call.data == "section_broadcast")
def broadcast_panel(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📢 إذاعة", callback_data="broadcast_normal"),
        types.InlineKeyboardButton("📌 إذاعة مميزة", callback_data="broadcast_pinned"),
    )
    markup.add(types.InlineKeyboardButton("❌ إغلاق", callback_data="close_menu"))

    try:
        bot.edit_message_text(
            "⚡ اختر نوع الإذاعة التي تريد تنفيذها:",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=markup
        )
    except:
        pass

@bot.callback_query_handler(func=lambda call: call.data == "close_menu")
def close_menu(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")
    try:
        bot.edit_message_text("✅ تم إغلاق القائمة.", call.message.chat.id, call.message.message_id)
    except:
        pass

@bot.callback_query_handler(func=lambda call: call.data.startswith("broadcast_"))
def start_broadcast(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

        broadcast_type = call.data.split("_")[1]

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(types.InlineKeyboardButton("❌ إلغاء", callback_data="cancel_broadcast"))

        text = (
            "✍️ أرسل الآن الرسالة (نص/صورة/فيديو/الخ...) ليتم إرسالها.\n"
            "🛑 اضغط ❌ للإلغاء."
        )

        try:
            bot.edit_message_text(
                text,
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                reply_markup=markup
            )
        except:
            bot.send_message(
                call.message.chat.id,
                text,
                reply_markup=markup
            )

        # ❌ لا تخزن داخل Message object
        # بدلها global dict أو cache
        BROADCAST_STATE = {
            "user_id": call.from_user.id,
            "chat_id": call.message.chat.id,
            "msg_id": call.message.message_id,
            "type": broadcast_type
        }

        # ✔️ تمرير data بدل message object
        bot.register_next_step_handler(
            call.message,
            lambda m: process_broadcast(m, broadcast_type)
        )

    except Exception as e:
        print("start_broadcast ERROR:", e)

def process_broadcast(message, broadcast_type, call=None):
    try:
        # 🔐 حماية من أي type غلط
        if not hasattr(message, "from_user"):
            print("INVALID MESSAGE TYPE:", type(message))
            return

        if message.from_user.id != OWNER_ID:
            bot.reply_to(message, "🚫 Owner only.")
            return

        # 📂 تحميل القروبات بأمان
        try:
            with open(ALLOWED_GROUPS_FILE, "r") as f:
                groups = json.load(f)

            if isinstance(groups, dict):
                groups = list(groups.keys())
            elif not isinstance(groups, list):
                groups = []

        except Exception as e:
            bot.reply_to(message, f"⚠️ Failed to load groups: {e}")
            return

        success = 0
        failed = 0

        # 📢 إرسال البث
        for chat_id in groups:
            try:
                chat_id = int(chat_id)

                content_type = getattr(message, "content_type", "text")

                if content_type == "text":
                    sent = bot.send_message(chat_id, message.text)

                elif content_type == "photo":
                    sent = bot.send_photo(
                        chat_id,
                        message.photo[-1].file_id,
                        caption=message.caption or ""
                    )

                elif content_type == "video":
                    sent = bot.send_video(
                        chat_id,
                        message.video.file_id,
                        caption=message.caption or ""
                    )

                elif content_type == "document":
                    sent = bot.send_document(
                        chat_id,
                        message.document.file_id,
                        caption=message.caption or ""
                    )

                elif content_type == "sticker":
                    sent = bot.send_sticker(chat_id, message.sticker.file_id)

                elif content_type == "voice":
                    sent = bot.send_voice(
                        chat_id,
                        message.voice.file_id
                    )

                elif content_type == "audio":
                    sent = bot.send_audio(
                        chat_id,
                        message.audio.file_id,
                        caption=message.caption or ""
                    )

                else:
                    continue

                # 📌 pin option
                if broadcast_type == "pinned":
                    try:
                        bot.pin_chat_message(chat_id, sent.message_id)
                    except:
                        pass

                success += 1
                time.sleep(0.3)

            except Exception as e:
                failed += 1
                print(f"[Broadcast Skip] {chat_id} | {e}")

        result_text = (
            "📢 Broadcast completed.\n"
            f"✅ Sent: {success}\n"
            f"❌ Failed: {failed}"
        )

        if call:
            try:
                bot.edit_message_text(
                    result_text,
                    chat_id=call.message.chat.id,
                    message_id=call.message.message_id
                )
            except:
                pass
        else:
            bot.reply_to(message, result_text)

    except Exception as e:
        print("process_broadcast ERROR:", e)

@bot.callback_query_handler(func=lambda call: call.data == "section_note")
def section_note(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    keyboard = types.InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        types.InlineKeyboardButton("➕ Add Note", callback_data="note"),
        types.InlineKeyboardButton("📖 Show Note", callback_data="show_note"),
        types.InlineKeyboardButton("❌ Delete Note", callback_data="delete_note"),
        types.InlineKeyboardButton("🔙 رجوع", callback_data="back_main")
    )

    bot.edit_message_text(
        "📝 قسم إدارة النوتة العامة:\nيمكنك إضافة / عرض / حذف النوتة 👇",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard
    )

waiting_for_note = {}  # user_id -> True/False

@bot.callback_query_handler(func=lambda call: call.data == "note")
def ask_note(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        # 🔐 نخزن الحالة لكل مستخدم
        waiting_for_note[call.from_user.id] = True

        bot.send_message(
            call.message.chat.id,
            "✍️ ابعت اللي عايزه يكون نوتة عامة:"
        )

    except Exception as e:
        print("ask_note ERROR:", e)

@bot.message_handler(func=lambda message: waiting_for_note and message.from_user.id == OWNER_ID,
                     content_types=["text", "photo", "video", "audio", "voice"])
def save_note_handler(message):
    global waiting_for_note

    try:
        if message.text:  
            set_global_note("text", message.text.strip())
            bot.reply_to(message, f"✅ تم إضافة النوتة النصية:\n📝 {message.text.strip()}")

        elif message.photo:  
            file_id = message.photo[-1].file_id
            set_global_note("photo", file_id)
            bot.reply_to(message, "✅ تم إضافة الصورة كنوتة عامة.")

        elif message.video: 
            file_id = message.video.file_id
            set_global_note("video", file_id)
            bot.reply_to(message, "✅ تم إضافة الفيديو كنوتة عامة.")

        elif message.audio or message.voice: 
            file_id = (message.audio or message.voice).file_id
            set_global_note("audio", file_id)
            bot.reply_to(message, "✅ تم إضافة الصوت كنوتة عامة.")

        else:
            bot.reply_to(message, "⚠️ نوع الرسالة غير مدعوم.")

    except Exception as e:
        bot.reply_to(message, f"⚠️ خطأ أثناء حفظ النوتة: {e}")

    finally:
        waiting_for_note = False  
        
@bot.callback_query_handler(func=lambda call: call.data == "delete_note")
def delete_note_handler(call):
    try:
        # 🔐 حماية من غير المالك
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        # 🧹 حذف النوتة
        clear_global_note()

        bot.answer_callback_query(call.id, "🗑️ تم الحذف بنجاح")
        bot.send_message(
            call.message.chat.id,
            "🗑️ تم مسح النوتة العامة بنجاح."
        )

    except Exception as e:
        print("delete_note_handler ERROR:", e)

@bot.callback_query_handler(func=lambda call: call.data == "show_note")
def show_note(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        note = get_global_note()

        if not isinstance(note, dict) or not note:
            return bot.send_message(call.message.chat.id, "⚠️ لا توجد نوتة حالياً.")

        note_type = note.get("type")
        content = note.get("content")

        if not note_type or not content:
            return bot.send_message(call.message.chat.id, "⚠️ النوتة غير صالحة.")

        if note_type == "text":
            bot.send_message(
                call.message.chat.id,
                f"📝 النوتة الحالية:\n{content}"
            )

        elif note_type == "photo":
            bot.send_photo(
                call.message.chat.id,
                content,
                caption="📝 هذه هي النوتة الحالية (صورة)"
            )

        elif note_type == "video":
            bot.send_video(
                call.message.chat.id,
                content,
                caption="📝 هذه هي النوتة الحالية (فيديو)"
            )

        elif note_type == "audio":
            bot.send_audio(
                call.message.chat.id,
                content,
                caption="📝 هذه هي النوتة الحالية (صوت)"
            )

        else:
            bot.send_message(call.message.chat.id, "⚠️ نوع النوتة غير معروف.")

    except Exception as e:
        print("show_note ERROR:", e)
        bot.send_message(call.message.chat.id, f"⚠️ خطأ أثناء عرض النوتة: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "back_main")
def back_main(call):
    show_main_panel(call.message, from_callback=True)

@bot.callback_query_handler(func=lambda call: call.data == "restart_bot")
def restart_bot(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

        bot.answer_callback_query(call.id, "♻️ جاري إعادة التشغيل...")

        # 💾 حفظ البيانات بأمان
        try:
            save_ban_data(ban_data)
        except Exception as e:
            print(f"⚠️ save_ban_data فشل: {e}")

        try:
            if 'save_user_data' in globals():
                save_user_data()
        except Exception as e:
            print(f"⚠️ save_user_data فشل: {e}")

        try:
            if 'save_notes_data' in globals():
                save_notes_data()
        except Exception as e:
            print(f"⚠️ save_notes_data فشل: {e}")

        # 📢 إرسال إشعار للجروبات
        try:
            groups = load_allowed_groups()

            if isinstance(groups, dict):
                chat_ids = list(groups.keys())
            elif isinstance(groups, list):
                chat_ids = groups
            else:
                chat_ids = []

            for chat_id in chat_ids:
                try:
                    bot.send_message(
                        int(chat_id),
                        "⚡ Bot has been restarted, please continue using it normally."
                    )
                except Exception as e:
                    print(f"⚠️ خطأ في إرسال رسالة لجروب {chat_id}: {e}")

        except Exception as e:
            print(f"⚠️ load_allowed_groups فشل: {e}")

        # ✏️ تحديث الرسالة قبل restart
        try:
            bot.edit_message_text(
                "✅ Restarting bot... Please wait.",
                chat_id=call.message.chat.id,
                message_id=call.message.message_id
            )
        except:
            pass

        # ⏳ مهم: delay بسيط قبل restart
        import time
        time.sleep(1)

        os.execv(sys.executable, [sys.executable] + sys.argv)

    except Exception as e:
        print("restart_bot ERROR:", e)
        try:
            bot.answer_callback_query(call.id, f"❌ خطأ: {e}")
        except:
            pass

@bot.callback_query_handler(func=lambda call: call.data == "back_to_main")
def back_to_main(call):
    show_main_panel(call.message, from_callback=True)

@bot.callback_query_handler(func=lambda call: call.data == "section_groups")
def show_group_section(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

    keyboard = types.InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        types.InlineKeyboardButton("✅ تفعيل جروب", callback_data="panel_activate"),
        types.InlineKeyboardButton("🛑 تعطيل جروب", callback_data="panel_disable")
    )
    keyboard.add(
        types.InlineKeyboardButton("📋 قائمة الجروبات", callback_data="panel_lista"),
        types.InlineKeyboardButton("📂 الملف الداخلي", callback_data="panel_debug")
    )
    keyboard.add(types.InlineKeyboardButton("⬅️ رجوع", callback_data="back_to_main"))

    bot.edit_message_text(
        "📌 قسم أوامر الجروبات:\nاختر العملية المطلوبة 👇",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard
    )

@bot.callback_query_handler(func=lambda call: call.data == "panel_activate")
def show_durations(call):
    if call.from_user.id != OWNER_ID:
        return

    INVISIBLE = "\u2060"  

    keyboard = types.InlineKeyboardMarkup(row_width=3)
    durations = [1, 5, 10, 20, 50, 100, 250, 500, 1000]
    buttons = [types.InlineKeyboardButton(f"{d} يوم", callback_data=f"allow_{d}") for d in durations]
    keyboard.add(*buttons)

    text = f"⏳ اختر مدة التفعيل للجروب الحالي:{INVISIBLE}"

    try:
        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=keyboard
        )
    except Exception as e:
        if "message is not modified" in str(e):
            pass 
        else:
            print("Edit Error:", e)

@bot.callback_query_handler(func=lambda call: call.data.startswith("allow_"))
def activate_group(call):
    if call.from_user.id != OWNER_ID:
        return

    try:
        days = int(call.data.split("_")[1])

        expiry_date = datetime.now(timezone.utc) + timedelta(days=days)

        groups = load_allowed_groups()
        chat_id_str = str(call.message.chat.id)

        groups[chat_id_str] = {
            "title": call.message.chat.title or "NoTitle",
            "days": days,
            "expiry": expiry_date.strftime("%Y-%m-%d %H:%M:%S")
        }
        save_allowed_groups(groups)

        bot.edit_message_text(
            f"✅ تم تفعيل البوت في هذا الجروب.\n"
            f"📌 الاسم: {call.message.chat.title or 'NoTitle'}\n"
            f"📅 المدة: {days} يومًا\n"
            f"⏳ ينتهي بتاريخ: {expiry_date.strftime('%Y-%m-%d %H:%M:%S')} UTC",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id
        )

    except Exception as e:
        bot.answer_callback_query(call.id, f"❌ خطأ: {e}")

@bot.callback_query_handler(func=lambda call: call.data == "panel_disable")
def disable_current_group(call):
    if call.from_user.id != OWNER_ID:
        return

    groups = load_allowed_groups()
    chat_id_str = str(call.message.chat.id)

    if chat_id_str in groups:
        del groups[chat_id_str]
        save_allowed_groups(groups)
        bot.edit_message_text(
            f"🛑 تم تعطيل البوت في هذا الجروب ({chat_id_str})",
            chat_id=call.message.chat.id,
            message_id=call.message.message_id
        )
    else:
        bot.answer_callback_query(call.id, "❌ الجروب مش مفعّل.")

@bot.callback_query_handler(func=lambda call: call.data == "panel_lista")
def list_groups(call):
    if call.from_user.id != OWNER_ID:
        return

    groups = load_allowed_groups()
    if not groups:
        return bot.answer_callback_query(call.id, "📭 لا يوجد جروبات مفعّلة.")

    text = "📋 قائمة الجروبات:\n\n"
    for gid, info in groups.items():
        expiry = info.get("expiry", "غير محدد")
        title = info.get("title", "بدون اسم")
        text += f"🔹 {title} (`{gid}`)\n⏳ انتهاء: {expiry}\n\n"

    bot.edit_message_text(
        text,
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        parse_mode="Markdown"
    )

@bot.callback_query_handler(func=lambda call: call.data == "panel_debug")
def debug_groups(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "🚫 غير مسموح")

        groups = load_allowed_groups()

        # 🔐 تأكد أن البيانات صالحة
        try:
            text = json.dumps(groups, ensure_ascii=False, indent=2)
        except Exception:
            text = str(groups)

        if not text:
            text = "{}"

        max_length = 4000
        if len(text) > max_length:
            text = text[:max_length] + "\n... ✂️ باقي البيانات مقصوصة."

        try:
            bot.edit_message_text(
                f"📂 الملف الداخلي:\n\n<pre>{text}</pre>",
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                parse_mode="HTML"
            )
        except Exception as e:
            bot.send_message(
                call.message.chat.id,
                f"⚠️ خطأ أثناء عرض الملف الداخلي: {e}"
            )

    except Exception as e:
        print("panel_debug ERROR:", e)

def is_allowed(chat_id):
    groups = load_allowed_groups()
    chat_id_str = str(chat_id)

    if chat_id_str in groups:
        expiry_str = groups[chat_id_str].get("expiry")
        if expiry_str:
            expiry_date = parser.parse(expiry_str)
            if expiry_date.tzinfo is None:
                expiry_date = expiry_date.replace(tzinfo=timezone.utc)

            if datetime.now(timezone.utc) < expiry_date:
                return True
    return False

group_lang = {}

@bot.callback_query_handler(func=lambda call: call.data.startswith("setlang_"))
def callback_setlang(call):
    lang = call.data.split("_")[1]
    group_lang[call.message.chat.id] = lang
    bot.answer_callback_query(call.id, f"✅ لغة الجروب تم تغييرها إلى {lang.upper()}")
    bot.edit_message_text(
        f"✅ لغة الجروب تم ضبطها: {lang.upper()}",
        call.message.chat.id,
        call.message.message_id
    )

@bot.callback_query_handler(func=lambda call: call.data == "leave_group")
def leave_group(call):
    try:
        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")

        chat_id = call.message.chat.id
        chat_id_str = str(chat_id)

        groups = load_allowed_groups()

        try:
            msg = bot.send_message(chat_id, "tnako nikmok 🙂")

            try:
                bot.pin_chat_message(
                    chat_id,
                    msg.message_id,
                    disable_notification=True
                )
            except Exception as e:
                if "not enough rights" not in str(e):
                    print("PIN ERROR:", e)

        except Exception as e:
            print("SEND ERROR:", e)

        # 🧹 حذف الجروب من القائمة بأمان
        try:
            if isinstance(groups, dict) and chat_id_str in groups:
                del groups[chat_id_str]
                save_allowed_groups(groups)
        except Exception as e:
            print("GROUP REMOVE ERROR:", e)

        # 🚪 خروج البوت من الجروب
        try:
            bot.leave_chat(chat_id)
        except Exception as e:
            print("LEAVE CHAT ERROR:", e)

    except Exception as e:
        print("leave_group ERROR:", e)

@bot.callback_query_handler(func=lambda call: call.data == "section_note_welcome")
def section_note_welcome(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    keyboard = types.InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        types.InlineKeyboardButton("➕ Add Welcome Note", callback_data="welcome_note"),
        types.InlineKeyboardButton("📖 Show Welcome Note", callback_data="show_welcome_note"),
        types.InlineKeyboardButton("❌ Delete Welcome Note", callback_data="delete_welcome_note"),
        types.InlineKeyboardButton("🔙 رجوع", callback_data="back_main")
    )

    bot.edit_message_text(
        "🎉 قسم إدارة رسالة الترحيب:\nيمكنك إضافة / عرض / حذف رسالة الترحيب 👇",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard
    )

waiting_for_welcome_note = {}

@bot.callback_query_handler(func=lambda call: call.data == "welcome_note")
def ask_welcome_note(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    waiting_for_welcome_note[call.from_user.id] = True

    bot.send_message(
        call.message.chat.id,
        "🎉 ابعت رسالة الترحيب (نص / صورة / فيديو):"
    )
    
@bot.message_handler(
    func=lambda m: waiting_for_welcome_note.get(m.from_user.id, False),
    content_types=["text", "photo", "video", "audio", "voice"]
)
def save_welcome_note(message):
    try:
        if message.text:
            set_welcome_note("text", message.text.strip())
            bot.reply_to(message, "✅ تم حفظ رسالة الترحيب (نص)")

        elif message.photo:
            file_id = message.photo[-1].file_id
            set_welcome_note("photo", file_id)
            bot.reply_to(message, "✅ تم حفظ رسالة الترحيب (صورة)")

        elif message.video:
            file_id = message.video.file_id
            set_welcome_note("video", file_id)
            bot.reply_to(message, "✅ تم حفظ رسالة الترحيب (فيديو)")

        elif message.audio or message.voice:
            file_id = (message.audio or message.voice).file_id
            set_welcome_note("audio", file_id)
            bot.reply_to(message, "✅ تم حفظ رسالة الترحيب (صوت)")

        else:
            bot.reply_to(message, "⚠️ نوع غير مدعوم")

    except Exception as e:
        bot.reply_to(message, f"⚠️ خطأ: {e}")

    finally:
        waiting_for_welcome_note[message.from_user.id] = False
        
@bot.callback_query_handler(func=lambda call: call.data == "show_welcome_note")
def show_welcome_note(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    note = get_welcome_note()

    if not isinstance(note, dict) or not note:
        return bot.send_message(call.message.chat.id, "⚠️ لا توجد رسالة ترحيب.")

    note_type = note.get("type")
    content = note.get("content")

    if note_type == "text":
        bot.send_message(call.message.chat.id, f"🎉 Welcome Note:\n{content}")

    elif note_type == "photo":
        bot.send_photo(call.message.chat.id, content, caption="🎉 Welcome Note (صورة)")

    elif note_type == "video":
        bot.send_video(call.message.chat.id, content, caption="🎉 Welcome Note (فيديو)")
        
@bot.callback_query_handler(func=lambda call: call.data == "delete_welcome_note")
def delete_welcome_note(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    clear_welcome_note()

    bot.answer_callback_query(call.id, "🗑️ تم الحذف")
    bot.send_message(call.message.chat.id, "🗑️ تم حذف رسالة الترحيب")
    
# ===================== LEFT NOTE SECTION =====================

@bot.callback_query_handler(func=lambda call: call.data == "section_note_global")
def section_note_global(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "❌ غير مسموح")

    keyboard = types.InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        types.InlineKeyboardButton("➕ Add Left Note", callback_data="left_note"),
        types.InlineKeyboardButton("📖 Show Left Note", callback_data="show_left_note"),
        types.InlineKeyboardButton("❌ Delete Left Note", callback_data="delete_left_note"),
        types.InlineKeyboardButton("🔙 رجوع", callback_data="back_main")
    )

    bot.edit_message_text(
        "👋 قسم إدارة رسالة المغادرة:\nيمكنك إضافة / عرض / حذف رسالة المغادرة 👇",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=keyboard
    )


# ===================== WAITING =====================

waiting_for_left_note = {}


# ===================== ASK LEFT NOTE =====================

@bot.callback_query_handler(func=lambda call: call.data == "left_note")
def ask_left_note(call):

    try:

        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        waiting_for_left_note[call.from_user.id] = True

        bot.send_message(
            call.message.chat.id,
            "✍️ ابعت رسالة المغادرة الجديدة:"
        )

    except Exception as e:
        print("ask_left_note ERROR:", e)


# ===================== SAVE LEFT NOTE =====================

@bot.message_handler(
    func=lambda message:
    waiting_for_left_note.get(message.from_user.id, False),
    content_types=["text", "photo", "video", "audio", "voice"]
)
def save_left_note_handler(message):

    try:

        if message.text:

            set_left_note("text", message.text.strip())

            bot.reply_to(
                message,
                f"✅ تم حفظ رسالة المغادرة:\n📝 {message.text.strip()}"
            )

        elif message.photo:

            file_id = message.photo[-1].file_id

            set_left_note("photo", file_id)

            bot.reply_to(
                message,
                "✅ تم حفظ صورة المغادرة."
            )

        elif message.video:

            file_id = message.video.file_id

            set_left_note("video", file_id)

            bot.reply_to(
                message,
                "✅ تم حفظ فيديو المغادرة."
            )

        elif message.audio or message.voice:

            file_id = (message.audio or message.voice).file_id

            set_left_note("audio", file_id)

            bot.reply_to(
                message,
                "✅ تم حفظ الصوت."
            )

        else:

            bot.reply_to(
                message,
                "⚠️ نوع غير مدعوم."
            )

    except Exception as e:

        bot.reply_to(
            message,
            f"⚠️ خطأ:\n{e}"
        )

    finally:

        waiting_for_left_note[message.from_user.id] = False


# ===================== DELETE LEFT NOTE =====================

@bot.callback_query_handler(func=lambda call: call.data == "delete_left_note")
def delete_left_note_handler(call):

    try:

        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        clear_left_note()

        bot.answer_callback_query(
            call.id,
            "🗑️ تم حذف رسالة المغادرة"
        )

        bot.send_message(
            call.message.chat.id,
            "🗑️ تم حذف رسالة المغادرة بنجاح."
        )

    except Exception as e:
        print("delete_left_note ERROR:", e)


# ===================== SHOW LEFT NOTE =====================

@bot.callback_query_handler(func=lambda call: call.data == "show_left_note")
def show_left_note(call):

    try:

        if call.from_user.id != OWNER_ID:
            return bot.answer_callback_query(call.id, "❌ غير مسموح")

        note = get_left_note()

        if not isinstance(note, dict) or not note:

            return bot.send_message(
                call.message.chat.id,
                "⚠️ لا توجد رسالة مغادرة حالياً."
            )

        note_type = note.get("type")
        content = note.get("content")

        if note_type == "text":

            bot.send_message(
                call.message.chat.id,
                f"📝 رسالة المغادرة الحالية:\n{content}"
            )

        elif note_type == "photo":

            bot.send_photo(
                call.message.chat.id,
                content,
                caption="🖼️ صورة المغادرة الحالية"
            )

        elif note_type == "video":

            bot.send_video(
                call.message.chat.id,
                content,
                caption="🎥 فيديو المغادرة الحالي"
            )

        elif note_type == "audio":

            bot.send_audio(
                call.message.chat.id,
                content,
                caption="🎵 صوت المغادرة الحالي"
            )

        else:

            bot.send_message(
                call.message.chat.id,
                "⚠️ نوع غير معروف."
            )

    except Exception as e:

        print("show_left_note ERROR:", e)

        bot.send_message(
            call.message.chat.id,
            f"⚠️ خطأ:\n{e}"
        )

@bot.callback_query_handler(func=lambda call: call.data == "close_panel")
def close_panel(call):
    if call.from_user.id != OWNER_ID:
        return bot.answer_callback_query(call.id, "🚫 للمالك فقط.")
    bot.delete_message(call.message.chat.id, call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data == "back_to_main")
def back_to_main(call):
    show_main_panel(call.message)
                                              
group_top_usage = {}  

DEV_URL = "https://t.me/xAlInAs_sAnIlAx"

ACTIVATION_TEXT = """```𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮
Hello, I am 𝗔𝗟𝗜𝗡𝗔𝗦 𝗣𝗥𝗜𝗠𝗘   Bot

🚫 This group is not activated

To activate the bot
Please contact me
```"""

last_lang_click = {}

def send_activation_message(chat_id):
    try:
        chat_id = int(chat_id)

        markup = types.InlineKeyboardMarkup()
        markup.add(
            types.InlineKeyboardButton("Contact Me", url=DEV_URL)
        )

        bot.send_message(
            chat_id,
            ACTIVATION_TEXT,
            reply_markup=markup,
            parse_mode="Markdown"
        )

    except Exception as e:
        print("send_activation_message ERROR:", e)

user_pages = {}

@bot.message_handler(commands=['start', 'help', 'x', 'D5X'])
def start_cmd(message):
    if not is_allowed(message.chat.id):
        send_activation_message(message.chat.id)
        return

    page1 = """𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗧𝗢 𝐀𝐋𝐈𝐍𝐀𝐒 𝐏𝐑𝐈𝐌𝐄

/DEV             - معلومات المطور 

/3 UID            - إرسال سكواد 3
/4 UID            - إرسال سكواد 4
/5 UID            - إرسال سكواد 5
/6 UID            - إرسال سكواد 6
/info UID         - معلومات اللاعب
/check UID        - فحص الباند
/spam UID         - سبام طلبات صداقة
/ghost TC NAME    - إرسال شبح مخصص
/wish UID         - جلب قائمة الأمنيات
/evo              - ترقيص
/dance & /emote   - ترقيص
++ UID            - سبام رومات
-- UID            - إيقاف السبام
/level UID        - معلومات اللفل
/bnr UID          - جلب البنر
/ban              - باند سبع ايام
/geban            - بان الضيف
/gen              - توليد حسابات
/clan             - معلومات كلان
/ser name         - البحث بالاسم
/MSG                - سبام رسائل فل سكواد 
/bot UID S(X)     - بوت صديق
/remove UID       - حذف البوت

Contact developer :
@xAlInAs_sAnIlAx
"""

    page2 = """I'addedd commands there is :

/3
/4
/5
/6
/info
/spam
/check
++
--
/level
/bnr
/gen
/clan
/ser

And this command it well be added soon :

/msg TC MESSAGE  - Send message with team code
/bot UID S(X)    - Friend bot
/remove UID      - Remove bot
"""

    pages = [page1, page2]

    user_pages[message.from_user.id] = 0

    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("Next", callback_data=f"next_{message.from_user.id}"),
        InlineKeyboardButton("Close", callback_data=f"close_{message.from_user.id}")
    )

    bot.send_message(
        message.chat.id,
        pages[0],
        reply_markup=markup
    )


@bot.callback_query_handler(func=lambda call: call.data.startswith(("next_", "close_")))
def page_buttons(call):
    user_id = int(call.data.split("_")[1])

    if call.from_user.id != user_id:
        return

    page1 = """𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗧𝗢 𝐀𝐋𝐈𝐍𝐀𝐒 𝐏𝐑𝐈𝐌𝐄

/DEV             - معلومات المطور 

/3 UID            - إرسال سكواد 3
/4 UID            - إرسال سكواد 4
/5 UID            - إرسال سكواد 5
/6 UID            - إرسال سكواد 6
/info UID         - معلومات اللاعب
/check UID        - فحص الباند
/spam UID         - سبام طلبات صداقة
/ghost TC NAME    - إرسال شبح مخصص
/wish UID         - جلب قائمة الأمنيات
/evo              - ترقيص
/dance & /emote   - ترقيص
++ UID            - سبام رومات
-- UID            - إيقاف السبام
/level UID        - معلومات اللفل
/bnr UID          - جلب البنر
/ban              - باند سبع ايام
/geban            - بان الضيف
/gen              - توليد حسابات
/clan             - معلومات كلان
/ser name         - البحث بالاسم
/MSG                - سبام رسائل فل سكواد 
/bot UID S(X)     - بوت صديق
/remove UID       - حذف البوت

Contact developer :
@MC_1A
"""

    page2 = """I'addedd commands there is :

/3
/4
/5
/6
/info
/spam
/check
++
--
/level
/bnr
/gen
/clan
/ser

And this command it well be added soon :

/msg TC MESSAGE  - Send message with team code
/bot UID S(X)    - Friend bot
/remove UID      - Remove bot
"""

    pages = [page1, page2]

    if call.data.startswith("close_"):
        bot.delete_message(call.message.chat.id, call.message.message_id)
        return

    current_page = user_pages.get(user_id, 0)
    next_page = (current_page + 1) % len(pages)
    user_pages[user_id] = next_page

    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("Next", callback_data=f"next_{user_id}"),
        InlineKeyboardButton("Close", callback_data=f"close_{user_id}")
    )

    bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=pages[next_page],
        reply_markup=markup
    )

def send_page(chat_id, user_id, lang):
    try:
        chat_id = int(chat_id)

        page_index = user_pages.get(user_id, 0)

        if lang not in menus or not menus.get(lang):
            return

        # 🔐 حماية من index خارج الحدود
        if page_index < 0 or page_index >= len(menus[lang]):
            page_index = 0
            user_pages[user_id] = 0

        page = menus[lang][page_index]

        markup = types.InlineKeyboardMarkup()
        buttons = []

        if page_index > 0:
            buttons.append(
                types.InlineKeyboardButton("⬅️ السابق", callback_data=f"{lang}:prev")
            )

        buttons.append(
            types.InlineKeyboardButton("❌ إغلاق", callback_data=f"{lang}:close")
        )

        if page_index < len(menus[lang]) - 1:
            buttons.append(
                types.InlineKeyboardButton("التالي ➡️", callback_data=f"{lang}:next")
            )

        markup.row(*buttons)

        bot.send_message(
            chat_id,
            page,
            reply_markup=markup,
            parse_mode="Markdown"
        )

    except Exception as e:
        print("send_page ERROR:", e)

@bot.callback_query_handler(func=lambda call: ":" in call.data)
def flip_page(call):
    try:
        bot.answer_callback_query(call.id)
    except:
        pass

    try:
        parts = call.data.split(":")
        if len(parts) != 2:
            return

        lang, action = parts
        user_id = call.from_user.id

        if user_id not in user_pages:
            user_pages[user_id] = 0

        if lang not in menus or not menus[lang]:
            return bot.send_message(call.message.chat.id, "📭 لا يوجد محتوى للعرض.")

        if action == "close":
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except Exception as e:
                print("خطأ حذف:", e)
            return

        max_index = len(menus[lang]) - 1

        if action == "next" and user_pages[user_id] < max_index:
            user_pages[user_id] += 1

        elif action == "prev" and user_pages[user_id] > 0:
            user_pages[user_id] -= 1

        page_index = user_pages[user_id]
        page = menus[lang][page_index]

        markup = types.InlineKeyboardMarkup()
        buttons = []

        if page_index > 0:
            buttons.append(
                types.InlineKeyboardButton("⬅️ السابق", callback_data=f"{lang}:prev")
            )

        buttons.append(
            types.InlineKeyboardButton("❌ إغلاق", callback_data=f"{lang}:close")
        )

        if page_index < max_index:
            buttons.append(
                types.InlineKeyboardButton("التالي ➡️", callback_data=f"{lang}:next")
            )

        markup.row(*buttons)

        try:
            bot.edit_message_text(
                page,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=markup,
                parse_mode="Markdown"
            )
        except Exception as e:
            print("خطأ تعديل:", e)

    except Exception as e:
        print("flip_page ERROR:", e)

hex_Key = "32656534343831396539623435393838343531343130363762323831363231383734643064356437616639643866376530306331653534373135623764316533"
MaIn_KeY = bytes.fromhex(hex_Key)

ReGiOnMaP = {
    "ME": "ar", "IND": "hi", "ID": "id", "VN": "vi", "TH": "th",
    "BD": "bn", "PK": "ur", "TW": "zh", "EU": "en", "CIS": "ru",
    "NA": "en", "SAC": "es", "BR": "pt"
}

ReGiOnUrLs = {
    "IND": "https://client.ind.freefiremobile.com/",
    "ID": "https://clientbp.ggpolarbear.com/",
    "BR": "https://client.us.freefiremobile.com/",
    "ME": "https://clientbp.common.ggbluefox.com/",
    "VN": "https://clientbp.ggpolarbear.com/",
    "TH": "https://clientbp.common.ggbluefox.com/",
    "CIS": "https://clientbp.ggpolarbear.com/",
    "BD": "https://clientbp.ggpolarbear.com/",
    "PK": "https://clientbp.ggpolarbear.com/",
    "SG": "https://clientbp.ggpolarbear.com/",
    "NA": "https://client.us.freefiremobile.com/",
    "SAC": "https://client.us.freefiremobile.com/",
    "EU": "https://clientbp.ggpolarbear.com/",
    "TW": "https://clientbp.ggpolarbear.com/"
}

SUPERSCRIPT_MAP = {
    '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
    '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹'
}

def to_superscript(num_str):
    return ''.join(SUPERSCRIPT_MAP.get(ch, ch) for ch in num_str)

def GeTlAnG(cOde):
    return ReGiOnMaP.get(cOde)

def GeTuRl(cOde):
    return ReGiOnUrLs.get(cOde)

def eNcVr(nUm):
    if nUm < 0:
        return b''
    rEsUlT = []
    while True:
        bYtE = nUm & 0x7F
        nUm >>= 7
        if nUm:
            bYtE |= 0x80
        rEsUlT.append(bYtE)
        if not nUm:
            break
    return bytes(rEsUlT)

def cReAtEvAr(fIeLdNuM, vAl):
    fIeLdHeAdEr = (fIeLdNuM << 3) | 0
    return eNcVr(fIeLdHeAdEr) + eNcVr(vAl)

def cReAtElEnGtH(fIeLdNuM, vAl):
    fIeLdHeAdEr = (fIeLdNuM << 3) | 2
    eNcOdEd = vAl.encode() if isinstance(vAl, str) else vAl
    return eNcVr(fIeLdHeAdEr) + eNcVr(len(eNcOdEd)) + eNcOdEd

def cReAtEpRoTo(fIeLdS):
    pAcKeT = bytearray()
    for fIeLd, vAl in fIeLdS.items():
        if isinstance(vAl, dict):
            nEsTeD = cReAtEpRoTo(vAl)
            pAcKeT.extend(cReAtElEnGtH(fIeLd, nEsTeD))
        elif isinstance(vAl, int):
            pAcKeT.extend(cReAtEvAr(fIeLd, vAl))
        elif isinstance(vAl, (str, bytes)):
            pAcKeT.extend(cReAtElEnGtH(fIeLd, vAl))
    return pAcKeT

def eNcAeS(pLaInTeXt):
    pLaIn = bytes.fromhex(pLaInTeXt)
    kEy = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cIpHeR = AES.new(kEy, AES.MODE_CBC, iV)
    rEsUlT = cIpHeR.encrypt(pad(pLaIn, AES.block_size))
    return bytes.fromhex(rEsUlT.hex())

def eNcApI(pT):
    pT = bytes.fromhex(pT)
    kEy = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cIpHeR = AES.new(kEy, AES.MODE_CBC, iV)
    cT = cIpHeR.encrypt(pad(pT, AES.block_size))
    return cT.hex()

def gEnNaMe(prefix):
    digits = ''.join(str(random.randint(0, 9)) for _ in range(5))
    sup_digits = to_superscript(digits)
    return prefix + sup_digits

def gEnPaSsWoRd(lEn=9):
    cHaRs = string.ascii_letters + string.digits
    rAnD = ''.join(random.choice(cHaRs) for _ in range(lEn)).upper()
    return f"ALINAS_{rAnD}_KING"

def eNcOdEsTr(oRiG):
    kEyStReAm = [
        0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30,
        0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37,
        0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31,
        0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30
    ]
    eNcOdEd = ""
    for i in range(len(oRiG)):
        oRiGbYtE = ord(oRiG[i])
        kEyByTe = kEyStReAm[i % len(kEyStReAm)]
        rEsByTe = oRiGbYtE ^ kEyByTe
        eNcOdEd += chr(rEsByTe)
    return {"open_id": oRiG, "f14": eNcOdEd}

def tOuNiCoDeEsC(sTr):
    return ''.join(c if 32 <= ord(c) <= 126 else f'\\u{ord(c):04x}' for c in sTr)

def pArSeRoOm(iT):
    try:
        data = bytes.fromhex(iT)
        result = {}
        pos = 0
        while pos < len(data):
            tag = data[pos]
            field_num = tag >> 3
            wire_type = tag & 0x07
            pos += 1
            if wire_type == 0:
                value = 0
                shift = 0
                while pos < len(data):
                    byte = data[pos]
                    pos += 1
                    value |= (byte & 0x7F) << shift
                    if not (byte & 0x80):
                        break
                    shift += 7
                result[str(field_num)] = value
            elif wire_type == 2:
                length = 0
                shift = 0
                while pos < len(data):
                    byte = data[pos]
                    pos += 1
                    length |= (byte & 0x7F) << shift
                    if not (byte & 0x80):
                        break
                    shift += 7
                value = data[pos:pos+length]
                pos += length
                result[str(field_num)] = value.hex()
        return json.dumps(result)
    except Exception:
        return None

def cHoOsErEgIoN(dAtA, jWt):
    uRl = "https://loginbp.ggpolarbear.com/ChooseRegion"
    hEaDeRs = {
        'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Content-Type': "application/x-www-form-urlencoded",
        'Expect': "100-continue",
        'Authorization': f"Bearer {jWt}",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB53"
    }
    rEs = requests.post(uRl, data=dAtA, headers=hEaDeRs, verify=False)
    return rEs.status_code

def gEtLoGiNdAtA(jWt, pL, rEg):
    if rEg.lower() == "me":
        uRl = 'https://clientbp.ggpolarbear.com/GetLoginData'
    else:
        lInK = GeTuRl(rEg)
        uRl = f"{lInK}GetLoginData"

    hEaDeRs = {
        'Expect': '100-continue',
        'Authorization': f'Bearer {jWt}',
        'X-Unity-Version': '2018.4.11f1',
        'X-GA': 'v1 1',
        'ReleaseVersion': 'OB53',
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
        'Host': 'clientbp.ggpolarbear.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
    }
    
    mAxTrY = 1
    aTt = 0
    while aTt < mAxTrY:
        try:
            rEs = requests.post(uRl, headers=hEaDeRs, data=pL, verify=False)
            rEs.raise_for_status()
            x = rEs.content.hex()
            jR = pArSeRoOm(x)
            if jR is None:
                return None
            pD = json.loads(jR)
            return pD
        except Exception:
            aTt += 1
            time.sleep(0.5)
    return None

def gEtPaYlOaD(jWt, nAt, dAtE, rEsP, cOdE, nAmE, uId, pAsS, rEg):
    try:
        tPb = jWt.split('.')[1]
        tPb += '=' * ((4 - len(tPb) % 4) % 4)
        dP = base64.urlsafe_b64decode(tPb).decode('utf-8')
        dP = json.loads(dP)
        nEiD = dP['external_id']
        sMd5 = dP['signature_md5']
        
        nOw = datetime.now()
        nOw = str(nOw)[:len(str(nOw)) - 7]
        
        pL = b':\x071.111.2\xaa\x01\x02ar\xb2\x01 55ed759fcf94f85813e57b2ec8492f5c\xba\x01\x014\xea\x01@6fb7fdef8658fd03174ed551e82b71b21db8187fa0612c8eaf1b63aa687f1eae\x9a\x06\x014\xa2\x06\x014'
        pL = pL.replace(b"2023-12-24 04:21:34", str(nOw).encode())
        pL = pL.replace(b"c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94", nAt.encode("UTF-8"))
        pL = pL.replace(b"4306245793de86da425a52caadf21eed", nEiD.encode("UTF-8"))
        pL = pL.replace(b"4306245793de86da425a52caadf21eed", sMd5.encode("UTF-8"))
        
        pHex = pL.hex()
        pEnC = eNcApI(pHex)
        pByTeS = bytes.fromhex(pEnC)
        
        dAtA = gEtLoGiNdAtA(jWt, pByTeS, rEg)
        return {
            "data": dAtA,
            "response": rEsP,
            "status_code": cOdE,
            "name": nAmE,
            "uid": uId,
            "password": pAsS
        }
    except Exception:
        return None

def uSeRlOgIn(uId, pAsS, aT, oId, rEsP, cOdE, nAmE, rEg):
    lAnG = GeTlAnG(rEg)
    lB = lAnG.encode("ascii")
    
    hEaDeRs = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ggpolarbear.com",
        "ReleaseVersion": "OB53",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1"
    }

    pL = b'\x1a\x132025-11-26 01:51:28"\tfree fire(\x01:\x071.123.1B2Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)J\x08HandheldR\x0cMTN/SpacetelZ\x04WIFI`\x80\nh\xd0\x05r\x03240z-x86-64 SSE3 SSE4.1 SSE4.2 AVX AVX2 | 2400 | 4\x80\x01\xe6\x1e\x8a\x01\x0fAdreno (TM) 640\x92\x01\rOpenGL ES 3.2\x9a\x01+Google|625f716f-91a7-495b-9f16-08fe9d3c6533\xa2\x01\x0e176.28.139.185\xaa\x01\x02ar\xb2\x01 4306245793de86da425a52caadf21eed\xba\x01\x014\xc2\x01\x08Handheld\xca\x01\rOnePlus A5010\xea\x01@c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94\xf0\x01\x01\xca\x02\x0cMTN/Spacetel\xd2\x02\x04WIFI\xca\x03 1ac4b80ecf0478a44203bf8fac6120f5\xe0\x03\xb5\xee\x02\xe8\x03\x9a\x80\x02\xf0\x03\xaf\x13\xf8\x03\x84\x07\x80\x04\xa7\x8f\x02\x88\x04\xb5\xee\x02\x90\x04\xa7\x8f\x02\x98\x04\xb5\xee\x02\xb0\x04\x04\xc8\x04\x01\xd2\x04=/data/app/com.dts.freefireth-fpXCSphIV6dKC7jL-WOyRA==/lib/arm\xe0\x04\x01\xea\x04_e62ab9354d8fb5fb081db338acb33491|/data/app/com.dts.freefireth-fpXCSphIV6dKC7jL-WOyRA==/base.apk\xf0\x04\x06\xf8\x04\x01\x8a\x05\x0232\x9a\x05\n2019119026\xa8\x05\x03\xb2\x05\tOpenGLES2\xb8\x05\xff\x01\xc0\x05\x04\xe0\x05\xbe~\xea\x05\t3rd_party\xf2\x05pKqsHT8W93GdcG3ZozENfFwVHtm7qq1eRUNaIDNgRobozIBtLOiYCc4Y6zvvpcICxzQF2sOE4cbytwLs4xZbRnpRMpmWRQKmeO5vcs8nQYBhwqH7K\xf8\x05\xe7\xe4\x06\x88\x06\x01\x90\x06\x01\x9a\x06\x014\xa2\x06\x014\xb2\x06"\x13R\x11FP\x0eY\x03IQ\x0eF\t\x00\x11XC9_\x00[Q\x0fh[V\na\x07Wm\x0f\x03f'
    
    pL = pL.replace(b'c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94', aT.encode())
    pL = pL.replace(b'4306245793de86da425a52caadf21eed', oId.encode())
    
    d = eNcApI(pL.hex())
    fP = bytes.fromhex(d)
    
    if rEg.lower() == "me":
        uRl = "https://loginbp.common.ggbluefox.com/MajorLogin"
    else:
        uRl = "https://loginbp.ggpolarbear.com/MajorLogin"
    
    rEs = requests.post(uRl, headers=hEaDeRs, data=fP, verify=False)
    
    if rEs.status_code == 200:
        if len(rEs.text) < 10:
            return False
        
        if lAnG.lower() not in ["ar", "en"]:
            jR = pArSeRoOm(rEs.content.hex())
            if jR is None:
                return False
            pD = json.loads(jR)
            tOkEn = None
            for key in ['8', 'data']:
                if key in pD:
                    tOkEn = pD[key]
                    break
            if not tOkEn:
                return False
            
            if rEg.lower() == "cis":
                rEg = "RU"
            
            fIeLdS = {1: rEg}
            fByTeS = bytes.fromhex(eNcApI(cReAtEpRoTo(fIeLdS).hex()))
            cR = cHoOsErEgIoN(fByTeS, tOkEn)
            
            if cR == 200:
                return lOgInSeRvEr(uId, pAsS, aT, oId, rEsP, cOdE, nAmE, rEg)
        else:
            tOkEn = rEs.text[rEs.text.find("eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ"):-1]
        
        sDi = tOkEn.find(".", tOkEn.find(".") + 1)
        time.sleep(0.2)
        tOkEn = tOkEn[:sDi + 44]
        return gEtPaYlOaD(tOkEn, aT, 1, rEsP, cOdE, nAmE, uId, pAsS, rEg)
    return False

def lOgInSeRvEr(uId, pAsS, aT, oId, rEsP, cOdE, nAmE, rEg):
    lAnG = GeTlAnG(rEg)
    lB = lAnG.encode("ascii")
    
    hEaDeRs = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ggpolarbear.com",
        "ReleaseVersion": "OB53",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1"
    }

    pL = b'\x1a\x13\x32\x30\x32\x36\x2d\x30\x31\x2d\x31\x34\x20\x31\x35\x3a\x32\x36\x3a\x30\x39\x22\x09\x66\x72\x65\x65\x20\x66\x69\x72\x65\x3a\x07\x31\x2e\x31\x32\x30\x2e\x33\x42\x0a\x69\x4f\x53\x20\x31\x35\x2e\x38\x2e\x32\x4a\x08\x48\x61\x6e\x64\x68\x65\x6c\x64\x65\x64\x52\x0e\x4f\x72\x61\x6e\x67\x65\x20\x54\x75\x6e\x69\x73\x69\x61\x5a\x04\x57\x49\x46\x49\x60\xb6\x0a\x68\xee\x05\x72\x03\x33\x32\x36\x7a\x0d\x61\x72\x6d\x36\x34\x20\x7c\x20\x30\x20\x7c\x20\x32\x80\x01\xd0\x0f\x8a\x01\x0d\x41\x70\x70\x6c\x65\x20\x41\x31\x30\x20\x47\x50\x55\x92\x01\x05\x4d\x65\x74\x61\x6c\x9a\x01\x2a\x41\x70\x70\x6c\x65\x7c\x34\x37\x36\x33\x42\x30\x36\x46\x2d\x31\x41\x46\x42\x2d\x34\x39\x31\x46\x2d\x39\x43\x31\x39\x2d\x37\x46\x43\x46\x38\x42\x38\x30\x39\x32\x33\x30\xa2\x01\x0e\x31\x30\x32\x2e\x31\x35\x32\x2e\x36\x33\x2e\x31\x33\x38\xaa\x01\x05\x67\x70\x74\x2d\x62\x72\xb2\x01\x20\x30\x35\x63\x32\x64\x30\x65\x38\x62\x32\x30\x36\x62\x34\x64\x37\x65\x39\x62\x30\x32\x38\x62\x38\x34\x32\x62\x61\x32\x63\x61\x32\xba\x01\x01\x34\xc2\x01\x08\x48\x61\x6e\x64\x68\x65\x6c\x64\x65\x64\xca\x01\x09\x69\x50\x68\x6f\x6e\x65\x39\x2c\x33\xea\x01\x40\x33\x32\x31\x62\x66\x36\x65\x31\x66\x64\x36\x63\x65\x37\x62\x32\x32\x64\x34\x39\x64\x36\x35\x35\x38\x63\x31\x30\x63\x65\x31\x35\x38\x30\x30\x62\x66\x62\x33\x35\x39\x64\x65\x37\x36\x63\x64\x30\x34\x32\x65\x65\x62\x66\x34\x32\x31\x39\x64\x63\x34\x61\x62\x65\xf0\x01\x01\xf0\x03\xa1\xee\x01\xf8\x03\xbd\x1b\xb0\x04\x02\xc8\x04\x02\xe0\x04\x01\xea\x04\x09\x49\x4f\x53\x44\x65\x76\x69\x63\x65\xf0\x04\x03\xf8\x04\x01\x9a\x05\x07\x31\x2e\x31\x32\x30\x2e\x31\xa8\x05\x03\xb2\x05\x05\x54\x4d\x65\x74\x61\x6c\xb8\x05\xff\x7f\xc0\x05\x04\xe0\x05\xca\xc8\x02\xea\x05\x03\x69\x6f\x73\xf2\x05\x48\x4b\x71\x73\x48\x54\x38\x43\x6a\x38\x69\x6d\x33\x32\x57\x70\x5a\x44\x64\x59\x2f\x6e\x51\x31\x58\x77\x43\x4c\x36\x55\x69\x2f\x32\x37\x48\x6e\x79\x6b\x32\x78\x34\x32\x69\x41\x72\x68\x7a\x64\x61\x30\x75\x4f\x44\x56\x64\x74\x6c\x51\x36\x46\x45\x30\x54\x2f\x52\x49\x7a\x6e\x6c\x70\x41\x3d\x3d\x90\x06\x01\x9a\x06\x01\x34\xa2\x06\x01\x34\xb2\x06\x0e\x60\x00\x17\x12\x72\x13\x59\x58\x21\x54\x5f\x12\x0d\x10\x09\x09\x09\x09\x09\x09\x09\x09\x09'
    
    pL = pL.replace(b'c69ae208fad72738b674b2847b50a3a1dfa25d1a19fae745fc76ac4a0e414c94', aT.encode())
    pL = pL.replace(b'4306245793de86da425a52caadf21eed', oId.encode())
    
    d = eNcApI(pL.hex())
    fP = bytes.fromhex(d)
    
    if rEg.lower() == "me":
        uRl = "https://loginbp.common.ggbluefox.com/MajorLogin"
    else:
        uRl = "https://loginbp.ggpolarbear.com/MajorLogin"
    
    rEs = requests.post(uRl, headers=hEaDeRs, data=fP, verify=False)
    
    if rEs.status_code == 200:
        if len(rEs.text) < 10:
            return False
        
        jR = pArSeRoOm(rEs.content.hex())
        if jR is None:
            return False
        pD = json.loads(jR)
        tOkEn = pD.get('8', pD.get('data', None))
        if not tOkEn:
            return False
        
        sDi = tOkEn.find(".", tOkEn.find(".") + 1)
        time.sleep(0.2)
        tOkEn = tOkEn[:sDi + 44]
        return gEtPaYlOaD(tOkEn, aT, 1, rEsP, cOdE, nAmE, uId, pAsS, rEg)
    return False

def cReAtEaCc(rEg, name_prefix):
    pAsS = gEnPaSsWoRd()
    dAtA = f"password={pAsS}&client_type=2&source=2&app_id=100067"
    mSg = dAtA.encode('utf-8')
    sIg = hmac.new(MaIn_KeY, mSg, hashlib.sha256).hexdigest()

    uRl = "https://100067.connect.garena.com/oauth/guest/register"
    hEaDeRs = {
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 12; M2101K7AG Build/SKQ1.210908.001)",
        "Authorization": "Signature " + sIg,
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive"
    }

    rEsPoNsE = requests.post(uRl, headers=hEaDeRs, data=dAtA)
    try:
        uId = rEsPoNsE.json()['uid']
        return gEtToKeN(uId, pAsS, rEg, name_prefix)
    except:
        return cReAtEaCc(rEg, name_prefix)

def gEtToKeN(uId, pAsS, rEg, name_prefix):
    uRl = "https://100067.connect.garena.com/oauth/guest/token/grant"
    hEaDeRs = {
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
    }

    bOdY = {
        "uid": uId,
        "password": pAsS,
        "response_type": "token",
        "client_type": "2",
        "client_secret": MaIn_KeY,
        "client_id": "100067"
    }

    rEsPoNsE = requests.post(uRl, headers=hEaDeRs, data=bOdY)
    oPeNiD = rEsPoNsE.json()['open_id']
    aCcEsStOkEn = rEsPoNsE.json()["access_token"]
    
    rEs = eNcOdEsTr(oPeNiD)
    fIeLd = tOuNiCoDeEsC(rEs['f14'])
    fIeLd = codecs.decode(fIeLd, 'unicode_escape').encode('latin1')
    return rEgMaJoR(aCcEsStOkEn, oPeNiD, fIeLd, uId, pAsS, rEg, name_prefix)

def rEgMaJoR(aT, oId, f, uId, pAsS, rEg, name_prefix):
    uRl = "https://loginbp.ggpolarbear.com/MajorRegister"
    nAmE = gEnNaMe(name_prefix)

    hEaDeRs = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ggpolarbear.com",
        "ReleaseVersion": "OB53",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1"
    }

    pAyLoAd = {
        1: nAmE,
        2: aT,
        3: oId,
        5: 102000007,
        6: 4,
        7: 1,
        13: 1,
        14: f,
        15: "en",
        16: 1,
        17: 1
    }

    pHex = cReAtEpRoTo(pAyLoAd).hex()
    pEnC = eNcAeS(pHex).hex()
    bOdY = bytes.fromhex(pEnC)

    rEs = requests.post(uRl, headers=hEaDeRs, data=bOdY, verify=False)
    return uSeRlOgIn(uId, pAsS, aT, oId, rEs.content.hex(), rEs.status_code, nAmE, rEg)

def generate_accounts(region, name_prefix, count):
    region = region.upper()
    if region not in ReGiOnMaP:
        raise ValueError("Invalid region")
    if count > MAX_ACCOUNTS:
        raise ValueError(f"Maximum allowed accounts is {MAX_ACCOUNTS}")
    
    accounts = []
    for i in range(count):
        try:
            result = cReAtEaCc(region, name_prefix)
            if result and result.get('status_code') == 200:
                accounts.append({
                    "name": result.get('name'),
                    "uid": result.get('uid'),
                    "password": result.get('password')
                })
            else:
                accounts.append({"error": f"Failed to generate account {i+1}"})
        except Exception as e:
            accounts.append({"error": f"Account {i+1} error: {str(e)}"})
    return accounts

@bot.message_handler(commands=['info'])
@require_membership
def get_player_info(message):
    chat_id = message.chat.id

    if not is_allowed(chat_id):
        return

    args = (message.text or "").split()

    if len(args) != 2:
        return send_with_global_note(
            chat_id,
            "<b>Usage:</b> /info &lt;UID&gt;</b>"
        )

    uid = args[1]

    if not uid.isdigit():
        return send_with_global_note(
            chat_id,
            "<b>⚠️ UID must contain numbers only</b>"
        )

    msg = bot.send_message(
        chat_id,
        "<b>〘 Please wait 〙</b>",
        parse_mode="HTML"
    )

    try:
        url = (
            f"https://api-info-nrml-alinas.vercel.app/"
            f"player-info?uid={uid}&region=ME"
        )

        try:
            res = requests.get(url, timeout=30)

        except requests.exceptions.ConnectionError:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>⚠️ API Connection Failed</b>"
            )

        except requests.exceptions.Timeout:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>⚠️ API Timeout</b>"
            )

        except Exception as req_error:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                f"<b>⚠️ Request Error:</b> {str(req_error)}"
            )

        if res.status_code != 200:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                f"<b>⚠️ API Error : {res.status_code}</b>"
            )

        try:
            data = res.json()

        except Exception:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>⚠️ Invalid API response</b>"
            )

        if not isinstance(data, dict):
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>⚠️ Invalid API data</b>"
            )

        basic = data.get("basicInfo", {})
        clan = data.get("clanBasicInfo", {})
        captain = data.get("captainBasicInfo", {})
        pet = data.get("petInfo", {})
        credit = data.get("creditScoreInfo", {})
        social = data.get("socialInfo", {})

        name = basic.get("nickname", "Unknown")
        region = basic.get("region", "N/A")
        level = basic.get("level", "N/A")
        exp = basic.get("exp", 0)
        likes = basic.get("liked", 0)
        version = basic.get("releaseVersion", "N/A")

        br_rank = basic.get("maxRank", "N/A")
        br_pts = basic.get("rankingPoints", "N/A")
        cs_rank = basic.get("csRank", "N/A")
        cs_pts = basic.get("csRankingPoints", "N/A")
        season = basic.get("seasonId", "N/A")

        clan_name = clan.get("clanName", "No Clan")
        clan_id = clan.get("clanId", "N/A")
        clan_level = clan.get("clanLevel", "N/A")
        clan_mem = f"{clan.get('memberNum', 0)}/{clan.get('maxMemberNum', 0)}"

        leader_name = captain.get("nickname", "N/A")
        leader_uid = captain.get("accountId", "N/A")
        leader_level = captain.get("level", "N/A")
        leader_likes = captain.get("liked", 0)
        leader_region = captain.get("region", "N/A")

        pet_id = pet.get("petId", "N/A")
        pet_level = pet.get("level", "N/A")
        pet_exp = pet.get("exp", 0)
        skill_id = pet.get("selectedSkillId", "N/A")

        score = credit.get("score", "N/A")
        reward = credit.get("status", "REWARD_STATE_UNCLAIMED")

        gender = social.get("gender", "Unknown")
        lang = social.get("language", "Unknown")
        signature = social.get("signature", "No Signature")

        text = (
            "<b>ACCOUNT INFO</b>\n\n"

            f"Player : => {name}\n"
            f"UID : => {uid}\n"
            f"Region : => {region}\n"
            f"Level : => {level} | EXP : => {exp}\n"
            f"Likes : => {likes}\n"
            f"Version : => {version}\n\n"

            "<b>RANK INFO</b>\n"
            f"• BR Rank : => {br_rank} | => {br_pts} pts\n"
            f"• CS Rank : => {cs_rank} | => {cs_pts} pts\n"
            f"• Season : => {season}\n\n"

            "<b>CLAN INFO</b>\n"
            f"• Name : => {clan_name}\n"
            f"• ID : => {clan_id}\n"
            f"• Level : => {clan_level}\n"
            f"• Members : => {clan_mem}\n\n"

            "<b>LEADER INFO</b>\n"
            f"• Nickname : => {leader_name}\n"
            f"• UID : => {leader_uid}\n"
            f"• Level : => {leader_level}\n"
            f"• Likes : => {leader_likes}\n"
            f"• Region : => {leader_region}\n\n"

            "<b>PET INFO</b>\n"
            f"• Pet ID : => {pet_id}\n"
            f"• Level : => {pet_level}\n"
            f"• EXP : => {pet_exp}\n"
            f"• Skill ID : => {skill_id}\n\n"

            "<b>CREDIT SCORE</b>\n"
            f"• Score : => {score}\n"
            f"• Reward : => {reward}\n\n"

            "<b>SOCIAL INFO</b>\n"
            f"• Gender : => {gender}\n"
            f"• Language : => {lang}\n"
            f"• Signature : => \"{signature}\"\n\n"

            "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>"
        )

        try:
            bot.delete_message(chat_id, msg.message_id)
        except:
            pass

        send_with_global_note(chat_id, text)

    except Exception as e:
        try:
            bot.delete_message(chat_id, msg.message_id)
        except:
            pass

        send_with_global_note(
            chat_id,
            f"<b>⚠️ Error:</b> {str(e)}"
        )


@bot.message_handler(commands=['id', 'ID'])
def cmd_id(message):
    try:
        user = message.from_user
        chat = message.chat
        txt = []

        name = f"{user.first_name or ''} {user.last_name or ''}".strip()

        txt.append(f"👤 𝗬𝗢𝗨𝗥  𝗡𝗔𝗠𝗘: {escape_md(name)}")

        if user.username:
            txt.append(f"🔗 𝗬𝗢𝗨𝗥  𝗨𝗦𝗘𝗥: @{escape_md(user.username)}")

        txt.append(f"🆔 𝗬𝗢𝗨𝗥  𝗜𝗗: `{user.id}`")
        txt.append(f"💬 𝗚𝗥𝗢𝗨𝗣  𝗜𝗗: `{chat.id}`")

        if message.reply_to_message and message.reply_to_message.from_user:
            u = message.reply_to_message.from_user
            r_name = f"{u.first_name or ''} {u.last_name or ''}".strip()

            txt.append(f"↩️ بترد على: {escape_md(r_name)}")

            if u.username:
                txt.append(f"🔗 @{escape_md(u.username)}")

            txt.append(f"🆔 `{u.id}`")

        bot.send_message(
            chat.id,   # ✔️ FIX هنا
            "\n".join(txt),
            parse_mode="MarkdownV2",
            disable_web_page_preview=True
        )

    except Exception as e:
        print("cmd_id ERROR:", e)
    
HEX_64_REGEX = re.compile(r"^[a-fA-F0-9]{64}$")

CREDITS = "@xAlInAs_sAnIlAx"
OWNER = "𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮"

@bot.message_handler(commands=['ban', 'BAN'])
@require_membership
def ban_account(message):
    try:
        if not is_allowed(message.chat.id):
            return

        args = (message.text or "").split()

        if len(args) != 2:
            return bot.reply_to(
                message,
                "<pre>USAGE : /ban access_token</pre>",
                parse_mode="HTML"
            )

        access_token = args[1]

        # ✔️ حماية regex
        if not HEX_64_REGEX or not HEX_64_REGEX.fullmatch(access_token):
            err = random.choice(["3SBA", "LOL", "NIKOMK"])
            return bot.reply_to(
                message,
                f"<pre>{{\"error\":\"{err}\",\"CREDITS\":\"{CREDITS}\",\"OWNER\":\"{OWNER}\"}}</pre>",
                parse_mode="HTML"
            )

        ban_url = f"http://78.109.17.4:5000/ff_ban?access_token={access_token}"

        wait_msg = bot.send_message(
            message.chat.id,
            "<b>Please wait...</b>",
            parse_mode="HTML"
        )

        try:
            res = requests.get(ban_url, timeout=60)

            raw_text = res.text or ""

            try:
                api_json = json.loads(raw_text)
            except:
                api_json = {"error": raw_text}

            api_json["CREDITS"] = CREDITS
            api_json["OWNER"] = OWNER

            formatted = json.dumps(api_json, indent=2, ensure_ascii=False)

            try:
                bot.delete_message(message.chat.id, wait_msg.message_id)
            except:
                pass

            send_with_global_note(
                message.chat.id,
                f"<pre>{formatted}</pre>"
            )

        except Exception:
            try:
                bot.delete_message(message.chat.id, wait_msg.message_id)
            except:
                pass

            error_json = {
                "error": "API_FAILED",
                "CREDITS": CREDITS,
                "OWNER": OWNER
            }

            send_with_global_note(
                message.chat.id,
                f"<pre>{json.dumps(error_json, indent=2, ensure_ascii=False)}</pre>"
            )

    except Exception as e:
        print("ban_account ERROR:", e)
        

def get_token(uid, password):
    try:
        url = "https://100067.connect.garena.com/oauth/guest/token/grant"

        headers = {
            "User-Agent": "GarenaMSDK/4.0.19P8(Android 12)",
            "Content-Type": "application/x-www-form-urlencoded"
        }

        data = {
            "uid": str(uid),
            "password": str(password),
            "response_type": "token",
            "client_type": "2",
            "client_id": "100067",
            "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
        }

        r = requests.post(url, headers=headers, data=data, timeout=15)

        if r.status_code != 200:
            return {"error": "HTTP_ERROR", "status": r.status_code, "body": r.text}

        try:
            return r.json()
        except:
            return {"error": "INVALID_JSON", "body": r.text}

    except Exception as e:
        return {"error": "REQUEST_FAILED", "details": str(e)}

@bot.message_handler(commands=['geban'])
@require_membership
def geban_account(message):
    try:
        if not is_allowed(message.chat.id):
            return

        args = (message.text or "").split()

        if len(args) != 2 or ":" not in args[1]:
            return bot.reply_to(
                message,
                "<pre>USAGE : /geban uid:password</pre>",
                parse_mode="HTML"
            )

        uid, password = args[1].split(":", 1)

        token_resp = get_token(uid, password)

        # ✔️ حماية نوع الرد
        if not isinstance(token_resp, dict) or "access_token" not in token_resp:
            token_resp = token_resp if isinstance(token_resp, dict) else {"error": str(token_resp)}

            token_resp["CREDITS"] = CREDITS
            token_resp["OWNER"] = OWNER

            formatted = json.dumps(token_resp, indent=2, ensure_ascii=False)
            return send_with_global_note(message.chat.id, f"<pre>{formatted}</pre>")

        access_token = token_resp["access_token"]

        # ✔️ حماية regex + None
        if not access_token or not HEX_64_REGEX or not HEX_64_REGEX.fullmatch(access_token):
            err = random.choice(["3SBA", "LOL", "NIKOMK"])
            return send_with_global_note(
                message.chat.id,
                f"<pre>{{\"error\":\"{err}\",\"CREDITS\":\"{CREDITS}\",\"OWNER\":\"{OWNER}\"}}</pre>"
            )

        ban_url = f"http://78.109.17.4:5000/ff_ban?access_token={access_token}"

        wait_msg = bot.send_message(
            message.chat.id,
            "<b>Please wait...</b>",
            parse_mode="HTML"
        )

        try:
            res = requests.get(ban_url, timeout=60)

            raw_text = res.text or ""

            try:
                api_json = json.loads(raw_text)
            except:
                api_json = {"error": raw_text}

            try:
                bot.delete_message(message.chat.id, wait_msg.message_id)
            except:
                pass

            api_json["CREDITS"] = CREDITS
            api_json["OWNER"] = OWNER

            formatted = json.dumps(api_json, indent=2, ensure_ascii=False)

            send_with_global_note(message.chat.id, f"<pre>{formatted}</pre>")

        except Exception:
            try:
                bot.delete_message(message.chat.id, wait_msg.message_id)
            except:
                pass

            error_json = {
                "error": "API_FAILED",
                "CREDITS": CREDITS,
                "OWNER": OWNER
            }

            send_with_global_note(
                message.chat.id,
                f"<pre>{json.dumps(error_json, indent=2, ensure_ascii=False)}</pre>"
            )

    except Exception as e:
        print("geban_account ERROR:", e)
        
        
@bot.message_handler(commands=['gen', 'GEN'])
@require_membership
def gen_command(message):
    try:
        chat_id = message.chat.id

        if not is_allowed(chat_id):
            return

        args = (message.text or "").split()

        if len(args) != 4:
            return send_with_global_note(
                chat_id,
                "<b>Usage:</b>\n<code>/gen ME ALINAS 15</code>"
            )

        region = args[1].upper()
        name = args[2]

        try:
            count = int(args[3])
            if count <= 0:
                raise ValueError
        except ValueError:
            return send_with_global_note(
                chat_id,
                "❌ العدد يجب أن يكون رقماً صحيحاً."
            )

        if count > MAX_ACCOUNTS:
            return send_with_global_note(
                chat_id,
                f"❌ MAX {MAX_ACCOUNTS} ACCOUNTS."
            )

        # رسالة انتظار
        msg = bot.send_message(
            chat_id,
            "<b>〘 Generating accounts, please wait 〙</b>",
            parse_mode="HTML"
        )

        try:
            accounts = generate_accounts(region, name, count)

            json_data = json.dumps(accounts, indent=2, ensure_ascii=False)

            file = io.BytesIO(json_data.encode("utf-8"))
            file.name = f"{name}.json"
            file.seek(0)

            username = message.from_user.username or "unknown"

            caption_text = (
                "<b>Generation Complete ✅</b>\n\n"
                f"<b>Count:</b> {count}\n"
                f"<b>Region:</b> {region}\n"
                f"<b>By:</b> @{username}\n\n"
                "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>\n\n"
            )

            # حذف رسالة الانتظار
            try:
                bot.delete_message(chat_id, msg.message_id)
            except Exception as e:
                print("DELETE ERROR:", e)

            bot.send_document(
                chat_id=chat_id,
                document=file,
                caption=caption_text,
                parse_mode="HTML"
            )

        except Exception as e:
            err = str(e).replace("<", "").replace(">", "")

            try:
                bot.delete_message(chat_id, msg.message_id)
            except Exception:
                pass

            send_with_global_note(
                chat_id,
                f"❌ خطأ: {err}"
            )

    except Exception as e:
        print("gen_command ERROR:", e)

@bot.message_handler(commands=['ghost'])
@require_membership
def handle_xrrr(message):
    try:
        chat_id = message.chat.id

        if not is_allowed(chat_id):
            return

        parts = (message.text or "").split()

        if len(parts) < 3:
            bot.reply_to(
                message,
                "<b>❗ Usage:</b>\n<b>/ghost &lt;team code&gt; &lt;name&gt;</b>",
                parse_mode="HTML"
            )
            return

        teamcode = parts[1].strip()
        name = " ".join(parts[2:]).strip()

        if not teamcode.isdigit() or len(teamcode) != 7:
            bot.reply_to(
                message,
                "<b>❌ Team code must be 7 digits</b>",
                parse_mode="HTML"
            )
            return

        wait_msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait... 〙</b>",
            parse_mode="HTML"
        )

        def _task():
            try:
                api_url = (
                    f"http://127.0.0.1:6002/ghost"
                    f"?teamcode={teamcode}"
                    f"&name={requests.utils.quote(name)}"
                    f"&api_key=ALINAS"
                )

                response = requests.get(api_url, timeout=60)

                try:
                    data = response.json()
                except:
                    bot.edit_message_text(
                        "<b>❌ Invalid API Response</b>",
                        chat_id,
                        wait_msg.message_id,
                        parse_mode="HTML"
                    )
                    return

                message_text = data.get("message", "Unknown")
                status = data.get("status", "success")

                if status == "error":
                    bot.edit_message_text(
                        f"<b>❌ {message_text}</b>",
                        chat_id,
                        wait_msg.message_id,
                        parse_mode="HTML"
                    )
                    return

                reply_msg = f"""
<pre>
ATTACK STATUS => SUCCESS

TEAM CODE     => {teamcode}

NAME          => {name}

ACCOUNTS USED => 3

SUCCESS COUNT => 3

MESSAGE       => Ghost successfully
</pre>
"""

                bot.edit_message_text(
                    reply_msg,
                    chat_id,
                    wait_msg.message_id,
                    parse_mode="HTML"
                )

            except requests.exceptions.RequestException:
                try:
                    bot.edit_message_text(
                        "<b>❌ API Request Failed</b>",
                        chat_id,
                        wait_msg.message_id,
                        parse_mode="HTML"
                    )
                except:
                    pass

            except Exception as e:
                print("ghost error:", e)
                try:
                    bot.edit_message_text(
                        "<b>❌ Unexpected Error</b>",
                        chat_id,
                        wait_msg.message_id,
                        parse_mode="HTML"
                    )
                except:
                    pass

        import threading
        threading.Thread(target=_task, daemon=True).start()

    except Exception as e:
        print("handle_xrrr ERROR:", e)
   
@bot.message_handler(commands=['spam'])
@require_membership
def handle_spam(message):
    chat_id = None
    wait_msg = None

    try:
        chat_id = message.chat.id
        user_id = message.from_user.id

        if not is_allowed(chat_id):
            return

        # ---------------- LIMIT SYSTEM ----------------
        now = time.time()

        if user_id not in spam_usage:
            spam_usage[user_id] = {
                "count": 0,
                "reset_time": now + SPAM_COOLDOWN
            }

        user_data = spam_usage[user_id]

        # إذا مرّت 24 ساعة نصفر العداد
        if now > user_data["reset_time"]:
            user_data["count"] = 0
            user_data["reset_time"] = now + SPAM_COOLDOWN

        # إذا وصل الحد
        if user_data["count"] >= MAX_SPAM_PER_DAY:
            remaining = int(user_data["reset_time"] - now)

            hours = remaining // 3600
            minutes = (remaining % 3600) // 60

            return bot.reply_to(
                message,
                f"<b>لقد استخدمت الحد اليومي ({MAX_SPAM_PER_DAY} مرات).</b>\n"
                f"<b>حاول مجدداً بعد:</b> {hours} ساعة و {minutes} دقيقة",
                parse_mode="HTML"
            )

        # زيادة العداد
        user_data["count"] += 1

        # ------------------------------------------------

        parts = (message.text or "").split()

        if len(parts) < 2:
            return bot.reply_to(
                message,
                "<b>/spam &lt;UID&gt;</b>",
                parse_mode="HTML"
            )

        uid = parts[1].strip()

        wait_msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait... 〙</b>",
            parse_mode="HTML"
        )

        # ----------------- SPAM API -----------------
        success = 0
        failed = 0
        total_accounts = 0

        try:
            spam_url = (
                f"https://api-request-spam-alinas.vercel.app/"
                f"spam?uid={uid}"
            )

            spam_res = requests.get(spam_url, timeout=60)
            spam_res.raise_for_status()

            try:
                spam_data = spam_res.json()
            except:
                spam_data = {}

            success = spam_data.get("success", 0)
            failed = spam_data.get("failed", 0)
            total_accounts = spam_data.get("total_accounts_available", 0)

        except Exception:
            success = 0
            failed = 0
            total_accounts = 0

        time.sleep(2)

        # ----------------- INFO API -----------------
        def fetch_info(uid, retries=3, delay=3):
            url = f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME"

            for _ in range(retries):
                try:
                    res = requests.get(url, timeout=10)
                    res.raise_for_status()

                    try:
                        data = res.json()
                    except:
                        continue

                    if data.get("basicInfo"):
                        return data

                except Exception:
                    time.sleep(delay)

            return {}

        info_data = fetch_info(uid)

        basic = info_data.get("basicInfo", {})

        nickname = basic.get("nickname", "Unknown")
        region = basic.get("region", "ME")
        level = basic.get("level", "Unknown")

        # ----------------- CAPTION -----------------
        caption = f"""
<b>Friend Request Result</b>

<b>Target:</b> {nickname}
<b>Level:</b> {level}

<b>UID:</b> {uid}
<b>Region:</b> {region}

<b>Success:</b> {success}
<b>Failed:</b> {failed}
<b>Total Accounts:</b> {total_accounts}

<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>
"""

        send_with_global_note(
            chat_id,
            caption,
            wait_msg.message_id
        )

    except Exception as e:
        try:
            if wait_msg:
                bot.delete_message(chat_id, wait_msg.message_id)
        except:
            pass

        bot.send_message(
            chat_id,
            f"<b>حدث خطأ أثناء تنفيذ الأمر</b>\n{e}",
            parse_mode="HTML"
        )
        
@bot.message_handler(commands=['check'])
@require_membership
def handle_check_ban(message):
    wait_msg = None

    try:
        chat_id = message.chat.id

        if not is_allowed(chat_id):
            return

        parts = (message.text or "").split()

        if len(parts) < 2 or not parts[1].isdigit():
            return send_with_global_note(
                chat_id,
                "<b>Usage: /check &lt;UID&gt;</b>"
            )

        uid = parts[1].strip()

        # رسالة الانتظار
        wait_msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        name = "Unknown"
        region = "ME"
        status_msg = "<b>Status Unknown</b>"

        try:
            info_url = f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME"
            res_info = requests.get(info_url, timeout=20)

            if res_info.status_code == 200:
                try:
                    data_info = res_info.json()
                except Exception:
                    data_info = {}

                basic_info = data_info.get("basicInfo", {}) or {}
                credit_info = data_info.get("creditScoreInfo", {}) or {}

                raw_name = basic_info.get("nickname", "Unknown")
                region = basic_info.get("region", "ME")

                try:
                    name = raw_name.encode("latin1").decode("utf-8")
                except Exception:
                    name = raw_name

                credit_status = credit_info.get("status", 1)

                if str(credit_status) == "1":
                    status_msg = "<b>Not Banned</b>"
                else:
                    status_msg = "<b>BANNED</b>"

        except Exception as e:
            print("INFO API ERROR:", e)

        reply_msg = (
            f"<b>Player Ban Check\n"
            f"------------------------\n"
            f"Name: {name}\n"
            f"Region: {region}\n"
            f"UID: {uid}\n"
            f"{status_msg}\n"
            f"------------------------\n"
            f"<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a></b>"
        )

        send_with_global_note(
            chat_id,
            reply_msg,
            wait_msg.message_id
        )

    except Exception as e:
        print("CHECK COMMAND ERROR:", e)

        try:
            send_with_global_note(
                chat_id,
                "<b>HMMM</b>",
                wait_msg.message_id if wait_msg else None
            )
        except Exception as send_error:
            print("SEND ERROR:", send_error)

cooldown_team = {}

@bot.message_handler(commands=['3', '4', '5', '6'])
@require_membership
def handle_create_team(message):
    try:
        chat_id = message.chat.id
        user_id = message.from_user.id

        if not is_allowed(chat_id):
            return

        team_size = (message.text or "").split()[0].replace("/", "")

        now = time.time()
        last_used = cooldown_team.get(user_id, 0)

        if now - last_used < 5:
            remaining = int(5 - (now - last_used))
            return bot.reply_to(
                message,
                f"<b>انتظر {remaining} ثانية قبل استخدام الأمر مرة أخرى</b>",
                parse_mode="HTML"
            )

        cooldown_team[user_id] = now

        parts = (message.text or "").split()

        if len(parts) < 2:
            return bot.reply_to(
                message,
                f"<b>/{team_size} &lt;UID&gt;</b>",
                parse_mode="HTML"
            )

        uid = parts[1].strip()

        wait_msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        # =========================
        # 1) إنشاء التيم
        # =========================
        try:
            create_url = f"http://fr3.spaceify.eu:25620/squad/create?size={team_size}&uids={uid}"
            create_res = requests.get(create_url, timeout=30)
            create_res.raise_for_status()

            try:
                create_data = create_res.json()
            except:
                create_data = {}

        except Exception:
            create_data = {}

        # مهم جداً:
        # الـ API يرجع success:true وليس status:success
        if not create_data.get("success"):
            caption = """
<b>@xAlInAs_sAnIlAx</b>

⚠️ فشل إنشاء التيم
"""
            return send_with_global_note(
                chat_id,
                caption,
                wait_msg.message_id
            )

        # =========================
        # 2) جلب معلومات اللاعب
        # =========================
        player_name = "Unknown"
        player_level = "Unknown"

        try:
            info_url = f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME"
            info_res = requests.get(info_url, timeout=20)
            info_res.raise_for_status()

            try:
                info_data = info_res.json()
            except:
                info_data = {}

            # البيانات داخل basicInfo
            basic_info = info_data.get("basicInfo", {})

            player_name = (
                basic_info.get("nickname")
                or basic_info.get("name")
                or info_data.get("name")
                or "Unknown"
            )

            player_level = (
                basic_info.get("level")
                or info_data.get("level")
                or "Unknown"
            )

        except Exception:
            pass

        # =========================
        # 3) الرسالة النهائية
        # =========================
        caption = f"""
<b>TEAM CREATED SUCCESSFULLY ✅</b>

<b>TEAM SIZE :</b> {team_size}

<b>UID :</b> {uid}

<b>NAME :</b> {player_name}

<b>LEVEL :</b> {player_level}

<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>
"""

        send_with_global_note(
            chat_id,
            caption,
            wait_msg.message_id
        )

    except Exception as e:
        try:
            bot.delete_message(chat_id, wait_msg.message_id)
        except:
            pass

        bot.send_message(
            chat_id,
            f"<b>حدث خطأ أثناء تنفيذ الأمر</b>\n{e}",
            parse_mode="HTML"
        )
            
@bot.message_handler(commands=['level'])
@require_membership
def level_cmd(message):
    try:
        args = (message.text or "").split()

        if len(args) < 2:
            return bot.reply_to(message, "❌ Usage: /level UID")

        uid = args[1]

        if not uid.isdigit():
            return bot.reply_to(
                message,
                "❌ UID must contain numbers only"
            )

        msg = bot.send_message(
            message.chat.id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        try:
            res = requests.get(
                f"{API_URL}?uid={uid}",
                timeout=15
            )

        except requests.exceptions.ConnectionError:
            return bot.edit_message_text(
                "❌ API connection failed",
                message.chat.id,
                msg.message_id
            )

        except requests.exceptions.Timeout:
            return bot.edit_message_text(
                "❌ API timeout",
                message.chat.id,
                msg.message_id
            )

        except Exception:
            return bot.edit_message_text(
                "❌ API request failed",
                message.chat.id,
                msg.message_id
            )

        if res.status_code != 200:
            return bot.edit_message_text(
                f"❌ API error : {res.status_code}",
                message.chat.id,
                msg.message_id
            )

        try:
            data = res.json()
        except Exception:
            data = {}

        basic = data.get("basicInfo", {}) or {}

        uid = basic.get("accountId", uid)
        name = basic.get("nickname", "Unknown")
        region = basic.get("region", "Unknown")
        level = basic.get("level", 0)
        exp = basic.get("exp", 0)

        percent, bar, next_exp = format_bar(exp, level)

        text = f"""
ACCOUNT ID =>  {uid}

NICKNAME   =>  {name}

REGION     =>  {region}

LEVEL      =>  {level}

XP         =>  {exp:,} / {next_exp:,}

[{bar}] {percent}%

<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>
"""

        try:
            bot.delete_message(message.chat.id, msg.message_id)
        except:
            pass

        send_with_global_note(
            message.chat.id,
            text
        )

    except Exception as e:
        try:
            bot.send_message(
                message.chat.id,
                f"⚠️ Error: {str(e)}"
            )
        except:
            pass

@bot.message_handler(commands=['ser', 'SER'])
@require_membership
def search_player_handler(message):
    try:
        chat_id = message.chat.id

        if not is_allowed(chat_id):
            return

        args = (message.text or "").split(maxsplit=1)

        if len(args) != 2:
            return send_with_global_note(
                chat_id,
                "<b>USAGE:</b> /ser NAME"
            )

        nickname = args[1].strip()

        msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        api_url = (
            f"https://api-search-name-by-alinas.vercel.app/"
            f"search?nickname={nickname}&key=ALINAS&region=ME"
        )

        try:
            response = requests.get(api_url, timeout=15)
        except Exception:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>API ERROR:</b> Request failed."
            )

        if response.status_code != 200:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>API ERROR:</b> Failed to fetch data."
            )

        try:
            data = response.json()
        except Exception:
            data = {}

        players = data.get("players", []) or []

        if not players:
            try:
                bot.delete_message(chat_id, msg.message_id)
            except:
                pass

            return send_with_global_note(
                chat_id,
                "<b>NO PLAYERS FOUND</b>"
            )

        result = "<b>LOOK :</b>\n\n"

        for player in players:
            account_id = player.get("accountId", "Unknown")

            nickname_text = str(
                player.get("nickname", "Unknown")
            ).replace("\t", "").replace("\r", "")

            level = player.get("level", "Unknown")
            region = player.get("countryCode", "Unknown")
            last_login = player.get("lastLogin", "Unknown")

            result += (
                f"<b>ID:</b> <code>{account_id}</code>\n"
                f"<b>Nickname:</b> {nickname_text}\n"
                f"<b>Level:</b> {level}\n"
                f"<b>Region:</b> {region}\n"
                f"<b>Last Login:</b> {last_login}\n"
                "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>\n"
                f"----------------------\n"
            )

        result += "\n<b>AlInAs ™</b>"

        try:
            bot.delete_message(chat_id, msg.message_id)
        except:
            pass

        if len(result) > 4000:
            for i in range(0, len(result), 4000):
                send_with_global_note(chat_id, result[i:i + 4000])
        else:
            send_with_global_note(chat_id, result)

    except Exception as e:
        try:
            bot.delete_message(chat_id, msg.message_id)
        except:
            pass

        send_with_global_note(
            chat_id,
            f"<b>ERROR:</b> {str(e)}"
        )


UID_REGEX = re.compile(r"^\d+$")

@bot.message_handler(commands=['wish', 'WISH'])
@require_membership
def wish_handler(message):
    chat_id = message.chat.id

    if not is_allowed(chat_id):
        return

    args = message.text.split()
    if len(args) != 2:
        return bot.reply_to(
            message,
            "<b>USAGE : /wish UID</b>",
            parse_mode="HTML"
        )

    uid = args[1]

    if not UID_REGEX.fullmatch(uid):
        return bot.reply_to(
            message,
            "<b>{\"error\":\"INVALID_UID\"}</b>",
            parse_mode="HTML"
        )

    api_url = f"http://78.109.17.4:50085/wish?uid={uid}"

    wait_msg = bot.send_message(
        chat_id,
        "<b>Please wait...</b>",
        parse_mode="HTML"
    )

    temp_dir = f"wishlist_{uid}"
    zip_path = f"{uid}_wishlist.zip"

    try:
        res = requests.get(api_url, timeout=60)

        # حماية من JSON crash
        try:
            data = res.json()
        except Exception:
            data = {}

        if "wishlist" not in data:
            try:
                bot.delete_message(chat_id, wait_msg.message_id)
            except:
                pass

            return bot.send_message(
                chat_id,
                f"<b>{json.dumps(data, indent=2, ensure_ascii=False)}</b>",
                parse_mode="HTML"
            )

        wishlist = data.get("wishlist", [])

        if not wishlist:
            try:
                bot.delete_message(chat_id, wait_msg.message_id)
            except:
                pass

            return bot.send_message(
                chat_id,
                "<b>{\"error\":\"EMPTY_WISHLIST\"}</b>",
                parse_mode="HTML"
            )

        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.mkdir(temp_dir)

        for item in wishlist:
            item_id = item.get("item_id")
            if not item_id:
                continue

            img_url = f"https://cdn.jsdelivr.net/gh/ShahGCreator/icon@main/PNG/{item_id}.png"
            img_path = os.path.join(temp_dir, f"{item_id}.png")

            try:
                img_res = requests.get(img_url, timeout=30)
                if img_res.status_code == 200:
                    with open(img_path, "wb") as f:
                        f.write(img_res.content)
            except:
                pass

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for file in os.listdir(temp_dir):
                zipf.write(os.path.join(temp_dir, file), arcname=file)

        try:
            bot.delete_message(chat_id, wait_msg.message_id)
        except:
            pass

        with open(zip_path, "rb") as f:
            bot.send_document(
                chat_id,
                f,
                caption=f"<b>{uid}_wishlist</b>",
                parse_mode="HTML"
            )

    except Exception as e:
        try:
            bot.delete_message(chat_id, wait_msg.message_id)
        except:
            pass

        bot.send_message(
            chat_id,
            "<b>{\"error\":\"API_FAILED\"}</b>",
            parse_mode="HTML"
        )

    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        if os.path.exists(zip_path):
            os.remove(zip_path)

@bot.message_handler(commands=["dance", "emote", "dnc"])
@require_membership
def dance_command(message):
    chat_id = message.chat.id

    if not is_allowed(chat_id):
        return

    parts = message.text.split()

    if len(parts) < 4:
        return bot.reply_to(
            message,
            "<b>⚠️ INVALID FORMAT</b>\n"
            "<b>USAGE:</b> /dance [TEAMCODE] [UID1] [UID2..UID5] [EMOTE_ID]</b>\n"
            "<b>EXAMPLE:</b> /dance 8091182 7669969208 909000012",
            parse_mode="HTML"
        )

    team_code = parts[1]
    emote_id = parts[-1]
    target_uids = parts[2:-1]

    if len(target_uids) > 5:
        return bot.reply_to(
            message,
            "<b>❌ MAXIMUM 5 UIDs ALLOWED</b>",
            parse_mode="HTML"
        )

    emote_info = EMOTES_DATA.get(emote_id, {})
    emote_name = emote_info.get("emote_name", "Unknown Emote")
    emote_image = emote_info.get("emote_image_url")

    status_msg = bot.reply_to(
        message,
        f"<b>💃 STARTING DANCE EMOTE...</b>\n"
        f"<b>TEAM:</b> <code>{team_code}</code>\n"
        f"<b>EMOTE:</b> <code>{emote_id}</code>\n"
        f"<b>TARGETS:</b> <code>{len(target_uids)}</code>",
        parse_mode="HTML"
    )

    try:
        api_url = "http://127.0.0.1:10000/join"

        params = {
            "tc": team_code,
            "emote_id": emote_id
        }

        for i, uid in enumerate(target_uids, start=1):
            params[f"uid{i}"] = uid

        response = requests.get(
            api_url,
            params=params,
            timeout=15
        )

        print("STATUS:", response.status_code)
        print("TEXT:", response.text)

        if response.status_code != 200:
            raise Exception(
                f"SERVER RETURNED {response.status_code}"
            )

        data = response.json()

        if data.get("status") != "success":
            raise Exception(
                data.get("message", "Unknown API Error")
            )

        success_uids = data.get("uids", [])

        # جلب أسماء اللاعبين
        players_text = ""

        for i, uid in enumerate(success_uids, start=1):

            try:
                info = requests.get(
                    f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=me",
                    timeout=10
                ).json()

                nickname = (
                    info.get("basicInfo", {})
                    .get("nickname", "Unknown")
                )

            except:
                nickname = "Unknown"

            players_text += f"{i}. {nickname}\n"

        # حذف رسالة الحالة
        try:
            bot.delete_message(
                chat_id=status_msg.chat.id,
                message_id=status_msg.message_id
            )
        except:
            pass

        # إرسال النتيجة النهائية
        bot.send_photo(
            chat_id=message.chat.id,
            photo=emote_image if emote_image else "https://i.imgur.com/8p0XKQh.png",
            caption=(
                f"<b>🎭 /DANCE EMOTE EXECUTED</b>\n\n"

                f"<b>TEAM CODE:</b> <code>{team_code}</code>\n"
                f"<b>EMOTE ID:</b> <code>{emote_id}</code>\n"
                f"<b>TARGET COUNT:</b> <code>{len(success_uids)}</code>\n\n"

                f"<b>PLAYERS:</b>\n"
                f"{players_text}\n"

                f"<b>STATUS:</b> <code>SUCCESS</code>"
            ),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "EMOTES ID",
                        callback_data="emotes_list"
                    )
                ]
            ])
        )

    except requests.exceptions.ConnectTimeout:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text="<b>❌ CONNECTION TIMEOUT</b>",
            parse_mode="HTML"
        )

    except requests.exceptions.ConnectionError:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text=(
                "<b>❌ API OFFLINE</b>\n"
                "<b>SERVER:</b> 127.0.0.1:5000"
            ),
            parse_mode="HTML"
        )

    except Exception as e:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text=(
                f"<b>❌ EMOTE FAILED</b>\n"
                f"<b>ERROR:</b> {str(e)[:200]}"
            ),
            parse_mode="HTML"
        )

@bot.message_handler(commands=["evo"])
@require_membership
def evo_command(message):
    chat_id = message.chat.id

    if not is_allowed(chat_id):
        return

    parts = message.text.split()

    if len(parts) < 3:
        return bot.reply_to(
            message,
            "<b>⚠️ INVALID FORMAT</b>\n"
            "<b>USAGE:</b> /evo [TEAMCODE] [UID1] [UID2..UID5]</b>\n"
            "<b>EXAMPLE:</b> /evo 8091182 7669969208",
            parse_mode="HTML"
        )

    team_code = parts[1]
    target_uids = parts[2:]

    if len(target_uids) > 5:
        return bot.reply_to(
            message,
            "<b>❌ MAXIMUM 5 UIDs ALLOWED</b>",
            parse_mode="HTML"
        )

    # اختيار ايموت عشوائي
    emote_id = str(random.choice(get_random_emotes()))

    emote_info = EMOTES_DATA.get(emote_id, {})
    emote_name = emote_info.get("emote_name", "Unknown Emote")
    emote_image = emote_info.get("emote_image_url")

    status_msg = bot.reply_to(
        message,
        f"<b>🌀 STARTING EVO EMOTE...</b>\n"
        f"<b>TEAM:</b> <code>{team_code}</code>\n"
        f"<b>RANDOM EMOTE:</b> <code>{emote_id}</code>\n"
        f"<b>TARGETS:</b> <code>{len(target_uids)}</code>",
        parse_mode="HTML"
    )

    try:
        api_url = "http://127.0.0.1:10000/join"

        params = {
            "tc": team_code,
            "emote_id": emote_id
        }

        for i, uid in enumerate(target_uids, start=1):
            params[f"uid{i}"] = uid

        response = requests.get(
            api_url,
            params=params,
            timeout=15
        )

        print("STATUS:", response.status_code)
        print("TEXT:", response.text)

        if response.status_code != 200:
            raise Exception(
                f"SERVER RETURNED {response.status_code}"
            )

        data = response.json()

        if data.get("status") != "success":
            raise Exception(
                data.get("message", "Unknown API Error")
            )

        success_uids = data.get("uids", [])

        # جلب أسماء اللاعبين
        players_text = ""

        for i, uid in enumerate(success_uids, start=1):

            try:
                info = requests.get(
                    f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=me",
                    timeout=10
                ).json()

                nickname = (
                    info.get("basicInfo", {})
                    .get("nickname", "Unknown")
                )

            except:
                nickname = "Unknown"

            players_text += f"{i}. {nickname}\n"

        # حذف رسالة الحالة
        try:
            bot.delete_message(
                chat_id=status_msg.chat.id,
                message_id=status_msg.message_id
            )
        except:
            pass

        # إرسال النتيجة النهائية
        bot.send_photo(
            chat_id=message.chat.id,
            photo=emote_image if emote_image else "https://i.imgur.com/8p0XKQh.png",
            caption=(
                f"<b>🌀 /EVO EMOTE EXECUTED</b>\n\n"

                f"<b>TEAM CODE:</b> <code>{team_code}</code>\n"
                f"<b>EMOTE ID:</b> <code>{emote_id}</code>\n"
                f"<b>EMOTE NAME:</b> <code>{emote_name}</code>\n"
                f"<b>TARGET COUNT:</b> <code>{len(success_uids)}</code>\n\n"

                f"<b>PLAYERS:</b>\n"
                f"{players_text}\n"

                f"<b>STATUS:</b> <code>SUCCESS</code>"
            ),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "RANDOM EMOTES",
                        callback_data="emotes_list"
                    )
                ]
            ])
        )

    except requests.exceptions.ConnectTimeout:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text="<b>❌ CONNECTION TIMEOUT</b>",
            parse_mode="HTML"
        )

    except requests.exceptions.ConnectionError:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text=(
                "<b>❌ API OFFLINE</b>\n"
                "<b>SERVER:</b> 127.0.0.1:5000"
            ),
            parse_mode="HTML"
        )

    except Exception as e:
        bot.edit_message_text(
            chat_id=status_msg.chat.id,
            message_id=status_msg.message_id,
            text=(
                f"<b>❌ EVO FAILED</b>\n"
                f"<b>ERROR:</b> {str(e)[:200]}"
            ),
            parse_mode="HTML"
        )

user_daily_usage = {}

@bot.message_handler(commands=['bot'])
@require_membership
def add_user_cmd(message):
    if not is_group_active(message.chat.id):
        return

    user_id = str(message.from_user.id)
    ensure_user_exists(user_id)

    DAILY_LIMIT = 3
    today_str = datetime.now().strftime("%Y-%m-%d")

    # ===== DAILY RESET =====
    if user_id not in user_daily_usage:
        user_daily_usage[user_id] = {
            "date": today_str,
            "count": 0
        }

    if user_daily_usage[user_id].get("date") != today_str:
        user_daily_usage[user_id]["date"] = today_str
        user_daily_usage[user_id]["count"] = 0

    # ===== DAILY LIMIT CHECK =====
    if message.from_user.id != OWNER_ID:
        if user_daily_usage[user_id]["count"] >= DAILY_LIMIT:
            return bot.send_message(
                message.chat.id,
                "<b>❌ Daily Limit Reached</b>\n\n"
                f"📌 <b>You can only use this command {DAILY_LIMIT} times per day.</b>",
                parse_mode="HTML"
            )

    msg = None

    try:
        args = message.text.split()

        # ===== CHECK COMMAND FORMAT =====
        if len(args) != 3:
            return bot.send_message(
                message.chat.id,
                "<b>❌ Invalid Usage</b>\n\n"
                "<code>/bot &lt;UID&gt; &lt;s1&gt;</code>\n\n"
                "<b>Example:</b> <code>/bot 123456789 s1</code>",
                parse_mode="HTML"
            )

        # ===== CLEAN UID (REMOVE HIDDEN CHARS / NON-DIGITS) =====
        raw_uid = str(args[1])
        uid = "".join(filter(str.isdigit, raw_uid))

        if not uid:
            return bot.send_message(
                message.chat.id,
                "<b>❌ Invalid UID</b>\n\n"
                "<b>Please send numbers only.</b>",
                parse_mode="HTML"
            )

        # ===== CLEAN SERVER =====
        chosen_server = str(args[2]).strip().lower()
        chosen_server = chosen_server.replace("serv_", "s").replace("server_", "s")

        if not (chosen_server.startswith("s") and chosen_server[1:].isdigit()):
            return bot.send_message(
                message.chat.id,
                f"<b>⚠️ Invalid server format:</b> <code>{escape(chosen_server)}</code>\n\n"
                "<b>Example:</b> <code>s1</code>",
                parse_mode="HTML"
            )

        server_index = int(chosen_server[1:])
        server_name_key = f"serv_{server_index}"

        # ===== CHECK SERVER EXISTS =====
        if server_name_key not in JWT_TOKENS:
            return bot.send_message(
                message.chat.id,
                f"<b>🚫 Server {escape(server_name_key)} is currently unavailable.</b>",
                parse_mode="HTML"
            )

        # ===== CHECK IF UID ALREADY EXISTS =====
        users = load_users()

        if not isinstance(users, dict):
            users = {}

        user_friends = users.get(user_id, {})

        if not isinstance(user_friends, dict):
            user_friends = {}

        if uid in user_friends:
            expiry = user_friends[uid].get("expiry", 0)

            try:
                expiry = int(expiry)
            except Exception:
                expiry = 0

            if expiry > int(time.time()):
                return bot.send_message(
                    message.chat.id,
                    f"<b>❌ UID <code>{escape(uid)}</code> is already active</b>\n\n"
                    "<b>⏳ Please wait until expiry.</b>",
                    parse_mode="HTML"
                )

        # ===== WAIT MESSAGE =====
        msg = bot.send_message(
            message.chat.id,
            "<b>〘 Please wait... 〙</b>",
            parse_mode="HTML"
        )

        # ===== SEND FRIEND REQUEST =====
        _, server_name, add_response = request_add_friend(
            uid,
            server_index=server_index
        )

        add_response = str(add_response)

        # ===== SUCCESS =====
        if add_response.startswith("✅"):

            if message.from_user.id != OWNER_ID:
                user_daily_usage[user_id]["count"] += 1

            save_user(user_id, uid, server_name, days=1)

            nickname = "Unknown"
            region = "Unknown"
            level = "Unknown"

            # ===== FETCH PLAYER INFO =====
            try:
                res = requests.get(
                    f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME",
                    timeout=40
                )

                if res.status_code == 200:
                    data = res.json()
                    basic = data.get("basicInfo", {})

                    nickname = escape(str(basic.get("nickname", "Unknown")))
                    region = escape(str(basic.get("region", "Unknown")))
                    level = escape(str(basic.get("level", "Unknown")))

            except Exception:
                pass

            # ===== REQUESTER NAME =====
            requester_name = (
                f"@{message.from_user.username}"
                if message.from_user.username
                else (message.from_user.first_name or "Unknown")
            )

            requester_name = escape(str(requester_name))
            server_name = escape(str(server_name))

            remaining_uses = (
                DAILY_LIMIT - user_daily_usage[user_id]["count"]
                if message.from_user.id != OWNER_ID
                else "Unlimited"
            )

            # ===== FINAL MESSAGE =====
            caption = (
                "<b>✅ FRIEND REQUEST SENT SUCCESSFULLY</b>\n\n"
                f"🆔 <b>UID:</b> <code>{escape(uid)}</code>\n"
                f"👤 <b>Nickname:</b> {nickname}\n"
                f"📊 <b>Level:</b> {level}\n"
                f"🌍 <b>Region:</b> {region}\n\n"
                f"🖥️ <b>Server:</b> {server_name}\n"
                f"➕ <b>Requested by:</b> {requester_name}\n\n"
                f"📌 <b>Remaining Uses:</b> {remaining_uses}\n\n"
                "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>"
            )

            send_with_global_note(
                message.chat.id,
                caption,
                msg.message_id if msg else None
            )

        # ===== FAILED =====
        else:
            send_with_global_note(
                message.chat.id,
                "<b>⚠️ REQUEST FAILED</b>\n\n"
                f"<code>{escape(add_response)}</code>",
                msg.message_id if msg else None
            )

    except Exception as e:
        send_with_global_note(
            message.chat.id,
            "<b>⚠️ Unexpected Error</b>\n\n"
            f"<code>{escape(str(e))}</code>",
            msg.message_id if msg else None
        )
        
from html import escape as h

@bot.message_handler(commands=['remove'])
@require_membership
def remove_user_cmd(message):
    args = message.text.split()

    if len(args) != 2:
        return bot.reply_to(
            message,
            "<b>❌ Invalid Usage</b>\n\n"
            "<code>/remove &lt;UID&gt;</code>",
            parse_mode="HTML"
        )

    player_id = str(args[1])
    user_id = str(message.from_user.id)

    requester_name = (
        f"@{message.from_user.username}"
        if message.from_user.username
        else (message.from_user.first_name or "Unknown User")
    )

    requester_name = h(str(requester_name))

    wait_msg = bot.reply_to(
        message,
        "<b>〘 Please wait... 〙</b>",
        parse_mode="HTML"
    )

    try:
        users = load_users()

        if not isinstance(users, dict):
            users = {}

        found = False
        can_delete = False
        server_name = "Unknown"
        uid_owner = None

        # ========= FIND UID =========
        for owner, friends in users.items():
            if not isinstance(friends, dict):
                continue

            user_data = friends.get(player_id)

            if not isinstance(user_data, dict):
                continue

            found = True
            uid_owner = owner
            server_name = str(user_data.get("server", "Unknown"))

            expiry_time = user_data.get("expiry") or 0

            try:
                expiry_time = int(expiry_time)
            except Exception:
                expiry_time = 0

            added_time = max(expiry_time - 86400, 0)

            if user_id in (str(OWNER_ID), str(ADMIN_ID)):
                can_delete = True

            elif uid_owner == user_id:
                can_delete = (time.time() - added_time) >= 10 * 3600

            else:
                can_delete = False

            break

        if not found:
            return send_with_global_note(
                message.chat.id,
                f"<b>🚫 UID Not Found:</b> <code>{h(player_id)}</code>",
                wait_msg.message_id if wait_msg else None
            )

        if not can_delete:
            return send_with_global_note(
                message.chat.id,
                "<b>❌ You cannot remove this UID yet</b>\n\n"
                "<b>⏳ You must wait 10 hours after adding it</b>",
                wait_msg.message_id if wait_msg else None
            )

        # ========= REMOVE FROM SERVER =========
        server_name, api_result = remove_friend(player_id, server_name)

        server_name = h(str(server_name))
        api_result = str(api_result)

        if api_result.startswith("✅"):
            remove_user(uid_owner, player_id)

            nickname = "Unknown"
            region = "Unknown"
            level = "Unknown"

            try:
                res = requests.get(
                    f"https://api-info-nrml-alinas.vercel.app/player-info?uid={player_id}&region=ME",
                    timeout=40
                )

                data = res.json() if res.status_code == 200 else {}
                basic = data.get("basicInfo", {})

                nickname = h(str(basic.get("nickname") or "Unknown"))
                region = h(str(basic.get("region") or "Unknown"))
                level = h(str(basic.get("level") or "Unknown"))

            except Exception:
                pass

            reply_msg = (
                "<b>✅ PLAYER REMOVED SUCCESSFULLY</b>\n\n"
                f"🆔 <b>UID:</b> <code>{h(player_id)}</code>\n\n"
                f"👤 <b>Nickname:</b> {nickname}\n"
                f"📊 <b>Level:</b> {level}\n"
                f"🌍 <b>Region:</b> {region}\n\n"
                f"🖥️ <b>Server:</b> {server_name}\n"
                f"🗑️ <b>Removed by:</b> {requester_name}\n\n"
                "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>\n"
            )

            send_with_global_note(
                message.chat.id,
                reply_msg,
                wait_msg.message_id if wait_msg else None
            )

        else:
            send_with_global_note(
                message.chat.id,
                "<b>❌ Failed to remove player</b>\n\n"
                f"<code>{h(api_result)}</code>\n\n"
                "<b>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</b>",
                wait_msg.message_id if wait_msg else None
            )

    except Exception as e:
        send_with_global_note(
            message.chat.id,
            "<b>⚠️ Unexpected Error Occurred</b>\n\n"
            f"<code>{h(str(e))}</code>\n\n"
            "<b>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</b>",
            wait_msg.message_id if wait_msg else None
        )
        
@bot.message_handler(commands=['remove_all'])
def remove_all_users(message):
    if message.from_user.id != DEV_ID:
        return bot.reply_to(message, "🚫 هذا الأمر مخصص للمطور فقط.")

    try:
        users = load_users()

        if not isinstance(users, dict) or not users:
            return bot.reply_to(message, "📭 لا يوجد أي لاعبين ليتم حذفهم.")

        deleted_count = 0
        failed_count = 0
        report_lines = []

        # نسخة آمنة
        users_copy = dict(users)

        for user_id, friends in users_copy.items():

            if not isinstance(friends, dict):
                continue

            friends_copy = dict(friends)

            for uid, info in friends_copy.items():
                server_name = "Unknown"

                if isinstance(info, dict):
                    server_name = info.get("server", "Unknown")

                try:
                    server_name, api_result = remove_friend(uid, server_name)
                    api_result = str(api_result)

                    if api_result.startswith("✅"):
                        deleted_count += 1

                        # حذف آمن من الأصل
                        if user_id in users and uid in users[user_id]:
                            del users[user_id][uid]

                        # ===== API INFO =====
                        nickname, region, level = "Unknown", "Unknown", "Unknown"

                        try:
                            res = requests.get(
                                f"https://api-info-nrml-alinas.vercel.app/player-info?uid={uid}&region=ME",
                                timeout=40
                            )

                            data = res.json() if res.status_code == 200 else {}
                            basic = data.get("basicInfo", {})

                            nickname = data.get("nickname", "Unknown")
                            region = data.get("region", "Unknown")
                            level = data.get("level", "Unknown")

                        except Exception:
                            pass

                        report_lines.append(
                            f"✅ حذف: {uid} | {nickname} | Lv:{level} | {region} | {server_name}"
                        )

                    else:
                        failed_count += 1
                        report_lines.append(
                            f"❌ فشل: {uid} | السيرفر: {server_name} | السبب: {api_result}"
                        )

                except Exception as err:
                    failed_count += 1
                    report_lines.append(f"⚠️ خطأ مع {uid}: {err}")

            # حذف user إذا فارغ
            if user_id in users and isinstance(users[user_id], dict) and not users[user_id]:
                del users[user_id]

        # حفظ نهائي
        save_users(users)

        final_report = (
            "🗑️ <b>تم تنفيذ الحذف الجماعي</b>\n\n"
            f"✅ المحذوف: {deleted_count}\n"
            f"❌ الفاشل: {failed_count}\n\n"
            "<b>📋 التفاصيل:</b>\n"
            + "\n".join(report_lines) +
            "\n\n<b>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</b>"
        )

        bot.send_message(
            message.chat.id,
            final_report,
            parse_mode="HTML"
        )

    except Exception as e:
        bot.reply_to(
            message,
            f"⚠️ خطأ غير متوقع:\n<code>{e}</code>",
            parse_mode="HTML"
        )

@bot.message_handler(commands=['clan', 'CLAN'])
@require_membership
def get_clan_info(message):
    chat_id = message.chat.id

    if not is_allowed(chat_id):
        return

    args = message.text.split()

    if len(args) != 2 or not args[1].isdigit():
        text_usage = (
            "<b>AlInAs</b>\n"
            "<b>Usage:</b>\n"
            "<b>/clan &lt;CLAN_ID&gt;</b>\n\n"
            "<b>Example:</b>\n"
            "<code>/clan 3050458512</code>"
        )
        return send_with_global_note(chat_id, text_usage)

    clan_id = args[1]
    url = f"https://api-get-info-clan-by-alinas.vercel.app/get_clan_info?clan_id={clan_id}"

    wait_msg = bot.send_message(
        chat_id,
        "<b>〘 Please wait 〙</b>",
        parse_mode="HTML"
    )

    try:
        res = requests.get(url, timeout=30)
        res.raise_for_status()

        try:
            data = res.json()
        except Exception:
            data = {}

    except Exception:
        try:
            bot.delete_message(chat_id, wait_msg.message_id)
        except:
            pass

        return send_with_global_note(
            chat_id,
            "<b>xAlInAs_sAnIlAx</b>\n"
            "<b>Error:</b> Clan service is currently unavailable."
        )

    try:
        bot.delete_message(chat_id, wait_msg.message_id)
    except:
        pass

    if not isinstance(data, dict) or data.get("error"):
        return send_with_global_note(
            chat_id,
            "<b>xAlInAs_sAnIlAx</b>\n"
            "<b>Error:</b> Failed to fetch clan information."
        )

    clan_name = data.get("clan_name", "Unknown")
    region = data.get("region", "Unknown")
    level = data.get("level", "N/A")
    rank = data.get("rank", "N/A")
    xp = data.get("xp", "N/A")
    energy = data.get("energy", "N/A")
    balance = data.get("balance", "N/A")
    achievements = data.get("achievements", "N/A")
    last_active = data.get("last_active", "N/A")
    welcome_message = data.get("welcome_message", "None")

    guild = data.get("guild_details") or {}
    total_members = guild.get("total_members", "N/A")
    members_online = guild.get("members_online", "N/A")

    text = (
        "<b>Clan info</b>\n\n"
        f"<b>Clan Name:</b> {clan_name}\n"
        f"<b>Clan ID:</b> {clan_id}\n"
        f"<b>Region:</b> {region}\n"
        f"<b>Level:</b> {level}\n"
        f"<b>Rank:</b> {rank}\n"
        f"<b>XP:</b> {xp}\n"
        f"<b>Energy:</b> {energy}\n"
        f"<b>Balance:</b> {balance}\n"
        f"<b>Achievements:</b> {achievements}\n"
        f"<b>Total Members:</b> {total_members}\n"
        f"<b>Members Online:</b> {members_online}\n"
        f"<b>Last Active:</b> {last_active}\n\n"
        f"<b>Welcome Message:</b>\n{welcome_message}\n\n"
        "<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>\n\n"
    )

    send_with_global_note(chat_id, text)
        

@bot.message_handler(commands=['dev', 'DEV'])
def dev_command(message):
    if not is_allowed(message.chat.id):
        return

    try:
        # رابط الصورة المباشر
        photo_url = "https://i.ibb.co/fVTWGNk4/Screenshot-20260504-195125.jpg"

        # النص الكامل
        caption = (
            "<b>BEST DEV TEAM</b>\n\n"

            "<a href='https://t.me/NH_S8'>𝗡𝗔𝗦𝗦𝗜𝗠</a>\n\n"

            "<a href='https://t.me/'></a>\n\n"

            "<b>SOCIAL MEDIA</b>\n\n"

            "<a href='https://www.instagram.com/3_.v._/?utm_source=qr&r=nametag'>Instagram</a>\n\n"

            "<a href='https://www.tiktok.com/@a.l.i.n.a.s4?_r=1&_d=f297e6214167m5&sec_uid=MS4wLjABAAAAzpLQupC9cxx32IGlNJPb03RaSJhJwbze5t1zzxiGiwxVi3HZA5MZ_GhfHIBQUlid&share_author_id=7008466352583246850&sharer_language=en&source=h5_m&u_code=dkid6fgg88micf&timestamp=1777795574&user_id=7008466352583246850&sec_user_id=MS4wLjABAAAAzpLQupC9cxx32IGlNJPb03RaSJhJwbze5t1zzxiGiwxVi3HZA5MZ_GhfHIBQUlid&item_author_type=1&utm_source=copy&utm_campaign=client_share&utm_medium=android&share_iid=7633975936111150869&share_link_id=2f8d9d06-6155-4410-92a2-19813d43e475&share_app_id=1233&ugbiz_name=ACCOUNT&ug_btm=b8727%2Cb4907&social_share_type=5&enable_checksum=1'>TikTok</a>\n\n"

            "<b>WHO'S ALINAS :</b>\n\n"

            "NAME : ALINAS\n\n"

            "AGE : ??"
        )

        # الأزرار
        markup = types.InlineKeyboardMarkup(row_width=2)

        btn1 = types.InlineKeyboardButton(
            "CHANNEL",
            url="https://t.me/x_5_c_h"
        )

        btn2 = types.InlineKeyboardButton(
            "BIO",
            url="https://t.me/x_z_x_o"
        )

        btn3 = types.InlineKeyboardButton(
            "GROUP",
            url="https://t.me/x_5_2_4"
        )

        btn4 = types.InlineKeyboardButton(
            "ME",
            url="https://t.me/xAlInAs_sAnIlAx"
        )

        markup.add(btn1, btn2, btn3, btn4)

        # إرسال الصورة بدل النص فقط
        bot.send_photo(
            message.chat.id,
            photo=photo_url,
            caption=caption,
            parse_mode="HTML",
            reply_markup=markup
        )

    except Exception as e:
        bot.reply_to(
            message,
            f"❌ حدث خطأ: {e}"
        )


API_BASE = "http://78.109.17.4:50069"
BIO_ENDPOINT = f"{API_BASE}/bio_upload"

SESSION_TIMEOUT = 60
HEX_64 = re.compile(r"^[a-fA-F0-9]{64}$")

bio_sessions = {}


def h(x):
    return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def cancel_kb():
    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton(
            "Cancel",
            callback_data="bio_cancel"
        )
    )
    return kb

@bot.callback_query_handler(func=lambda c: c.data == "bio_cancel")
def cancel_bio(c):
    uid = c.from_user.id
    session = bio_sessions.get(uid)
    if not session:
        bot.answer_callback_query(c.id, "No active process")
        return
    bio_sessions.pop(uid, None)
    try:
        bot.delete_message(c.message.chat.id, c.message.message_id)
    except:
        pass

@bot.message_handler(commands=["bio"])
@require_membership
def bio_start(message):
    uid = message.from_user.id
    chat_id = message.chat.id

    if uid in bio_sessions:
        return

    bio_sessions[uid] = {
        "step": "WAIT_LOGIN",
        "login": None,
        "chat_id": chat_id,
        "bot_msgs": [],
        "start": time.time()
    }

    threading.Thread(target=auto_close, args=(uid,), daemon=True).start()

    m = bot.send_message(
        chat_id,
        "Send access token or UID:PASS",
        reply_markup=cancel_kb()
    )

    bio_sessions[uid]["bot_msgs"].append(m.message_id)


def auto_close(uid):
    time.sleep(SESSION_TIMEOUT)

    session = bio_sessions.get(uid)
    if not session:
        return

    # تأكد أن الجلسة مازالت نفسها (حتى مايحذفش session جديدة)
    if session.get("step") != "WAIT_LOGIN":
        return

    chat_id = session.get("chat_id")

    for mid in session.get("bot_msgs", []):
        try:
            bot.delete_message(chat_id, mid)
        except Exception:
            pass

    bio_sessions.pop(uid, None)

@bot.message_handler(func=lambda m: m.from_user.id in bio_sessions)
def bio_steps(message):

    uid = message.from_user.id
    chat_id = message.chat.id

    session = bio_sessions.get(uid)

    # حماية أساسية
    if not session or "step" not in session:
        bio_sessions.pop(uid, None)
        return

    # لازم نص فقط
    if not getattr(message, "text", None):
        return

    # حذف رسالة المستخدم
    try:
        bot.delete_message(chat_id, message.message_id)
    except Exception:
        pass

    # ===================== LOGIN STEP =====================
    if session["step"] == "WAIT_LOGIN":

        text = message.text.strip()
        login = {}

        try:
            if HEX_64.fullmatch(text):
                login["access"] = text

            elif ":" in text:
                u, p = text.split(":", 1)
                login["uid"] = u.strip()
                login["pass"] = p.strip()

            else:
                bio_sessions.pop(uid, None)
                return

        except Exception:
            bio_sessions.pop(uid, None)
            return

        session["login"] = login
        session["step"] = "WAIT_BIO"
        session.setdefault("bot_msgs", [])

        m = bot.send_message(chat_id, "Send bio text")
        session["bot_msgs"].append(m.message_id)
        return

    # ===================== BIO STEP =====================
    if session["step"] == "WAIT_BIO":

        bio_text = message.text.strip()

        params = dict(session.get("login", {}))
        params["bio"] = bio_text

        try:
            r = requests.get(BIO_ENDPOINT, params=params, timeout=30)
            data = r.json()
        except Exception:
            bio_sessions.pop(uid, None)
            return

        # حذف رسائل البوت
        for mid in session.get("bot_msgs", []):
            try:
                bot.delete_message(chat_id, mid)
            except Exception:
                pass

        bio_sessions.pop(uid, None)

        text = (
            "<b>Bio Updated Successfully</b>\n\n"
            f"<b>Name:</b> {h(data.get('name', 'Unknown'))}\n"
            f"<b>UID:</b> {h(data.get('uid', 'Unknown'))}\n"
            f"<b>Region:</b> {h(data.get('region', 'Unknown'))}\n"
            f"<b>Login Method:</b> {h(data.get('login_method', 'Unknown'))}\n"
            f"<b>Bio:</b> {h(data.get('bio', ''))}\n"
            f"<b>Status:</b> {h(data.get('status', 'Unknown'))}\n\n"
            "<b>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</b>"
        )

        send_with_global_note(chat_id, text)


# ===================== BANNER =====================
@bot.message_handler(commands=['bnr', 'BNR'])
@require_membership
def bnr_handler(message):

    args = message.text.split()

    if len(args) != 2:
        return bot.reply_to(
            message,
            "<b>USAGE:</b> /bnr UID",
            parse_mode="HTML"
        )

    uid = args[1]

    if not uid.isdigit():
        return bot.reply_to(
            message,
            "<b>INVALID UID</b>",
            parse_mode="HTML"
        )

    msg = bot.send_message(
        message.chat.id,
        "<b>〘 Please wait 〙</b>",
        parse_mode="HTML"
    )

    api_url = f"https://api-banner-alinas.vercel.app/profile?uid={uid}"

    try:
        r = requests.get(api_url, timeout=20)

        if r.status_code != 200:
            try:
                bot.delete_message(message.chat.id, msg.message_id)
            except:
                pass

            return bot.reply_to(
                message,
                "<b>FAILED TO GENERATE BANNER</b>",
                parse_mode="HTML"
            )

        image_bytes = BytesIO(r.content)
        image_bytes.seek(0)
        image_bytes.name = "banner.webp"

        try:
            bot.delete_message(message.chat.id, msg.message_id)
        except:
            pass

        # ✅ FIX: send as document (webp) instead of sticker
        bot.send_document(
            message.chat.id,
            image_bytes,
            reply_to_message_id=message.message_id
        )

    except Exception as e:
        try:
            bot.delete_message(message.chat.id, msg.message_id)
        except:
            pass

        bot.reply_to(
            message,
            f"<b>ERROR:</b> {str(e)}",
            parse_mode="HTML"
        )


# ===================== FILE =====================
@bot.message_handler(commands=['file'])
def getfile_cmd(message):

    if message.from_user.id != OWNER_ID:
        return

    wait_msg = bot.reply_to(message, "⏳ جاري تجهيز السورس...")

    try:
        zip_filename = "alinas_bot.zip"
        zip_buffer = io.BytesIO()

        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zipf:

            for root, dirs, files in os.walk("."):

                if any(x in root for x in ["__pycache__", ".git"]):
                    continue

                for file in files:
                    filepath = os.path.join(root, file)

                    if file == zip_filename:
                        continue

                    zipf.write(filepath, os.path.relpath(filepath, "."))

        zip_buffer.seek(0)

        bot.send_document(
            message.chat.id,
            zip_buffer,
            visible_file_name=zip_filename,
            caption="📦 سورس البوت كامل"
        )

        bot.edit_message_text(
            "✅ تم تجهيز السورس وإرساله.",
            chat_id=message.chat.id,
            message_id=wait_msg.message_id
        )

    except Exception as e:
        bot.edit_message_text(
            f"❌ خطأ أثناء إنشاء ملف السورس: {str(e)}",
            chat_id=message.chat.id,
            message_id=wait_msg.message_id
        )

@bot.message_handler(func=lambda m: hasattr(m, "text") and m.chat.type != 'private')
@require_membership
def handle_commands(msg):
    try:
        if not hasattr(msg, "from_user") or not getattr(msg, "text", None):
            print("INVALID MSG TYPE:", type(msg))
            return

        settings = get_settings()
        text = msg.text.strip()

        # maintenance mode
        if settings.get('maintenance_mode') and msg.from_user.id != DEV_ID:
            return

        start_cmd = settings.get('start_command', '')
        stop_cmd = settings.get('stop_command', '')

        # حماية من empty commands
        if not start_cmd or not stop_cmd:
            print("COMMANDS NOT CONFIGURED IN SETTINGS")
            return

        # start command
        if text.startswith(start_cmd):
            return onAdd(msg)

        # stop command
        if text.startswith(stop_cmd):
            return onRemove(msg)

    except Exception as e:
        print("HANDLE_COMMANDS ERROR:", e)
        
def onAdd(msg):
    try:
        if not hasattr(msg, "from_user") or not hasattr(msg, "chat"):
            print("BLOCKED INVALID MSG TYPE:", type(msg))
            return

        if not getattr(msg, "text", None):
            return

        settings = get_settings()
        parts = msg.text.strip().split()

        if len(parts) < 2:
            return send_with_global_note(
                msg.chat.id,
                f"usage: {settings.get('start_command', '/start')} <UID>"
            )

        uid = parts[1]

        if not uid.isdigit():
            return send_with_global_note(
                msg.chat.id,
                f"usage: {settings.get('start_command', '/start')} <UID>"
            )

        # 🔥 WAIT MESSAGE (added here)
        wait_msg = bot.send_message(
            msg.chat.id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        user_id = msg.from_user.id
        username = getattr(msg.from_user, "username", None) or str(user_id)

        try:
            result = add(uid, user_id, username)
        except Exception as e:
            print("ADD ERROR:", e)
            return

        if result:
            try:
                # 🔥 جلب معلومات اللاعب
                try:
                    res = requests.get(
                        f"{API_URL}?uid={uid}",
                        timeout=20
                    )
                    data = res.json() if res.status_code == 200 else {}
                    basic = data.get("basicInfo", {}) or {}

                    name = basic.get("nickname", uid)
                    level = basic.get("level", "N/A")
                    region = basic.get("region", "N/A")

                except Exception:
                    name, level, region = uid, "N/A", "N/A"

                template = settings.get(
                    "start_message_template",
                    DEFAULT_SETTINGS["start_message_template"]
                )

                message = template.format(
                    uid=uid,
                    name=name,
                    level=level,
                    region=region
                )

                # 🔥 delete wait message then send result
                try:
                    bot.delete_message(msg.chat.id, wait_msg.message_id)
                except:
                    pass

                send_with_global_note(msg.chat.id, message)

            except Exception as e:
                print("SEND ERROR:", e)
                send_with_global_note(msg.chat.id, f"STARTED -> {uid}")

        else:
            try:
                bot.delete_message(msg.chat.id, wait_msg.message_id)
            except:
                pass

    except Exception as e:
        print("onAdd ERROR:", e)

def onRemove(msg):
    try:
        if not hasattr(msg, "from_user") or not hasattr(msg, "chat"):
            print("BLOCKED INVALID MSG TYPE:", type(msg))
            return

        if not getattr(msg, "text", None):
            return

        settings = get_settings()
        parts = msg.text.strip().split()

        if len(parts) < 2:
            return send_with_global_note(
                msg.chat.id,
                f"usage: {settings.get('stop_command', '/stop')} <UID>"
            )

        uid = parts[1]

        if not uid.isdigit():
            return send_with_global_note(
                msg.chat.id,
                f"usage: {settings.get('stop_command', '/stop')} <UID>"
            )

        # 🔥 WAIT MESSAGE (added)
        wait_msg = bot.send_message(
            msg.chat.id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        user_id = msg.from_user.id

        try:
            result = remove(uid, user_id)
        except Exception as e:
            print("REMOVE ERROR:", e)
            try:
                bot.delete_message(msg.chat.id, wait_msg.message_id)
            except:
                pass
            return

        if result:
            try:
                # 🔥 جلب معلومات اللاعب
                try:
                    res = requests.get(f"{API_URL}?uid={uid}", timeout=20)
                    data = res.json() if res.status_code == 200 else {}
                    basic = data.get("basicInfo", {}) or {}

                    name = basic.get("nickname", uid)
                    level = basic.get("level", "N/A")
                    region = basic.get("region", "N/A")

                except Exception:
                    name, level, region = uid, "N/A", "N/A"

                # 🔥 template من settings.json
                template = settings.get(
                    "stop_message_template",
                    DEFAULT_SETTINGS["stop_message_template"]
                )

                message = template.format(
                    uid=uid,
                    name=name,
                    level=level,
                    region=region
                )

                # 🔥 remove wait message
                try:
                    bot.delete_message(msg.chat.id, wait_msg.message_id)
                except:
                    pass

                send_with_global_note(msg.chat.id, message)

            except Exception as e:
                print("SEND ERROR:", e)
                send_with_global_note(msg.chat.id, f"STOPPED -> {uid}")

        else:
            # 🔥 remove wait message
            try:
                bot.delete_message(msg.chat.id, wait_msg.message_id)
            except:
                pass

            if uid in _tasks:
                try:
                    with _target_owners_lock:
                        owner_id, owner_username = _target_owners.get(uid, (None, "unknown"))
                except Exception:
                    owner_username = "unknown"

                send_with_global_note(
                    msg.chat.id,
                    f"YOU CANNOT STOP THIS SPAM ONLY {owner_username} OR DEV CAN"
                )
            else:
                send_with_global_note(msg.chat.id, f"NOT RUN -> {uid}")

    except Exception as e:
        print("onRemove ERROR:", e)

@bot.message_handler(commands=['like'])
@require_membership
def handle_like(message):
    try:
        chat_id = message.chat.id
        parts = message.text.split()

        # التحقق من كتابة الأمر بشكل صحيح
        if len(parts) != 2:
            bot.reply_to(
                message,
                "<b>Usage:</b>\n<code>/like UID</code>",
                parse_mode="HTML"
            )
            return

        uid = parts[1].strip()

        # التحقق من UID
        if not uid.isdigit():
            bot.reply_to(
                message,
                "<b>❌ Invalid UID</b>",
                parse_mode="HTML"
            )
            return

        # رسالة انتظار
        wait_msg = bot.send_message(
            chat_id,
            "<b>〘 Please wait 〙</b>",
            parse_mode="HTML"
        )

        # رابط API
        api_url = f"https://api-likes-alinas.vercel.app/like?uid={uid}"

        response = requests.get(api_url, timeout=30)

        if response.status_code != 200:
            bot.edit_message_text(
                "<b>❌ API Error</b>",
                chat_id,
                wait_msg.message_id,
                parse_mode="HTML"
            )
            return

        data = response.json()

        # التحقق الصحيح بدل status
        if "LikesAdded" not in data:
            bot.edit_message_text(
                "<b>❌ Failed to send likes</b>",
                chat_id,
                wait_msg.message_id,
                parse_mode="HTML"
            )
            return

        # الرسالة النهائية
        reply_text = f"""
<b>LIKE SEND SUCCESS ✅</b>

<b>Player:</b> {data.get('PlayerNickname', 'Unknown')}

<b>UID:</b> {data.get('UID', uid)}

<b>Before Likes:</b> {data.get('LikesbeforeCommand', 0)}

<b>After Likes:</b> {data.get('LikesafterCommand', 0)}

<b>Likes Added:</b> {data.get('LikesAdded', 0)}

<b>Successful Requests:</b> {data.get('SuccessfulRequests', 0)}

<b>Tokens Used:</b> {data.get('SuccessfulRequests', 0)}

<a href='https://t.me/xAlInAs_sAnIlAx'>xAlInAs</a>
"""

        bot.edit_message_text(
            reply_text,
            chat_id,
            wait_msg.message_id,
            parse_mode="HTML",
            disable_web_page_preview=True
        )

    except Exception as e:
        bot.reply_to(
            message,
            f"<b>❌ Error:</b>\n<code>{str(e)}</code>",
            parse_mode="HTML"
        )

from html import escape


def send_welcome_with_note(chat_id, reply_msg, wait_msg_id=None):
    try:
        note = get_welcome_note()  # 🔥 نفس الدالة اللي درتها فوق

        if isinstance(note, dict):
            note_type = note.get("type")
            content = note.get("content")

            if note_type == "photo" and content:
                bot.send_photo(
                    chat_id=chat_id,
                    photo=content,
                    caption=reply_msg,
                    parse_mode="HTML"
                )
                return

            elif note_type == "video" and content:
                bot.send_video(
                    chat_id=chat_id,
                    video=content,
                    caption=reply_msg,
                    parse_mode="HTML"
                )
                return

        bot.send_message(
            chat_id,
            reply_msg,
            parse_mode="HTML"
        )

    except Exception as e:
        print("WELCOME NOTE ERROR:", e)
        try:
            bot.send_message(chat_id, reply_msg, parse_mode="HTML")
        except:
            pass

def set_left_note(note_type, content):
    with open(LEFT_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "type": note_type,
            "content": content
        }, f, ensure_ascii=False, indent=2)


def get_left_note():
    try:
        with open(LEFT_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return None


def clear_left_note():
    try:
        os.remove(LEFT_FILE)
    except:
        pass
        
# ===================== WELCOME =====================

@bot.message_handler(content_types=['new_chat_members'])
def welcome(message):
    for user in message.new_chat_members:

        username = f"@{user.username}" if user.username else "No Username"
        user_id = user.id
        group_name = message.chat.title

        now = datetime.now()
        date = now.strftime("%d.%m.%y")
        time = now.strftime("%I:%M:%S %p")

        text = f"""
Welcome, {user.first_name}
━━━━━━━━━━━━━━━━━━━━━━
Username: {username}
User ID: {user_id}
Date: {date}
Time: {time}
━━━━━━━━━━━━━━━━━━━━━━
Welcome To:

{group_name}
━━━━━━━━━━━━━━━━━━━━━━
To view all available commands, send:
/help

━━━━━━━━━━━━━━━━━━━━━━
Please respect all members and follow the rules.
━━━━━━━━━━━━━━━━━━━━━━
Contact Developers:

<a href='https://t.me/xAlInAs_sAnIlAx'>𝙭𝐀𝑳𝐈𝐍𝐀𝐒.𝙥𝙮</a>
"""

        send_welcome_with_note(message.chat.id, text)


# ===================== GOODBYE =====================

@bot.message_handler(content_types=['left_chat_member'])
def goodbye(message):

    user = message.left_chat_member

    username = f"@{user.username}" if user.username else "No Username"
    user_id = user.id
    group_name = message.chat.title

    text = f"""
Goodbye, {user.first_name}
━━━━━━━━━━━━━━━━━━━━━━
Username: {username}
User ID: {user_id}
━━━━━━━━━━━━━━━━━━━━━━
Left Group:

{group_name}
━━━━━━━━━━━━━━━━━━━━━━
We Hope To See You Again.
"""

    set_left_note(message.chat.id, text)

@bot.message_handler(content_types=['text', 'photo', 'video', 'document', 'audio'])
def forward_to_channel(message):
    try:
        # نخليها فقط من الخاص
        if message.chat.type != "private":
            return

        # لو نص
        if message.content_type == "text":
            bot.send_message(CHANNEL_ID, f"\n\n{message.text}")

        # صور
        elif message.content_type == "photo":
            bot.send_photo(
                CHANNEL_ID,
                message.photo[-1].file_id,
                caption=message.caption or ""
            )

        # فيديو
        elif message.content_type == "video":
            bot.send_video(
                CHANNEL_ID,
                message.video.file_id,
                caption=message.caption or ""
            )

        # ملفات
        elif message.content_type == "document":
            bot.send_document(
                CHANNEL_ID,
                message.document.file_id,
                caption=message.caption or ""
            )

        # صوت
        elif message.content_type == "audio":
            bot.send_audio(
                CHANNEL_ID,
                message.audio.file_id,
                caption=message.caption or ""
            )

        bot.reply_to(message, "DONE MY KING")

    except Exception as e:
        bot.reply_to(message, f"❌ خطأ: {e}")

if __name__ == "__main__":

    print("BOT IS RUNNING")

    try:
        bot.remove_webhook()

        # تشغيل init بشكل آمن
        def safe_init():
            try:
                init()
            except Exception as e:
                print(f"INIT ERROR: {e}")

        threading.Thread(target=safe_init, daemon=True).start()

        print("STARTING POLLING...")

        bot.infinity_polling(
            skip_pending=True,
            timeout=60,
            long_polling_timeout=60
        )

    except Exception as e:
        print(f"BOT CRASHED: {e}")