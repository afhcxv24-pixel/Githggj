# ملف بديل لـ imghdr (shim) لبايثون 3.13
# DEV: @UXD_0

from mimetypes import guess_type
from pathlib import Path

def what(file, h=None):
    """
    بديل مبسط لـ imghdr.what()
    بيرجع نوع الصورة (jpg, png, gif, ...) أو None لو مش صورة.
    """
    try:
        file = Path(file)
        if not file.exists():
            return None

        mime, _ = guess_type(str(file))
        if mime and mime.startswith("image/"):
            return mime.split("/")[1]  # بيرجع الامتداد (مثلاً: 'jpeg', 'png')
        return None
    except Exception:
        return None