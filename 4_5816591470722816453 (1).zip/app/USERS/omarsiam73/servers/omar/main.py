import os
import sys
import json
import time
import base64
import binascii
import hashlib
import logging
import asyncio
import threading
import warnings
import types
from datetime import datetime, timedelta

import requests
import aiohttp
from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from urllib3.exceptions import InsecureRequestWarning

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

warnings.simplefilter('ignore', InsecureRequestWarning)


_sym_db = _symbol_database.Default()


def _build_pb2(module_name: str, serialized_file: bytes) -> types.ModuleType:
    
    mod = types.ModuleType(module_name)
    mod_globals = mod.__dict__
    descriptor = _descriptor_pool.Default().AddSerializedFile(serialized_file)
    mod_globals['DESCRIPTOR'] = descriptor
    _builder.BuildMessageAndEnumDescriptors(descriptor, mod_globals)
    _builder.BuildTopDescriptorsAndMessages(descriptor, module_name, mod_globals)
    
    sys.modules[module_name] = mod
    return mod


like_pb2 = _build_pb2(
    'like_pb2',
    b'\n\nlike.proto\"#\n\x04like\x12\x0b\n\x03uid\x18\x01 \x01(\x03\x12\x0e\n\x06region\x18\x02 \x01(\tb\x06proto3'
)

like_count_pb2 = _build_pb2(
    'like_count_pb2',
    b'\n\x10like_count.proto\"?\n\tBasicInfo\x12\x0b\n\x03UID\x18\x01 \x01(\x03\x12\x16\n\x0ePlayerNickname\x18\x03 \x01(\t\x12\r\n\x05Likes\x18\x15 \x01(\x03\"\'\n\x04Info\x12\x1f\n\x0b\x41\x63\x63ountInfo\x18\x01 \x01(\x0b\x32\n.BasicInfob\x06proto3'
)

uid_generator_pb2 = _build_pb2(
    'uid_generator_pb2',
    b'\n\x13uid_generator.proto\"0\n\ruid_generator\x12\x0f\n\x07saturn_\x18\x01 \x01(\x03\x12\x0e\n\x06garena\x18\x02 \x01(\x03\x62\x06proto3'
)

my_pb2 = _build_pb2(
    'my_pb2',
    b'\n\x08my.proto\"\xae\t\n\x08GameData\x12\x11\n\ttimestamp\x18\x03 \x01(\t\x12\x11\n\tgame_name\x18\x04 \x01(\t\x12\x14\n\x0cgame_version\x18\x05 \x01(\x05\x12\x14\n\x0cversion_code\x18\x07 \x01(\t\x12\x0f\n\x07os_info\x18\x08 \x01(\t\x12\x13\n\x0b\x64\x65vice_type\x18\t \x01(\t\x12\x18\n\x10network_provider\x18\n \x01(\t\x12\x17\n\x0f\x63onnection_type\x18\x0b \x01(\t\x12\x14\n\x0cscreen_width\x18\x0c \x01(\x05\x12\x15\n\rscreen_height\x18\r \x01(\x05\x12\x0b\n\x03\x64pi\x18\x0e \x01(\t\x12\x10\n\x08\x63pu_info\x18\x0f \x01(\t\x12\x11\n\ttotal_ram\x18\x10 \x01(\x05\x12\x10\n\x08gpu_name\x18\x11 \x01(\t\x12\x13\n\x0bgpu_version\x18\x12 \x01(\t\x12\x0f\n\x07user_id\x18\x13 \x01(\t\x12\x12\n\nip_address\x18\x14 \x01(\t\x12\x10\n\x08language\x18\x15 \x01(\t\x12\x0f\n\x07open_id\x18\x16 \x01(\t\x12\x15\n\rplatform_type\x18\x17 \x01(\x05\x12\x1a\n\x12\x64\x65vice_form_factor\x18\x18 \x01(\t\x12\x14\n\x0c\x64\x65vice_model\x18\x19 \x01(\t\x12\x14\n\x0c\x61\x63\x63\x65ss_token\x18\x1d \x01(\t\x12\x18\n\x10unknown_field_30\x18\x1e \x01(\x05\x12\"\n\x1asecondary_network_provider\x18) \x01(\t\x12!\n\x19secondary_connection_type\x18* \x01(\t\x12\x11\n\tunique_id\x18\x39 \x01(\t\x12\x10\n\x08\x66ield_60\x18< \x01(\x05\x12\x10\n\x08\x66ield_61\x18= \x01(\x05\x12\x10\n\x08\x66ield_62\x18> \x01(\x05\x12\x10\n\x08\x66ield_63\x18? \x01(\x05\x12\x10\n\x08\x66ield_64\x18@ \x01(\x05\x12\x10\n\x08\x66ield_65\x18\x41 \x01(\x05\x12\x10\n\x08\x66ield_66\x18\x42 \x01(\x05\x12\x10\n\x08\x66ield_67\x18\x43 \x01(\x05\x12\x10\n\x08\x66ield_70\x18\x46 \x01(\x05\x12\x10\n\x08\x66ield_73\x18I \x01(\x05\x12\x14\n\x0clibrary_path\x18J \x01(\t\x12\x10\n\x08\x66ield_76\x18L \x01(\x05\x12\x10\n\x08\x61pk_info\x18M \x01(\t\x12\x10\n\x08\x66ield_78\x18N \x01(\x05\x12\x10\n\x08\x66ield_79\x18O \x01(\x05\x12\x17\n\x0fos_architecture\x18Q \x01(\t\x12\x14\n\x0c\x62uild_number\x18S \x01(\t\x12\x10\n\x08\x66ield_85\x18U \x01(\x05\x12\x18\n\x10graphics_backend\x18V \x01(\t\x12\x19\n\x11max_texture_units\x18W \x01(\x05\x12\x15\n\rrendering_api\x18X \x01(\x05\x12\x18\n\x10\x65ncoded_field_89\x18Y \x01(\t\x12\x10\n\x08\x66ield_92\x18\\ \x01(\x05\x12\x13\n\x0bmarketplace\x18] \x01(\t\x12\x16\n\x0e\x65ncryption_key\x18^ \x01(\t\x12\x15\n\rtotal_storage\x18_ \x01(\x05\x12\x10\n\x08\x66ield_97\x18\x61 \x01(\x05\x12\x10\n\x08\x66ield_98\x18\x62 \x01(\x05\x12\x10\n\x08\x66ield_99\x18\x63 \x01(\t\x12\x11\n\tfield_100\x18\x64 \x01(\tb\x06proto3'
)

output_pb2 = _build_pb2(
    'output_pb2',
    b'\n\x13jwt_generator.proto\"\xd2\x02\n\nGarena_420\x12\x12\n\naccount_id\x18\x01 \x01(\x03\x12\x0e\n\x06region\x18\x02 \x01(\t\x12\r\n\x05place\x18\x03 \x01(\t\x12\x10\n\x08location\x18\x04 \x01(\t\x12\x0e\n\x06status\x18\x05 \x01(\t\x12\r\n\x05token\x18\x08 \x01(\t\x12\n\n\x02id\x18\t \x01(\x05\x12\x0b\n\x03\x61pi\x18\n \x01(\t\x12\x0e\n\x06number\x18\x0c \x01(\x05\x12\x1e\n\tGarena420\x18\x0f \x01(\x0b\x32\x0b.Garena_420\x12\x0c\n\x04\x61rea\x18\x10 \x01(\t\x12\x11\n\tmain_area\x18\x12 \x01(\t\x12\x0c\n\x04\x63ity\x18\x13 \x01(\t\x12\x0c\n\x04name\x18\x14 \x01(\t\x12\x11\n\ttimestamp\x18\x15 \x01(\x03\x12\x0e\n\x06\x62inary\x18\x16 \x01(\x0c\x12\x13\n\x0b\x62inary_data\x18\x17 \x01(\x0c\x1a\"\n\x12\x44\x65\x63rypted_Payloads\x12\x0c\n\x04type\x18\x01 \x01(\x05\x62\x06proto3'
)

_protobuf_pkg = types.ModuleType('protobuf')
_protobuf_pkg.my_pb2 = my_pb2
_protobuf_pkg.output_pb2 = output_pb2
sys.modules['protobuf'] = _protobuf_pkg
sys.modules['protobuf.my_pb2'] = my_pb2
sys.modules['protobuf.output_pb2'] = output_pb2


app = Flask(__name__)
app.logger.setLevel(logging.INFO)

PORT = int(os.environ.get("PORT", 3086))
STORAGE_PATH = "."

ACCOUNTS_FILE = os.path.join(STORAGE_PATH, "accounts.txt")
TOKEN_FILE = os.path.join(STORAGE_PATH, "token_me.json")

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'
TOKEN_REFRESH_INTERVAL_HOURS = 0.1666
MAX_WORKERS = 10

scheduler_started = False

REMOTE_CONFIG_URL = "https://redzedupdater.vercel.app/"
FALLBACK_TOKEN_API = "https://mafuuu-token-converter.onrender.com/access-jwt"
remote_config = None
remote_config_last_fetch = 0
REMOTE_CONFIG_TTL = 3600

_V0 = b'\xa7\x3f\x91\xe2\x5d\x88\x14\xb6\xfc\x29\x47\x0d\x6a\xbe\x52\x71'
_V1 = b'xCT_x_TeaM_Internal_Vault_v2_DoNotTouch_2024'

def _v_d():
    h = hashlib.pbkdf2_hmac('sha256', _V1, _V0, 150000, 48)
    return h[:32], h[32:48]

def _v_x(data):
    xk = hashlib.sha256(_V1 + _V0).digest()
    return bytes(b ^ xk[i % len(xk)] for i, b in enumerate(data))

def _v_r(blob):
    try:
        raw = base64.b64decode(blob.encode())
        ct = _v_x(raw)
        k, iv = _v_d()
        c = AES.new(k, AES.MODE_CBC, iv)
        pt = c.decrypt(ct)
        pad_len = pt[-1]
        return pt[:-pad_len].decode('utf-8')
    except Exception:
        return ""

_Z = [
    "VEPZieZlG15ke6eJE6nCcMMaNEZLvbfyBrG/zxa8mNpLtMdeCOhYu+9VefbQWeaV",
    "qOo9Js96Anw/0tzqFRcc1hPSxpyWPFp3TSe4za8Dm17abGDJAVcnegbRew2g0Nzy",
    "ge+xGeUHG7SEOQUAQ0wqaA==",
    "qOo9Js96Anw/0tzqFRcc1hPSxpyWPFp3TSe4za8Dm17abGDJAVcnegbRew2g0Nzy",
]

OWNER_NAME = _v_r(_Z[1]) or "ˣᶜᵀ ㅤ𝒙ㅤ 𝑻𝒆𝒂𝑴"
OWNER_TAG = _v_r(_Z[2]) or "@xCTx_AyOuB"
_TEAM_NAME = _v_r(_Z[3]) or "ˣᶜᵀ ㅤ𝒙ㅤ 𝑻𝒆𝒂𝑴"
REMOTE_STATUS_URL = _v_r(_Z[0])
REMOTE_STATUS_CHECK_INTERVAL = 60

BOT_STATUS = "stop"
BOT_STATUS_LAST_CHECK = 0
BOT_STATUS_LOCK = threading.Lock()
_status_thread_started = False


def check_remote_status():

    global BOT_STATUS, BOT_STATUS_LAST_CHECK
    try:
        r = requests.get(
            REMOTE_STATUS_URL,
            timeout=10,
            headers={"Cache-Control": "no-cache", "Pragma": "no-cache"}
        )
        if r.status_code == 200:
            raw = (r.text or "").strip().lower()

            first_word = raw.split()[0] if raw.split() else ""
            new_status = "run" if first_word == "run" else "stop"
            with BOT_STATUS_LOCK:
                old = BOT_STATUS
                BOT_STATUS = new_status
                BOT_STATUS_LAST_CHECK = time.time()
            if old != new_status:
                app.logger.warning(
                    f"[KILL-SWITCH] حالة البوت تغيرت: {old} → {new_status} | المالك: {OWNER_TAG}"
                )
            else:
                app.logger.info(f"[KILL-SWITCH] الحالة الحالية: {new_status}")
            return new_status
        else:
            app.logger.error(f"[KILL-SWITCH] فشل جلب الحالة - HTTP {r.status_code}")
    except Exception as e:
        app.logger.error(f"[KILL-SWITCH] خطأ في الاتصال: {e}")
    return BOT_STATUS


def _remote_status_loop():

    while True:
        try:
            check_remote_status()
        except Exception as e:
            app.logger.error(f"[KILL-SWITCH] خطأ في الحلقة: {e}")
        time.sleep(REMOTE_STATUS_CHECK_INTERVAL)


def start_remote_status_monitor():

    global _status_thread_started
    if _status_thread_started:
        return

    check_remote_status()
    t = threading.Thread(target=_remote_status_loop, daemon=True, name="RemoteStatusMonitor")
    t.start()
    _status_thread_started = True
    app.logger.info(
        f"[KILL-SWITCH] تم تشغيل مراقب الحالة - فحص كل {REMOTE_STATUS_CHECK_INTERVAL} ثانية"
    )


def _stopped_payload():
    return {
        "contact": OWNER_TAG,
        "message": "🚫 البوت متوقف حالياً من قبل المالك",
        "note": "يرجى التواصل مع المالك لمعرفة موعد إعادة التشغيل",
        "owner": OWNER_NAME,
        "owner_tag": OWNER_TAG,
        "running": False,
        "status": "stopped",
        "team": _TEAM_NAME,
    }


def _stopped_response():
    return jsonify(_stopped_payload()), 503



def fetch_remote_config():
    global remote_config, remote_config_last_fetch
    try:
        r = requests.get(REMOTE_CONFIG_URL, timeout=10)
        if r.status_code == 200:
            remote_config = r.json()
            remote_config_last_fetch = time.time()
            app.logger.info(f"Remote config loaded: version {remote_config.get('current_version')}")
            return True
    except Exception as e:
        app.logger.error(f"Failed to fetch remote config: {e}")
    return False


def get_client_url():
    global remote_config
    if not remote_config or (time.time() - remote_config_last_fetch > REMOTE_CONFIG_TTL):
        fetch_remote_config()
    if remote_config and "client_url" in remote_config:
        return remote_config["client_url"].get("etc", "https://clientbp.ggpolarbear.com/")
    return "https://clientbp.ggpolarbear.com/"


def get_server_url():
    global remote_config
    if not remote_config or (time.time() - remote_config_last_fetch > REMOTE_CONFIG_TTL):
        fetch_remote_config()
    if remote_config and "server_url" in remote_config:
        return remote_config["server_url"].rstrip('/')
    return "https://loginbp.ggpolarbear.com"


def get_release_version():
    global remote_config
    if not remote_config or (time.time() - remote_config_last_fetch > REMOTE_CONFIG_TTL):
        fetch_remote_config()
    if remote_config and "latest_release_version" in remote_config:
        return remote_config["latest_release_version"]
    return "OB53"


def decode_jwt_payload(token):
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        payload = parts[1]
        padding = 4 - len(payload) % 4
        if padding != 4:
            payload += '=' * padding
        decoded = base64.urlsafe_b64decode(payload)
        return json.loads(decoded)
    except:
        return None


def is_token_expired(token):
    try:
        payload = decode_jwt_payload(token)
        if not payload:
            return True
        exp = payload.get('exp')
        if not exp:
            iat = payload.get('iat')
            ttl = payload.get('ttl', 7200)
            if iat:
                exp = iat + ttl
            else:
                return True
        current_time = int(time.time())
        return current_time >= exp
    except:
        return True


def get_token_remaining_time(token):
    try:
        payload = decode_jwt_payload(token)
        if not payload:
            return 0
        exp = payload.get('exp')
        if not exp:
            iat = payload.get('iat')
            ttl = payload.get('ttl', 7200)
            if iat:
                exp = iat + ttl
            else:
                return 0
        remaining = exp - int(time.time())
        return max(0, remaining)
    except:
        return 0


def get_oauth_token_via_api(uid, password):

    url = f"{FALLBACK_TOKEN_API}?uid={uid}&password={password}"
    try:
        app.logger.info(f"Trying fallback API for UID {uid}...")
        r = requests.get(url, timeout=30)
        if r.status_code == 200:
            data = r.json()
            token = (
                data.get("access_token")
                or data.get("token")
                or data.get("jwt")
                or data.get("data", {}).get("token") if isinstance(data.get("data"), dict) else None
                or data.get("data", {}).get("access_token") if isinstance(data.get("data"), dict) else None
            )
            if token:
                app.logger.info(f"Fallback API success for UID {uid}")
                return {
                    "access_token": token,
                    "open_id": data.get("open_id") or data.get("openId") or "",
                    "uid": uid,
                    "raw": data,
                    "source": "external_api"
                }
            else:
                app.logger.warning(f"Fallback API returned no token for UID {uid}")
        else:
            app.logger.error(f"Fallback API returned status {r.status_code} for UID {uid}")
    except Exception as e:
        app.logger.error(f"External API failed for UID {uid}: {e}")
    return None


def get_oauth_token(password, uid):


    app.logger.info(f"Trying Garena API for UID {uid}...")
    url = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"

    headers = {
        "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }

    try:
        r = requests.post(url, headers=headers, data=data, timeout=30)
        j = r.json()

        token = (
            j.get("access_token")
            or j.get("token")
            or j.get("session_key")
            or j.get("jwt")
            or (j.get("data") or {}).get("token")
        )

        if token:
            j["access_token"] = token
            app.logger.info(f"Garena API success for UID {uid}")
            return {
                "access_token": j.get("access_token"),
                "open_id": j.get("open_id"),
                "uid": j.get("uid"),
                "raw": j,
                "source": "garena"
            }
        else:
            app.logger.warning(f"Garena API returned no token for UID {uid}, trying fallback...")
    except Exception as e:
        app.logger.error(f"Garena API failed for UID {uid}: {e}, trying fallback...")

    return get_oauth_token_via_api(uid, password)


def encrypt_aes(key, iv, plaintext):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_message)


def parse_major_login_response(response_content):
    response_dict = {}
    try:
        lines = response_content.split("\n")
        for line in lines:
            if ":" in line:
                key, value = line.split(":", 1)
                response_dict[key.strip()] = value.strip().strip('"')
    except:
        pass
    return response_dict


def generate_jwt_token(uid, password):
    token_data = get_oauth_token(password, uid)
    if not token_data or not token_data.get("access_token"):
        app.logger.error(f"No access token for UID {uid} from any source")
        return None

    access_token = token_data["access_token"]
    open_id = token_data.get("open_id", "")
    release_version = get_release_version()
    server_url = get_server_url()
    token_source = token_data.get("source", "unknown")

    game_data = my_pb2.GameData()
    game_data.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    game_data.game_name = "free fire"
    game_data.game_version = 1
    game_data.version_code = "1.108.3"
    game_data.os_info = "Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)"
    game_data.device_type = "Handheld"
    game_data.network_provider = "Verizon Wireless"
    game_data.connection_type = "WIFI"
    game_data.screen_width = 1280
    game_data.screen_height = 960
    game_data.dpi = "240"
    game_data.cpu_info = "ARMv7 VFPv3 NEON VMH | 2400 | 4"
    game_data.total_ram = 5951
    game_data.gpu_name = "Adreno (TM) 640"
    game_data.gpu_version = "OpenGL ES 3.0"
    game_data.user_id = f"Google|{uid}-{int(time.time())}"
    game_data.ip_address = "172.190.111.97"
    game_data.language = "en"
    game_data.open_id = open_id
    game_data.access_token = access_token
    game_data.platform_type = 4
    game_data.device_form_factor = "Handheld"
    game_data.device_model = "Asus ASUS_I005DA"
    game_data.field_60 = 32968
    game_data.field_61 = 29815
    game_data.field_62 = 2479
    game_data.field_63 = 914
    game_data.field_64 = 31213
    game_data.field_65 = 32968
    game_data.field_66 = 31213
    game_data.field_67 = 32968
    game_data.field_70 = 4
    game_data.field_73 = 2
    game_data.library_path = "/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/lib/arm"
    game_data.field_76 = 1
    game_data.apk_info = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/base.apk"
    game_data.field_78 = 6
    game_data.field_79 = 1
    game_data.os_architecture = "32"
    game_data.build_number = "2019117877"
    game_data.field_85 = 1
    game_data.graphics_backend = "OpenGLES2"
    game_data.max_texture_units = 16383
    game_data.rendering_api = 4
    game_data.encoded_field_89 = "\u0017T\u0011\u0017\u0002\b\u000eUMQ\bEZ\u0003@ZK;Z\u0002\u000eV\ri[QVi\u0003\ro\t\u0007e"
    game_data.field_92 = 9204
    game_data.marketplace = "3rd_party"
    game_data.encryption_key = "KqsHT2B4It60T/65PGR5PXwFxQkVjGNi+IMCK3CFBCBfrNpSUA1dZnjaT3HcYchlIFFL1ZJOg0cnulKCPGD3C3h1eFQ="
    game_data.total_storage = 111107
    game_data.field_97 = 1
    game_data.field_98 = 1
    game_data.field_99 = "4"
    game_data.field_100 = "4"

    serialized = game_data.SerializeToString()
    encrypted = encrypt_aes(AES_KEY, AES_IV, serialized)

    major_login_url = f"{server_url}/MajorLogin"

    headers = {
        'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Content-Type': "application/octet-stream",
        'Expect': "100-continue",
        'X-GA': "v1 1",
        'X-Unity-Version': "2018.4.11f1",
        'ReleaseVersion': release_version
    }

    try:
        app.logger.info(f"MajorLogin for UID {uid} to {major_login_url}")
        response = requests.post(major_login_url, data=encrypted, headers=headers, verify=False, timeout=30)

        if response.status_code == 200:
            parsed = output_pb2.Garena_420()
            parsed.ParseFromString(response.content)
            result = parse_major_login_response(str(parsed))

            jwt_token = result.get("token")

            if jwt_token:
                app.logger.info(f"JWT generated for UID {uid} via {token_source}")
                return {
                    "uid": str(uid),
                    "token": jwt_token,
                    "region": "ME",
                    "status": "live",
                    "generated_at": int(time.time()),
                    "server_url": server_url,
                    "release_version": release_version,
                    "token_source": token_source
                }
            else:
                app.logger.error(f"No JWT in MajorLogin response for UID {uid}")
        else:
            app.logger.error(f"MajorLogin returned status {response.status_code} for UID {uid}")

        return None
    except Exception as e:
        app.logger.error(f"MajorLogin failed for {uid}: {e}")
        return None


def load_accounts():
    accounts = []
    if not os.path.exists(ACCOUNTS_FILE):
        app.logger.error(f"Accounts file not found: {ACCOUNTS_FILE}")
        return accounts

    with open(ACCOUNTS_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                uid, pwd = line.split(":", 1)
                accounts.append({"uid": uid.strip(), "password": pwd.strip()})

    app.logger.info(f"Loaded {len(accounts)} accounts")
    return accounts


def load_tokens():
    if not os.path.exists(TOKEN_FILE):
        app.logger.warning(f"Token file not found: {TOKEN_FILE}")
        return None, 0, 0

    try:
        with open(TOKEN_FILE, "r") as f:
            tokens = json.load(f)

        if not isinstance(tokens, list):
            return None, 0, 0

        valid_tokens = []
        expired_count = 0

        for token_entry in tokens:
            token = token_entry.get("token", "")
            if not token:
                continue

            if is_token_expired(token):
                expired_count += 1
            else:
                remaining = get_token_remaining_time(token)
                token_entry["expires_in"] = remaining
                valid_tokens.append(token_entry)

        app.logger.info(f"Tokens: {len(valid_tokens)} valid, {expired_count} expired, {len(tokens)} total")
        return valid_tokens, expired_count, len(tokens)

    except Exception as e:
        app.logger.error(f"Failed to load tokens: {e}")
        return None, 0, 0


def save_tokens(tokens):
    try:
        os.makedirs(os.path.dirname(TOKEN_FILE) if os.path.dirname(TOKEN_FILE) else '.', exist_ok=True)
        with open(TOKEN_FILE, "w") as f:
            json.dump(tokens, f, indent=2)
        app.logger.info(f"Saved {len(tokens)} tokens to {TOKEN_FILE}")
        return True
    except Exception as e:
        app.logger.error(f"Failed to save tokens: {e}")
        return False


def refresh_expired_tokens():
    app.logger.info("Refreshing expired tokens...")
    accounts = load_accounts()
    if not accounts:
        app.logger.error("No accounts found")
        return False

    current_tokens = []
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r") as f:
                current_tokens = json.load(f)
        except:
            current_tokens = []

    uid_to_account = {acc["uid"]: acc for acc in accounts}
    tokens_to_refresh = []

    for token_entry in current_tokens:
        uid = token_entry.get("uid")
        token = token_entry.get("token", "")
        if not token or is_token_expired(token):
            if uid in uid_to_account:
                tokens_to_refresh.append(uid_to_account[uid])

    existing_uids = {t.get("uid") for t in current_tokens}
    for acc in accounts:
        if acc["uid"] not in existing_uids:
            tokens_to_refresh.append(acc)

    if not tokens_to_refresh:
        app.logger.info("No tokens need refresh")
        return True

    app.logger.info(f"Refreshing {len(tokens_to_refresh)} tokens...")
    results = []
    threads = []

    def worker(acc):
        result = generate_jwt_token(acc['uid'], acc['password'])
        if result:
            results.append(result)
        time.sleep(0.3)

    for acc in tokens_to_refresh:
        t = threading.Thread(target=worker, args=(acc,))
        threads.append(t)

    for i in range(0, len(threads), MAX_WORKERS):
        batch = threads[i:i + MAX_WORKERS]
        for t in batch:
            t.start()
        for t in batch:
            t.join()

    if results:
        valid_existing = [t for t in current_tokens if not is_token_expired(t.get("token", ""))]
        uid_map = {t["uid"]: t for t in valid_existing}
        for new_token in results:
            uid_map[new_token["uid"]] = new_token
        merged = list(uid_map.values())
        return save_tokens(merged)

    return False


def refresh_all_tokens():
    app.logger.info("Starting full token refresh...")
    accounts = load_accounts()
    if not accounts:
        app.logger.error("No accounts to refresh")
        return

    results = []
    threads = []

    def worker(acc):
        result = generate_jwt_token(acc['uid'], acc['password'])
        if result:
            results.append(result)
        time.sleep(0.5)

    for acc in accounts:
        t = threading.Thread(target=worker, args=(acc,))
        threads.append(t)

    for i in range(0, len(threads), MAX_WORKERS):
        batch = threads[i:i + MAX_WORKERS]
        for t in batch:
            t.start()
        for t in batch:
            t.join()

    if results:
        existing = []
        if os.path.exists(TOKEN_FILE):
            try:
                with open(TOKEN_FILE, "r") as f:
                    existing = json.load(f)
            except:
                existing = []

        uid_map = {item["uid"]: item for item in existing}
        for new_item in results:
            uid_map[new_item["uid"]] = new_item

        merged = list(uid_map.values())
        save_tokens(merged)
        app.logger.info(f"Saved {len(merged)} tokens to {TOKEN_FILE}")
    else:
        app.logger.error("No tokens generated!")


def scheduled_refresh():
    while True:
        app.logger.info("Starting a new infinite loop cycle for token refresh...")
        refresh_all_tokens()
        app.logger.info("Cycle completed. Restarting infinite loop in 60 seconds...")

        time.sleep(60)


def start_scheduler():
    global scheduler_started
    if not scheduler_started:
        t = threading.Thread(target=scheduled_refresh, daemon=True)
        t.start()
        scheduler_started = True
        app.logger.info("Token scheduler started")


def encrypt_for_like(plaintext):
    try:
        cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
        padded = pad(plaintext, AES.block_size)
        encrypted = cipher.encrypt(padded)
        return binascii.hexlify(encrypted).decode('utf-8')
    except:
        return None


def create_like_protobuf(uid, region):
    try:
        msg = like_pb2.like()
        msg.uid = int(uid)
        msg.region = region
        return msg.SerializeToString()
    except:
        return None


def create_uid_protobuf(uid):
    try:
        msg = uid_generator_pb2.uid_generator()
        msg.saturn_ = int(uid)
        msg.garena = 1
        return msg.SerializeToString()
    except:
        return None


def decode_player_info(binary_data):
    if not binary_data or len(binary_data) < 5:
        return None
    try:
        info = like_count_pb2.Info()
        info.ParseFromString(binary_data)
        if info.AccountInfo.UID != 0:
            return info
    except:
        pass
    try:
        basic = like_count_pb2.BasicInfo()
        basic.ParseFromString(binary_data)
        if basic.UID != 0:
            info = like_count_pb2.Info()
            info.AccountInfo.UID = basic.UID
            info.AccountInfo.PlayerNickname = basic.PlayerNickname
            info.AccountInfo.Likes = basic.Likes
            return info
    except:
        pass
    return None


def get_player_info(encrypted_uid, token):
    try:
        client_url = get_client_url()
        url = f"{client_url}GetPlayerPersonalShow"
        edata = bytes.fromhex(encrypted_uid)
        headers = {
            'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Authorization': f"Bearer {token}",
            'Content-Type': "application/x-www-form-urlencoded",
            'Expect': "100-continue",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': get_release_version()
        }
        response = requests.post(url, data=edata, headers=headers, verify=False, timeout=15)
        if response.status_code == 401:
            return None, "EXPIRED"
        if response.status_code != 200:
            return None, f"HTTP_{response.status_code}"
        result = decode_player_info(response.content)
        return result, "OK"
    except Exception as e:
        return None, "ERROR"


async def send_like_request(session, encrypted_uid, token):
    try:
        client_url = get_client_url()
        url = f"{client_url}LikeProfile"
        edata = bytes.fromhex(encrypted_uid)
        headers = {
            'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
            'Connection': "Keep-Alive",
            'Accept-Encoding': "gzip",
            'Authorization': f"Bearer {token}",
            'Content-Type': "application/x-www-form-urlencoded",
            'Expect': "100-continue",
            'X-Unity-Version': "2018.4.11f1",
            'X-GA': "v1 1",
            'ReleaseVersion': get_release_version()
        }
        async with session.post(url, data=edata, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            return resp.status
    except:
        return None


async def send_multiple_likes(uid, tokens):
    """يرسل اللايكات بسرعة جداً عبر جلسة aiohttp واحدة مشتركة - أسرع بكثير من السابق"""
    try:
        proto_data = create_like_protobuf(uid, "ME")
        if not proto_data:
            return None
        encrypted = encrypt_for_like(proto_data)
        if not encrypted:
            return None

        connector = aiohttp.TCPConnector(limit=200, ssl=False, force_close=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = []
            for i in range(100):
                token = tokens[i % len(tokens)]["token"]
                tasks.append(send_like_request(session, encrypted, token))
            results = await asyncio.gather(*tasks, return_exceptions=True)
        return results
    except Exception as e:
        app.logger.error(f"send_multiple_likes error: {e}")
        return None



_ALWAYS_ALLOWED_PATHS = {"/health", "/control", "/owner", "/favicon.ico", "/tg_webhook", "/tg_set_webhook"}


@app.before_request
def _enforce_kill_switch():

    if request.path in _ALWAYS_ALLOWED_PATHS:
        return None
    with BOT_STATUS_LOCK:
        status = BOT_STATUS
    if status != "run":
        return _stopped_response()
    return None


@app.route('/')
def home():
    with BOT_STATUS_LOCK:
        status = BOT_STATUS
    return jsonify({
        "status": "running" if status == "run" else "stopped",
        "bot_status": status,
        "service": "Free Fire Like API - ME Server",
        "timestamp": datetime.now().isoformat(),
        "remote_config": remote_config.get("current_version") if remote_config else "not loaded",
        "owner": OWNER_NAME,
        "owner_tag": OWNER_TAG
    })


@app.route('/control', methods=['GET'])
def api_control():

    with BOT_STATUS_LOCK:
        status = BOT_STATUS
        last_check = BOT_STATUS_LAST_CHECK
    return jsonify({
        "bot_status": status,
        "is_running": status == "run",
        "last_check_ago_seconds": int(time.time() - last_check) if last_check else None,
        "check_interval_seconds": REMOTE_STATUS_CHECK_INTERVAL,
        "owner": OWNER_NAME,
        "owner_tag": OWNER_TAG
    })


@app.route('/owner', methods=['GET'])
def api_owner():

    return jsonify({
        "owner": OWNER_NAME,
        "owner_tag": OWNER_TAG,
        "team": _TEAM_NAME
    })


@app.route('/health')
def health():
    return jsonify({"status": "healthy"}), 200


@app.route('/status', methods=['GET'])
def api_status():
    valid_tokens, expired_count, total_count = load_tokens()
    sample_expiry = None
    if valid_tokens and len(valid_tokens) > 0:
        remaining = get_token_remaining_time(valid_tokens[0].get("token", ""))
        sample_expiry = f"{remaining // 60} minutes"

    return jsonify({
        "status": "running",
        "server": "ME",
        "storage_path": STORAGE_PATH,
        "auto_refresh_hours": TOKEN_REFRESH_INTERVAL_HOURS,
        "total_tokens": total_count,
        "valid_tokens": len(valid_tokens) if valid_tokens else 0,
        "expired_tokens": expired_count,
        "sample_expires_in": sample_expiry,
        "remote_config_version": remote_config.get("current_version") if remote_config else "not loaded",
        "client_url": get_client_url(),
        "server_url": get_server_url()
    })


@app.route('/token_status', methods=['GET'])
def api_token_status():
    valid_tokens, expired_count, total_count = load_tokens()
    if valid_tokens is None:
        return jsonify({"error": "Token file not found"}), 404

    expiring_soon = []
    for t in (valid_tokens or [])[:5]:
        remaining = get_token_remaining_time(t.get("token", ""))
        expiring_soon.append({
            "uid": t.get("uid"),
            "region": t.get("region"),
            "expires_in_minutes": round(remaining / 60, 1)
        })

    return jsonify({
        "server": "ME",
        "total_tokens": total_count,
        "valid_tokens": len(valid_tokens) if valid_tokens else 0,
        "expired_tokens": expired_count,
        "sample_tokens": expiring_soon
    })


@app.route('/generate_token', methods=['GET'])
def api_generate_token():
    uid = request.args.get('uid')
    password = request.args.get('password')

    if not uid or not password:
        return jsonify({"error": "Missing uid or password"}), 400

    result = generate_jwt_token(uid, password)
    if result:
        payload = decode_jwt_payload(result['token'])
        if payload and payload.get('exp'):
            result['expires_at'] = datetime.fromtimestamp(payload['exp']).isoformat()
            result['expires_in_seconds'] = payload['exp'] - int(time.time())
        return jsonify({"status": "success", "data": result})
    return jsonify({"status": "error", "message": "Failed to generate token from all sources"}), 500


@app.route('/refresh_all_tokens', methods=['GET'])
def api_refresh_all():
    def run():
        refresh_all_tokens()
    threading.Thread(target=run).start()
    return jsonify({"status": "started", "message": "Full refresh in progress"})


@app.route('/refresh_expired', methods=['GET'])
def api_refresh_expired():
    def run():
        refresh_expired_tokens()
    threading.Thread(target=run).start()
    return jsonify({"status": "started", "server": "ME", "message": "Refreshing expired tokens"})


def perform_like(uid):
    """
    تنفذ منطق إرسال اللايكات وتعيد قاموساً بالنتيجة بدلاً من JSON response.
    يستخدم بواسطة /like endpoint وبوت تلجرام.
    """
    try:
        valid_tokens, expired_count, total_count = load_tokens()

        if not valid_tokens or len(valid_tokens) == 0:
            app.logger.warning("No valid tokens, attempting refresh...")
            refresh_success = refresh_expired_tokens()
            if refresh_success:
                valid_tokens, _, _ = load_tokens()
            if not valid_tokens or len(valid_tokens) == 0:
                return {
                    "ok": False,
                    "error": "No valid tokens available",
                    "expired_count": expired_count,
                    "total_count": total_count,
                }

        check_token = valid_tokens[0]["token"]

        uid_proto = create_uid_protobuf(uid)
        if not uid_proto:
            return {"ok": False, "error": "UID protobuf failed"}

        encrypted_uid = encrypt_for_like(uid_proto)
        if not encrypted_uid:
            return {"ok": False, "error": "Encryption failed"}

        before_info, status = get_player_info(encrypted_uid, check_token)

        if status == "EXPIRED":
            app.logger.warning("Token expired during request, refreshing...")
            refresh_expired_tokens()
            valid_tokens, _, _ = load_tokens()
            if not valid_tokens:
                return {"ok": False, "error": "Token expired and refresh failed"}
            check_token = valid_tokens[0]["token"]
            before_info, status = get_player_info(encrypted_uid, check_token)

        if before_info is None:
            return {
                "ok": False,
                "error": "Failed to retrieve player info",
                "token_status": status,
                "valid_tokens_available": len(valid_tokens),
            }

        before_likes = int(before_info.AccountInfo.Likes)
        player_name = str(before_info.AccountInfo.PlayerNickname)
        player_uid = int(before_info.AccountInfo.UID)

        app.logger.info(f"Before: {player_name} has {before_likes} likes")

        results = asyncio.run(send_multiple_likes(uid, valid_tokens))

        successful_requests = 0
        if results:
            for r in results:
                if isinstance(r, int) and r == 200:
                    successful_requests += 1

        time.sleep(2)

        after_info, _ = get_player_info(encrypted_uid, check_token)

        if after_info is None:
            return {"ok": False, "error": "Failed to get final player info"}

        after_likes = int(after_info.AccountInfo.Likes)
        likes_given = after_likes - before_likes

        return {
            "ok": True,
            "PlayerNickname": player_name,
            "UID": player_uid,
            "LikesBefore": before_likes,
            "LikesAfter": after_likes,
            "LikesGivenByAPI": likes_given,
            "SuccessfulRequests": successful_requests,
            "tokens_used": len(valid_tokens),
            "status": 1 if likes_given > 0 else 2,
        }
    except Exception as e:
        app.logger.error(f"perform_like error: {e}")
        return {"ok": False, "error": str(e)}


@app.route('/like', methods=['GET'])
def handle_like():
    uid = request.args.get("uid")

    if not uid:
        return jsonify({"error": "Missing uid"}), 400

    result = perform_like(uid)
    if not result.get("ok"):
        return jsonify(result), 500

    likes_given = result["LikesGivenByAPI"]
    return jsonify({
        "LikesAdded": likes_given,
        "LikesGivenByAPI": likes_given,
        "LikesafterCommand": result["LikesAfter"],
        "LikesbeforeCommand": result["LikesBefore"],
        "PlayerNickname": result["PlayerNickname"],
        "UID": result["UID"],
        "SuccessfulRequests": result["SuccessfulRequests"],
        "message": f"تمت إضافة {likes_given} إعجاب بنجاح" if likes_given > 0 else "فشل في إضافة الإعجابات",
        "status": result["status"],
        "tokens_used": result["tokens_used"],
    })


#هنا بوت تلغرام 

TELEGRAM_BOT_TOKEN = "8812861688:AAGV1uHjOKmz54qvPupUXxZujJowMmJeZls"
OWNER_ID = 8812861688
TG_API = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"

MESSAGES_FILE = os.path.join(STORAGE_PATH, "bot_messages.json")

# الرسائل الافتراضية المزخرفة
DEFAULT_START_HELP = (
    "ＨＥＬＬＯ ＩＮ ＴＨＥ ＡｂｕㅤＴａｌｉａＩＫＥ ＢＯＴ\n\n"
    "ＨＯＷ ＴＯ ＵＳＥ？\n\n"
    "/Like uid \n\n"
    "Example: /Like 123456789\n\n"
    "ＤＥＶ ＢＹ : @omar40 / "
)

DEFAULT_LIKE_TEMPLATE = (
    "❤️ LIKE INFORMATION\n\n"
    "👤 Player: {PlayerNickname}\n\n"
    "🆔 UID: {UID}\n\n"
    "📊 Likes Before: {LikesBefore}\n\n"
    "📈 Likes After: {LikesAfter}\n\n"
    "➕ Likes Added: {LikesGivenByAPI}\n\n"
    "✅ Successful Requests:\n\n"
    " {SuccessfulRequests}\n\n"
    "🎯 Status: {status}"
)

DEFAULT_STOPPED_MESSAGE = json.dumps(_stopped_payload(), indent=2, ensure_ascii=False)


def load_bot_messages():
    """يحمّل الرسائل المخصصة (start/help/like/stopped) من ملف JSON"""
    default = {
        "start_help": DEFAULT_START_HELP,
        "like_template": DEFAULT_LIKE_TEMPLATE,
        "stopped": DEFAULT_STOPPED_MESSAGE,
    }
    if not os.path.exists(MESSAGES_FILE):
        try:
            with open(MESSAGES_FILE, "w", encoding="utf-8") as f:
                json.dump(default, f, ensure_ascii=False, indent=2)
        except Exception as e:
            app.logger.error(f"Failed to write default bot_messages.json: {e}")
        return default
    try:
        with open(MESSAGES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # ضمان وجود كل المفاتيح
        for k, v in default.items():
            if k not in data:
                data[k] = v
        return data
    except Exception as e:
        app.logger.error(f"Failed to load bot_messages.json: {e}")
        return default


def save_bot_messages(data):
    try:
        with open(MESSAGES_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        app.logger.error(f"Failed to save bot_messages.json: {e}")
        return False


# جلسة طلبات مع Keep-Alive لتسريع الإرسال إلى Telegram
_tg_session = requests.Session()

# حالة انتظار إدخال نص جديد لكل مالك (key: user_id, value: which_message)
PENDING_EDITS = {}
PENDING_LOCK = threading.Lock()


def tg_request(method, **payload):
    """يستدعي Telegram Bot API بأمان"""
    try:
        url = f"{TG_API}/{method}"
        r = _tg_session.post(url, json=payload, timeout=15)
        return r.json()
    except Exception as e:
        app.logger.error(f"tg_request {method} error: {e}")
        return None


def tg_send(chat_id, text, reply_markup=None, parse_mode=None, reply_to_message_id=None):
    payload = {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": True,
    }
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    if reply_to_message_id:
        payload["reply_to_message_id"] = reply_to_message_id
    return tg_request("sendMessage", **payload)


def tg_edit(chat_id, message_id, text, reply_markup=None, parse_mode=None):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "disable_web_page_preview": True,
    }
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return tg_request("editMessageText", **payload)


def tg_answer_callback(callback_id, text=None, show_alert=False):
    payload = {"callback_query_id": callback_id}
    if text:
        payload["text"] = text
    if show_alert:
        payload["show_alert"] = True
    return tg_request("answerCallbackQuery", **payload)


def owner_panel_markup():
    """لوحة المالك: أزرار لتغيير الوصف /start /help /like ورؤية الحالة"""
    return {
        "inline_keyboard": [
            [{"text": "✏️ تغيير وصف /start و /help", "callback_data": "edit_start_help"}],
            [{"text": "✏️ تغيير وصف /like", "callback_data": "edit_like"}],
            [{"text": "✏️ تغيير رسالة التوقف", "callback_data": "edit_stopped"}],
            [{"text": "👁 عرض الرسائل الحالية", "callback_data": "view_messages"}],
            [{"text": "🔄 إعادة تعيين كل الرسائل", "callback_data": "reset_all"}],
            [{"text": "📊 حالة البوت", "callback_data": "bot_status"}],
        ]
    }


def is_owner(user_id):
    try:
        return int(user_id) == int(OWNER_ID)
    except:
        return False


def is_bot_running():
    with BOT_STATUS_LOCK:
        return BOT_STATUS == "run"


def handle_telegram_update(update):
    """المعالج الرئيسي لتحديثات تلجرام"""
    try:
        # ===== التعامل مع الأزرار (Callback) =====
        if "callback_query" in update:
            cq = update["callback_query"]
            data = cq.get("data", "")
            from_user = cq.get("from", {})
            user_id = from_user.get("id")
            chat_id = cq.get("message", {}).get("chat", {}).get("id")
            message_id = cq.get("message", {}).get("message_id")

            if not is_owner(user_id):
                tg_answer_callback(cq["id"], "❌ هذه الأزرار للمالك فقط", show_alert=True)
                return

            msgs = load_bot_messages()

            if data == "edit_start_help":
                with PENDING_LOCK:
                    PENDING_EDITS[user_id] = "start_help"
                tg_answer_callback(cq["id"], "أرسل النص الجديد الآن")
                tg_send(chat_id,
                        "✏️ أرسل النص الجديد لوصف /start و /help.\n"
                        "أرسل /cancel للإلغاء.")
                return

            if data == "edit_like":
                with PENDING_LOCK:
                    PENDING_EDITS[user_id] = "like_template"
                tg_answer_callback(cq["id"], "أرسل القالب الجديد الآن")
                tg_send(chat_id,
                        "✏️ أرسل قالب /like الجديد.\n"
                        "يمكنك استخدام المتغيرات:\n"
                        "{PlayerNickname} - اسم اللاعب\n"
                        "{UID} - معرف اللاعب\n"
                        "{LikesBefore} - الإعجابات قبل\n"
                        "{LikesAfter} - الإعجابات بعد\n"
                        "{LikesGivenByAPI} - الإعجابات المضافة\n"
                        "{SuccessfulRequests} - الطلبات الناجحة\n"
                        "{status} - الحالة\n\n"
                        "أرسل /cancel للإلغاء.")
                return

            if data == "edit_stopped":
                with PENDING_LOCK:
                    PENDING_EDITS[user_id] = "stopped"
                tg_answer_callback(cq["id"], "أرسل النص الجديد الآن")
                tg_send(chat_id,
                        "✏️ أرسل رسالة التوقف الجديدة (التي تظهر عند فشل/إيقاف البوت).\n"
                        "أرسل /cancel للإلغاء.")
                return

            if data == "view_messages":
                tg_answer_callback(cq["id"])
                preview = (
                    "📋 <b>الرسائل الحالية:</b>\n\n"
                    "🔹 <b>/start و /help:</b>\n"
                    f"<pre>{html.escape(msgs['start_help'])}</pre>\n\n"
                    "🔹 <b>قالب /like:</b>\n"
                    f"<pre>{html.escape(msgs['like_template'])}</pre>\n\n"
                    "🔹 <b>رسالة التوقف:</b>\n"
                    f"<pre>{html.escape(msgs['stopped'])}</pre>"
                )
                # قد تكون طويلة جداً، نقسمها إذا لزم
                if len(preview) > 3800:
                    tg_send(chat_id, "🔹 <b>/start و /help:</b>", parse_mode="HTML")
                    tg_send(chat_id, f"<pre>{html.escape(msgs['start_help'])}</pre>", parse_mode="HTML")
                    tg_send(chat_id, "🔹 <b>قالب /like:</b>", parse_mode="HTML")
                    tg_send(chat_id, f"<pre>{html.escape(msgs['like_template'])}</pre>", parse_mode="HTML")
                    tg_send(chat_id, "🔹 <b>رسالة التوقف:</b>", parse_mode="HTML")
                    tg_send(chat_id, f"<pre>{html.escape(msgs['stopped'])}</pre>", parse_mode="HTML")
                else:
                    tg_send(chat_id, preview, parse_mode="HTML")
                return

            if data == "reset_all":
                save_bot_messages({
                    "start_help": DEFAULT_START_HELP,
                    "like_template": DEFAULT_LIKE_TEMPLATE,
                    "stopped": DEFAULT_STOPPED_MESSAGE,
                })
                tg_answer_callback(cq["id"], "✅ تم إعادة التعيين", show_alert=True)
                tg_send(chat_id, "✅ تم إعادة تعيين جميع الرسائل إلى القيم الافتراضية.")
                return

            if data == "bot_status":
                with BOT_STATUS_LOCK:
                    status = BOT_STATUS
                    last = BOT_STATUS_LAST_CHECK
                valid_tokens, expired_count, total_count = load_tokens()
                vcount = len(valid_tokens) if valid_tokens else 0
                txt = (
                    f"📊 <b>حالة البوت</b>\n\n"
                    f"الحالة: <b>{'🟢 يعمل' if status == 'run' else '🔴 متوقف'}</b>\n"
                    f"آخر فحص: <b>{int(time.time() - last)} ثانية</b>\n"
                    f"توكنات صالحة: <b>{vcount}</b>\n"
                    f"توكنات منتهية: <b>{expired_count}</b>\n"
                    f"الإجمالي: <b>{total_count}</b>\n"
                    f"المالك: <b>{html.escape(OWNER_NAME)}</b> ({html.escape(OWNER_TAG)})"
                )
                tg_answer_callback(cq["id"])
                tg_send(chat_id, txt, parse_mode="HTML")
                return

            tg_answer_callback(cq["id"])
            return

        # ===== التعامل مع الرسائل النصية =====
        if "message" not in update:
            return

        message = update["message"]
        text = message.get("text", "")
        chat = message.get("chat", {})
        chat_id = chat.get("id")
        from_user = message.get("from", {})
        user_id = from_user.get("id")
        message_id = message.get("message_id")

        if not text:
            return

        # حالة الانتظار: المالك يرسل نصاً جديداً لتعديل رسالة
        with PENDING_LOCK:
            pending = PENDING_EDITS.get(user_id)

        if pending and is_owner(user_id):
            if text.strip().lower() in ("/cancel", "cancel"):
                with PENDING_LOCK:
                    PENDING_EDITS.pop(user_id, None)
                tg_send(chat_id, "❌ تم إلغاء التعديل.")
                return
            # حفظ النص الجديد
            msgs = load_bot_messages()
            msgs[pending] = text
            if save_bot_messages(msgs):
                with PENDING_LOCK:
                    PENDING_EDITS.pop(user_id, None)
                key_name = {
                    "start_help": "/start و /help",
                    "like_template": "قالب /like",
                    "stopped": "رسالة التوقف",
                }.get(pending, pending)
                tg_send(chat_id, f"✅ تم تحديث: <b>{key_name}</b>\n\n📝 المعاينة:", parse_mode="HTML")
                tg_send(chat_id, f"<pre>{html.escape(text)}</pre>", parse_mode="HTML")
            else:
                tg_send(chat_id, "❌ فشل في حفظ التعديل، حاول مرة أخرى.")
            return

        msgs = load_bot_messages()

        cmd = text.strip().split()[0].lower()

        # /start و /help
        if cmd in ("/start", "/start@", "/help", "/help@"):
            tg_send(chat_id, msgs["start_help"], reply_to_message_id=message_id)
            # لوحة المالك إذا كان مالكاً
            if is_owner(user_id):
                tg_send(chat_id, "👑 <b>لوحة تحكم المالك</b>",
                        reply_markup=owner_panel_markup(), parse_mode="HTML")
            return

        # /panel أو /admin للمالك
        if cmd in ("/panel", "/admin", "/owner"):
            if not is_owner(user_id):
                tg_send(chat_id, "❌ هذه اللوحة للمالك فقط.", reply_to_message_id=message_id)
                return
            tg_send(chat_id, "👑 <b>لوحة تحكم المالك</b>",
                    reply_markup=owner_panel_markup(), parse_mode="HTML")
            return

        # /like uid
        if cmd in ("/like", "/like@"):
            # تحقق من حالة البوت أولاً
            if not is_bot_running():
                tg_send(chat_id, f"<pre>{html.escape(msgs['stopped'])}</pre>",
                        parse_mode="HTML", reply_to_message_id=message_id)
                return

            parts = text.strip().split()
            if len(parts) < 2:
                tg_send(chat_id,
                        "❌ الاستخدام الصحيح:\n<code>/Like 123456789</code>",
                        parse_mode="HTML", reply_to_message_id=message_id)
                return
            uid_arg = parts[1].strip()
            if not uid_arg.isdigit():
                tg_send(chat_id, "❌ UID يجب أن يكون أرقاماً فقط.",
                        reply_to_message_id=message_id)
                return

            # أرسل رسالة معالجة فورية
            wait_resp = tg_send(chat_id,
                                f"⏳ جاري إرسال الإعجابات إلى UID: <code>{uid_arg}</code>...\n"
                                f"⚡ يرجى الانتظار بضع ثوانٍ",
                                parse_mode="HTML",
                                reply_to_message_id=message_id)
            wait_msg_id = None
            try:
                wait_msg_id = wait_resp["result"]["message_id"]
            except Exception:
                pass

            # نفّذ في خيط منفصل لتجنب حجب webhook
            def _run_like():
                result = perform_like(uid_arg)
                if not result.get("ok"):
                    err_text = (
                        f"❌ <b>فشل في إرسال الإعجابات</b>\n\n"
                        f"السبب: <code>{html.escape(str(result.get('error', 'unknown')))}</code>\n\n"
                        f"للتواصل: {OWNER_TAG}"
                    )
                    # في حال فشل الإرسال يظهر رسالة الإيقاف المزخرفة
                    if wait_msg_id:
                        tg_edit(chat_id, wait_msg_id, err_text, parse_mode="HTML")
                    else:
                        tg_send(chat_id, err_text, parse_mode="HTML")
                    # رسالة إضافية بتنسيق JSON الذي طلبه المستخدم عند فشل/توقف الإرسال
                    tg_send(chat_id, f"<pre>{html.escape(msgs['stopped'])}</pre>",
                            parse_mode="HTML")
                    return

                likes_given = result["LikesGivenByAPI"]
                status_text = "✅ Success" if likes_given > 0 else "⚠️ Failed (No likes added)"

                final_text = msgs["like_template"].format(
                    PlayerNickname=result["PlayerNickname"],
                    UID=result["UID"],
                    LikesBefore=result["LikesBefore"],
                    LikesAfter=result["LikesAfter"],
                    LikesGivenByAPI=result["LikesGivenByAPI"],
                    SuccessfulRequests=result["SuccessfulRequests"],
                    status=status_text,
                )

                if wait_msg_id:
                    tg_edit(chat_id, wait_msg_id, final_text)
                else:
                    tg_send(chat_id, final_text)

            threading.Thread(target=_run_like, daemon=True).start()
            return

        # /cancel وحدها
        if cmd == "/cancel":
            with PENDING_LOCK:
                if PENDING_EDITS.pop(user_id, None):
                    tg_send(chat_id, "❌ تم إلغاء التعديل.")
                else:
                    tg_send(chat_id, "لا يوجد تعديل قيد الانتظار.")
            return

        # رد افتراضي للأوامر غير المعروفة (يبقى صامتاً في المجموعات)
        if chat.get("type") == "private":
            tg_send(chat_id, msgs["start_help"])

    except Exception as e:
        app.logger.error(f"handle_telegram_update error: {e}")


@app.route('/tg_webhook', methods=['POST'])
def tg_webhook():
    """نقطة استقبال تحديثات تلجرام (webhook)"""
    try:
        update = request.get_json(force=True, silent=True) or {}
        # عالج التحديث في خيط لئلا نوقف Telegram (الذي ينتظر استجابة سريعة)
        threading.Thread(target=handle_telegram_update, args=(update,), daemon=True).start()
    except Exception as e:
        app.logger.error(f"tg_webhook error: {e}")
    return jsonify({"ok": True})


@app.route('/tg_set_webhook', methods=['GET'])
def tg_set_webhook():
    """يضبط الـ webhook إلى عنوان السيرفر الحالي تلقائياً"""
    base = request.args.get("url")
    if not base:
        # يحاول استنتاج العنوان من الطلب
        base = request.host_url.rstrip('/')
    webhook_url = f"{base}/tg_webhook"
    r = tg_request("setWebhook", url=webhook_url, drop_pending_updates=True)
    return jsonify({"webhook_url": webhook_url, "telegram_response": r})


@app.route('/tg_delete_webhook', methods=['GET'])
def tg_delete_webhook():
    r = tg_request("deleteWebhook", drop_pending_updates=True)
    return jsonify(r)


# ===== وضع التشغيل المحلي: long polling =====
_polling_started = False


def telegram_polling_loop():
    """وضع long polling - يُستخدم عند تشغيل main.py محلياً (بدون webhook)"""
    app.logger.info("[TG] Starting Telegram long-polling loop...")
    offset = 0
    # ألغي أي webhook قديم
    try:
        tg_request("deleteWebhook", drop_pending_updates=False)
    except:
        pass

    while True:
        try:
            url = f"{TG_API}/getUpdates"
            r = _tg_session.get(url, params={
                "timeout": 25,
                "offset": offset,
                "allowed_updates": json.dumps(["message", "callback_query"]),
            }, timeout=35)
            data = r.json()
            if not data.get("ok"):
                app.logger.error(f"[TG] getUpdates failed: {data}")
                time.sleep(3)
                continue
            for upd in data.get("result", []):
                offset = upd["update_id"] + 1
                # عالج كل تحديث في خيط مستقل لتجنب حجب البقية
                threading.Thread(target=handle_telegram_update, args=(upd,), daemon=True).start()
        except Exception as e:
            app.logger.error(f"[TG] polling error: {e}")
            time.sleep(3)


def start_telegram_polling():
    global _polling_started
    if _polling_started:
        return
    t = threading.Thread(target=telegram_polling_loop, daemon=True, name="TelegramPolling")
    t.start()
    _polling_started = True
    app.logger.info("[TG] Telegram polling thread started")


def init_app():
    fetch_remote_config()

    start_remote_status_monitor()
    if not os.path.exists(STORAGE_PATH):
        os.makedirs(STORAGE_PATH, exist_ok=True)

    source_accounts = os.path.abspath(os.path.join(os.path.dirname(__file__), "accounts.txt"))
    target_accounts = os.path.abspath(ACCOUNTS_FILE)

    if os.path.exists(source_accounts) and source_accounts != target_accounts:
        import shutil
        try:
            shutil.copy2(source_accounts, target_accounts)
            app.logger.info(f"Copied accounts.txt to {target_accounts}")
        except Exception as e:
            app.logger.error(f"Failed to copy accounts: {e}")
    elif not os.path.exists(target_accounts):
        with open(ACCOUNTS_FILE, 'w') as f:
            f.write("# Format: uid:password\n")
        app.logger.info(f"Created empty {ACCOUNTS_FILE}")

    # ضمان وجود ملف الرسائل
    load_bot_messages()

    start_scheduler()

    # تشغيل وضع long-polling افتراضياً (يعمل بدون عنوان عمومي)
    # إذا كنت ستستخدم webhook، اضبط متغير البيئة USE_TELEGRAM_WEBHOOK=1
    if os.environ.get("USE_TELEGRAM_WEBHOOK", "0") != "1":
        start_telegram_polling()
    else:
        app.logger.info("[TG] Webhook mode enabled - call /tg_set_webhook?url=https://yourdomain.com to register")


init_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=PORT, debug=False, use_reloader=False, threaded=True)
