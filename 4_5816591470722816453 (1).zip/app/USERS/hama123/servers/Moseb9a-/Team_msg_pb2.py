# -*- coding: utf-8 -*-
# Universal Protobuf Patch for Team_msg.pb2
# Ensures compatibility with protobuf runtime 6.x and Python

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

# Fallback runtime patch in case of missing runtime_version
try:
    from google.protobuf import runtime_version as _runtime_version
    _runtime_version.ValidateProtobufRuntimeVersion(
        _runtime_version.Domain.PUBLIC, 6, 30, 0, '', 'Team_msg.proto'
    )
except ImportError:
    class _runtime_version:
        class Domain:
            PUBLIC = 0
        @staticmethod
        def ValidateProtobufRuntimeVersion(*args, **kwargs):
            pass

_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x0eTeam_msg.proto\"\x94\x06\n\x0eGenTeamWhisper\x12\x0c\n\x04type\x18\x01 \x01(\x05\x12%\n\x04\x64\x61ta\x18\x02 \x01(\x0b\x32\x17.GenTeamWhisper.Nested2\x1a\xcc\x05\n\x07Nested2\x12\x0b\n\x03uid\x18\x01 \x01(\x03\x12\x0f\n\x07\x63hat_id\x18\x02 \x01(\x03\x12\x0b\n\x03msg\x18\x04 \x01(\t\x12\x11\n\ttimestamp\x18\x05 \x01(\x03\x12\x11\n\tchat_type\x18\x07 \x01(\x05\x12\r\n\x05title\x18\x08 \x01(\x05\x12/\n\x06\x66ield9\x18\t \x01(\x0b\x32\x1f.GenTeamWhisper.Nested2.Nested9\x12\x10\n\x08language\x18\n \x01(\t\x12\x31\n\x07\x66ield13\x18\r \x01(\x0b\x32 .GenTeamWhisper.Nested2.Nested13\x12\x35\n\x0b\x65mpty_field\x18\x0e \x01(\x0b\x32 .GenTeamWhisper.Nested2.Nested14\x1a\n\n\x08Nested14\x1a\xf2\x02\n\x07Nested9\x12\x10\n\x08Nickname\x18\x01 \x01(\t\x12\x11\n\tavatar_id\x18\x02 \x01(\x03\x12\x0c\n\x04rank\x18\x04 \x01(\x05\x12\r\n\x05\x62\x61\x64ge\x18\x05 \x01(\x05\x12\x11\n\tClan_Name\x18\x08 \x01(\t\x12\x0f\n\x07\x66ield10\x18\n \x01(\x05\x12\x17\n\x0fglobal_rank_pos\x18\x0b \x01(\x05\x12?\n\nbadge_info\x18\r \x01(\x0b\x32+.GenTeamWhisper.Nested2.Nested9.NestedBadge\x12?\n\nprime_info\x18\x0e \x01(\x0b\x32+.GenTeamWhisper.Nested2.Nested9.NestedPrime\x1a\x1c\n\x0bNestedBadge\x12\r\n\x05value\x18\x01 \x01(\x05\x1aH\n\x0bNestedPrime\x12\x11\n\tprime_uid\x18\x01 \x01(\x05\x12\x13\n\x0bprime_level\x18\x02 \x01(\x05\x12\x11\n\tprime_hex\x18\x03 \x01(\t\x1a\x33\n\x08Nested13\x12\x10\n\x08url_type\x18\x02 \x01(\x05\x12\x15\n\rcurl_platform\x18\x03 \x01(\x05\x62\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'Team_msg_pb2', _globals)

if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_GENTEAMWHISPER']._serialized_start = 19
    _globals['_GENTEAMWHISPER']._serialized_end = 807
    _globals['_GENTEAMWHISPER_NESTED2']._serialized_start = 91
    _globals['_GENTEAMWHISPER_NESTED2']._serialized_end = 807
    _globals['_GENTEAMWHISPER_NESTED2_NESTED14']._serialized_start = 371
    _globals['_GENTEAMWHISPER_NESTED2_NESTED14']._serialized_end = 381
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9']._serialized_start = 384
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9']._serialized_end = 754
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9_NESTEDBADGE']._serialized_start = 652
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9_NESTEDBADGE']._serialized_end = 680
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9_NESTEDPRIME']._serialized_start = 682
    _globals['_GENTEAMWHISPER_NESTED2_NESTED9_NESTEDPRIME']._serialized_end = 754
    _globals['_GENTEAMWHISPER_NESTED2_NESTED13']._serialized_start = 756
    _globals['_GENTEAMWHISPER_NESTED2_NESTED13']._serialized_end = 807

# @@protoc_insertion_point(module_scope)