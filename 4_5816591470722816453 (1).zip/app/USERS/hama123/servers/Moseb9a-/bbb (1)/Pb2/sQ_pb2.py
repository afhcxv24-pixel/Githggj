# -*- coding: utf-8 -*-
# Universal Protobuf Safe Version for recieved_chat_pb2
# Auto-generated replacement to work with any protobuf version

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

# Safety patch for runtime_version
try:
    from google.protobuf import runtime_version as _runtime_version
    _runtime_version.ValidateProtobufRuntimeVersion(
        _runtime_version.Domain.PUBLIC, 6, 30, 0, '', 'recieved_chat.proto'
    )
except (ImportError, AttributeError):
    class _runtime_version:
        class Domain:
            PUBLIC = 0
        @staticmethod
        def ValidateProtobufRuntimeVersion(*args, **kwargs):
            pass

_sym_db = _symbol_database.Default()

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x13recieved_chat.proto\"\x80\x01\n\rrecieved_chat\x12\x13\n\x0bpacket_type\x18\x04 \x01(\x03\x12&\n\x07details\x18\x05 \x01(\x0b\x32\x15.recieved_chat.nested\x1a\x32\n\x06nested\x12\x12\n\nplayer_uid\x18\x01 \x01(\x03\x12\x14\n\x0cteam_session\x18\x0e \x01(\tb\x06proto3'
)

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'recieved_chat_pb2', _globals)

if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_RECIEVED_CHAT']._serialized_start = 24
    _globals['_RECIEVED_CHAT']._serialized_end = 152
    _globals['_RECIEVED_CHAT_NESTED']._serialized_start = 102
    _globals['_RECIEVED_CHAT_NESTED']._serialized_end = 152

# @@protoc_insertion_point(module_scope)