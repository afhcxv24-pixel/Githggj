import telebot
from telebot import types
import sqlite3
import threading
import time
from datetime import datetime, timedelta
import requests
import re
import os
from functools import wraps



# ================= CONFIG =================
TOKEN = "8670152153:AAEhv3hx4sF-CD2R2FA8vfUJNFKSHYpSHfY" # توكنك
ADMIN_ID = 8311110459 # ID 
SUPPORT_USERNAME = "IRW_0" #حط هنا اليوزر بتاعك 
UPDATES_CHANNEL = "UI_C5" # حط هنا قناه تحديثات البوتات
DEV_CHANNEL = "UI_C2"     # حط هنا قناتك انت 
BOT_USERNAME = "@haMa_haws_bot" # هنا يوزر بوتك 
photo_url = "https://files.catbox.moe/dst2l6.jpg" # هنا بق متجيش عندها ولو احتاجت تغيرها


bot = telebot.TeleBot(TOKEN, parse_mode="HTML", threaded=True)

# حالات المستخدمين المؤقتة
user_states = {}

# كود الذكاء الاصطناعي لتصليح أخطاء التعديل تلقائياً
def smart_edit_fixer(original_func):
    def wrapper(*args, **kwargs):
        try:
            return original_func(*args, **kwargs)
        except Exception as e:
            error_msg = str(e)
            # لو الخطأ إن الرسالة صورة وأنت بعت نص
            if "there is no text in the message to edit" in error_msg:
                return bot.edit_message_caption(*args, **kwargs)
            # لو الخطأ إن الرسالة نص وأنت بعت كابشن
            elif "there is no caption in the message to edit" in error_msg:
                return bot.edit_message_text(*args, **kwargs)
            # لو فشل تماماً (زي إن الرسالة اتمسحت)، ابعت رسالة جديدة
            else:
                chat_id = kwargs.get('chat_id') or args[1]
                text = kwargs.get('text') or kwargs.get('caption') or args[0]
                markup = kwargs.get('reply_markup')
                return bot.send_message(chat_id, text, reply_markup=markup, parse_mode='HTML')
    return wrapper

# تطبيق "الحقن الذكي" على وظائف المكتبة
bot.edit_message_text = smart_edit_fixer(bot.edit_message_text)
bot.edit_message_caption = smart_edit_fixer(bot.edit_message_caption)

# ================= حذف قاعدة البيانات القديمة وإنشاء جديدة =================
try:
    os.remove("contest_bot_v5.db")
    print("🗑️ تم حذف قاعدة البيانات القديمة")
except:
    print("📁 لا توجد قاعدة بيانات قديمة")

# ================= DATABASE - استخدام connection منفصلة لكل عملية =================
def get_db_connection():
    """إنشاء اتصال جديد بقاعدة البيانات"""
    import sqlite3

    conn = sqlite3.connect("/tmp/contest_bot_v5.db", check_same_thread=False)
    conn.row_factory = sqlite3.Row

    return conn

def init_database():
    """تهيئة قاعدة البيانات وجدولها"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # جدول الإعدادات
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings(
        owner INTEGER PRIMARY KEY,
        force_sub INTEGER DEFAULT 1,
        no_self INTEGER DEFAULT 1,
        one_vote INTEGER DEFAULT 1,
        one_join INTEGER DEFAULT 1,
        remove_leave INTEGER DEFAULT 1,
        anti_spam INTEGER DEFAULT 1,
        notify INTEGER DEFAULT 1,
        no_duplicate INTEGER DEFAULT 1,
        vote_channel TEXT
    )
    """)

    # جدول المستخدمين
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # جدول المسابقات
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS contests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner INTEGER,
        title TEXT,
        description TEXT,
        active INTEGER DEFAULT 1,
        channel_id TEXT,
        channel_username TEXT,
        channel_title TEXT,
        post_message_id INTEGER,
        approval_mode TEXT DEFAULT 'auto',
        type TEXT DEFAULT 'auto',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        scheduled_delete INTEGER DEFAULT 0,
        deleted INTEGER DEFAULT 0
    )
    """)

    # جدول المتسابقين
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS contestants(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contest_id INTEGER,
        user_id INTEGER,
        name TEXT,
        votes INTEGER DEFAULT 0,
        post_message_id INTEGER,
        status TEXT DEFAULT 'approved'
    )
    """)

    # جدول التصويتات
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS votes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contest_id INTEGER,
        contestant_id INTEGER,
        voter_id INTEGER,
        voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(contest_id, voter_id)
    )
    """)

    # جدول الحظر
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bans(
        user_id INTEGER PRIMARY KEY,
        banned_by INTEGER,
        reason TEXT DEFAULT 'بدون سبب',
        banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # جدول قنوات الاشتراك الإجباري
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS force_sub_channels(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        channel_id TEXT UNIQUE,
        channel_username TEXT,
        added_by INTEGER,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # جدول الأدمن
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS admins(
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        added_by INTEGER,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()
    print("✅ تم إنشاء قاعدة البيانات بنجاح")

# تهيئة قاعدة البيانات
init_database()

# ================= وظيفة التحقق من الاشتراك الإجباري الإلزامي =================
def check_subscription_required(user_id):
    """
    التحقق الصارم من اشتراك المستخدم في جميع القنوات الإجبارية
    إذا لم يكن مشتركاً، يمنع من أي إجراء في البوت
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_id, channel_username FROM force_sub_channels")
    channels = cursor.fetchall()
    conn.close()
    
    # إذا لم تكن هناك قنوات اشتراك إجباري، السماح بالاستخدام
    if not channels:
        return True, []
    
    not_subscribed = []
    for channel in channels:
        channel_id = channel[0]
        channel_username = channel[1]
        try:
            if str(channel_id).lstrip('-').isdigit():
                chat_id = int(channel_id)
            else:
                chat_info = bot.get_chat(channel_username)
                chat_id = chat_info.id
                
            member = bot.get_chat_member(chat_id, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                not_subscribed.append((chat_id, channel_username))
        except Exception as e:
            print(f"Error checking subscription for channel {channel_id}: {e}")
            not_subscribed.append((channel_id, channel_username))
            continue
    
    if not_subscribed:
        return False, not_subscribed
    return True, []

def subscription_required(func):
    @wraps(func)
    def wrapper(message_or_call, *args, **kwargs):
        user_id = None
        data = None

        if isinstance(message_or_call, types.Message):
            user_id = message_or_call.from_user.id

        elif isinstance(message_or_call, types.CallbackQuery):
            user_id = message_or_call.from_user.id
            data = message_or_call.data

        # استثناء التصويت من الاشتراك الإجباري العام
        if data and data.startswith("vote_"):
            return func(message_or_call, *args, **kwargs)

        if user_id == ADMIN_ID:
            return func(message_or_call, *args, **kwargs)

        subscribed, not_subscribed = check_subscription_required(user_id)

        if not subscribed:
            try:
                if isinstance(message_or_call, types.CallbackQuery):
                    bot.answer_callback_query(
                        message_or_call.id,
                        "❌ يجب الاشتراك في القنوات أولاً",
                        show_alert=True
                    )
            except:
                pass

            show_subscription_required(user_id, not_subscribed)
            return None

        return func(message_or_call, *args, **kwargs)

    return wrapper



def show_subscription_required(user_id, not_subscribed_channels):
    try:
        keyboard = types.InlineKeyboardMarkup(row_width=1)

        for channel_id, channel_username in not_subscribed_channels:
            try:
                chat = bot.get_chat(channel_username)
                channel_title = chat.title
                keyboard.add(types.InlineKeyboardButton(
                    f"📢 اشترك في {channel_title}",
                    url=f"https://t.me/{channel_username.replace('@','')}",
                    style="danger"
                ))
            except:
                keyboard.add(types.InlineKeyboardButton(
                    "📢 اشترك في القناة",
                    url=f"https://t.me/{channel_username.replace('@','')}",
                    style="danger"
                ))

        keyboard.add(types.InlineKeyboardButton(
            "🔄 تحقق من الاشتراك",
            callback_data="check_sub_force",
            style="success"
        ))

        text = f'''<blockquote>• ⚠️ <b>اشتراك إجباري</b></blockquote>
<blockquote>• 🚫 لا يمكنك استخدام البوت قبل الاشتراك</blockquote>
<blockquote>• 📢 اشترك في القنوات ثم اضغط تحقق ✅</blockquote>'''

        bot.send_message(user_id, text, reply_markup=keyboard)

    except Exception as e:
        print(e)


# ================= وظيفة التحقق من اشتراك المستخدم في قناة المسابقة =================
def check_contest_channel_subscription(user_id, contest_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_id, channel_username, channel_title FROM contests WHERE id = ?", (contest_id,))
    result = cursor.fetchone()
    conn.close()

    if not result or not result[0]:
        return True, None

    channel_id = result[0]
    channel_username = result[1]
    channel_title = result[2]

    try:
        member = bot.get_chat_member(int(channel_id), user_id)

        # أي حالة غير مغادر = يعتبر مشترك
        if member.status not in ["left", "kicked"]:
            return True, None
        else:
            return False, (channel_username, channel_title)

    except Exception as e:
        print("Subscription check error:", e)

        # نعتبره مشترك لتجنب الأخطاء
        return True, None

    except Exception as e:
        print(f"Error checking contest subscription: {e}")
        return False, (channel_username, channel_title)

def show_contest_subscription_required(user_id, contest_info, callback_query_id=None):
    """عرض رسالة اشتراك القناة في البوت فقط - بدون إرسال أي شيء للقناة"""
    try:
        channel_username, channel_title = contest_info
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(types.InlineKeyboardButton(
            f"📢 اشترك في {channel_title}", 
            url=f"https://t.me/{channel_username.replace('@', '')}",
            style="danger"
        ))
        keyboard.add(types.InlineKeyboardButton(
            "🔄 تحقق من الاشتراك",
            callback_data=f"check_contest_sub_{contest_id}",
            style="success"
        ))
        
        text = f"""
<blockquote>• ❌ <b>لم يتم التصويت!</b></blockquote>
<blockquote>• ⚠️ <b>عذراً، أنت غير مشترك في قناة المسابقة.</b></blockquote>
<blockquote>• 📢 <b>القناة المطلوبة:</b> {channel_title}</blockquote>
<blockquote>• 🔗 @{channel_username.replace('@', '')}</blockquote>
<blockquote>• 🔴 <b>يجب الاشتراك في القناة أولاً</b></blockquote>
<blockquote>• ✅ <b>اشترك ثم اضغط على زر التحقق</b></blockquote>
"""
        
        # الرد مباشرة على المستخدم في البوت فقط
        bot.send_message(user_id, text, reply_markup=keyboard)
        
        # إذا كان الطلب من callback، نعرض alert
        if callback_query_id:
            bot.answer_callback_query(callback_query_id, "❌ لم يتم التصويت! يجب الاشتراك في قناة المسابقة.", show_alert=True)
            
        return True
    except Exception as e:
        print(f"Error in show_contest_subscription_required: {e}")
        return False

# ================= وظيفة حذف المسابقات المنتهية =================
def schedule_contest_deletion():
    """جدولة حذف المسابقات بعد 24 ساعة من إنشائها"""
    while True:
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # البحث عن المسابقات التي مضى عليها 24 ساعة ولم تحذف بعد
            one_day_ago = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
            
            cursor.execute("""
                SELECT id, channel_id, post_message_id, owner, title 
                FROM contests 
                WHERE active = 1 AND deleted = 0 AND created_at < ?
            """, (one_day_ago,))
            
            contests_to_delete = cursor.fetchall()
            
            for contest in contests_to_delete:
                contest_id = contest[0]
                channel_id = contest[1]
                post_message_id = contest[2]
                owner_id = contest[3]
                contest_title = contest[4]
                
                # حذف المنشور من القناة
                try:
                    if channel_id and post_message_id:
                        bot.delete_message(int(channel_id), post_message_id)
                        print(f"🗑️ تم حذف منشور المسابقة {contest_id} من القناة")
                except Exception as e:
                    print(f"❌ فشل حذف منشور المسابقة {contest_id}: {e}")
                
                # تحديث حالة المسابقة إلى محذوفة
                cursor.execute("UPDATE contests SET active = 0, deleted = 1 WHERE id = ?", (contest_id,))
                conn.commit()
                
                # إرسال إشعار لصاحب المسابقة
                try:
                    bot.send_message(
                        owner_id,
                        f"🗑️ <b>تم حذف المسابقة تلقائياً</b>\n\n"
                        f"📌 <b>عنوان المسابقة:</b> {contest_title}\n"
                        f"🆔 <b>رقم المسابقة:</b> {contest_id}\n"
                        f"📅 <b>تاريخ الإنشاء:</b> {contest[5] if len(contest) > 5 else 'غير معروف'}\n"
                        f"⏰ <b>تم الحذف بعد 24 ساعة من إنشائها</b>\n\n"
                        f"🔄 يمكنك إنشاء مسابقة جديدة في أي وقت"
                    )
                except Exception as e:
                    print(f"❌ فشل إرسال إشعار لصاحب المسابقة {contest_id}: {e}")
            
            conn.close()
            
        except Exception as e:
            print(f"❌ خطأ في جدولة حذف المسابقات: {e}")
        
        # التحقق كل ساعة
        time.sleep(3600)

# بدء thread لحذف المسابقات المنتهية
deletion_thread = threading.Thread(target=schedule_contest_deletion, daemon=True)
deletion_thread.start()

# ================= UTILITY FUNCTIONS =================
def create_main_keyboard(user_id):
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    
    # السطر الأول - نشر منشور التصويت (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("👥 نشر منشور التصويت", callback_data="publish_vote_post", style="danger")
    )
    
    # السطر الثاني - تعيين قناة التصويت (أخضر) + إنشاء مسابقة (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("📢 تعيين قناة التصويت", callback_data="set_vote_channel", style="primary"),
        types.InlineKeyboardButton("🎯 إنشاء مسابقة", callback_data="create_contest", style="success")
    )
    
    # السطر الثالث - مسابقاتي (أزرق) + إعدادات البوت (أخضر)
    keyboard.row(
        types.InlineKeyboardButton("🏆 مسابقاتي", callback_data="my_contests", style="primary"),
        types.InlineKeyboardButton("⚙️ إعدادات البوت", callback_data="settings", style="success")
    )
    
    # السطر الرابع - إضافة أصوات (أزرق) + خصم أصوات (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("➕ إضافة أصوات", callback_data="add_votes", style="primary"),
        types.InlineKeyboardButton("➖ خصم أصوات", callback_data="remove_votes", style="success")
    )
    
    # السطر الخامس - شرح استخدام البوت (أزرق) + مميزات البوت (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("📖 شرح استخدام البوت", callback_data="tutorial", style="primary"),
        types.InlineKeyboardButton("🖨 مميزات البوت", callback_data="features", style="success")
    )
    
    # السطر السادس - قناة المطور (أحمر) + قناة التحديثات (أخضر)
    keyboard.row(
        types.InlineKeyboardButton("📢 قناة المطور", url=f"https://t.me/{DEV_CHANNEL.replace('','')}", style="primary"),
        types.InlineKeyboardButton("📢 قناة التحديثات", url=f"https://t.me/{UPDATES_CHANNEL.replace('','')}", style="success")
    )
    
    # السطر السابع - الدعم الفني / مطور البوت (أحمر)
    keyboard.row(
        types.InlineKeyboardButton("🧑‍💻 مطور البوت", url=f"https://t.me/{SUPPORT_USERNAME.replace('','')}", style="danger")
    )
    
    # التحقق من صلاحيات الأدمن
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (user_id,))
    is_admin = cursor.fetchone()
    conn.close()
    
    if is_admin or str(user_id) == str(ADMIN_ID):
        keyboard.row(types.InlineKeyboardButton("👑 لوحة التحكم", callback_data="admin_panel", style="danger"))
    
    return keyboard

def show_main_menu(chat_id, user_id,first_name):
    """عرض القائمة الرئيسية مع الرسالة الأصلية"""
  # تعديل المتغير لإضافة مسافات بين الاقتباسات
    main_text = f'''<b>أهلاً بك عزيزي {first_name} في مكانك الأمثل لإنشاء المسابقات ❤️‍🔥</b>

<b>مميزاتنـــــــا :</b>
<blockquote>• ضد الرشق نهائياً</blockquote>
<blockquote>• نظام دقيق جداً</blockquote>
<blockquote>• امكانيه احتساب النجوم كتصويتات</blockquote>
<blockquote>• امكانيه تخصيص كل شيء</blockquote>
<blockquote>• بيئه عادله</blockquote>
<blockquote>• قوه و سرعه في الأداء</blockquote>

<b>و العديد من المميزات الأخرى.... اكتشفها بنفسك الآن 🔥</b>'''
    
    bot.send_photo(
    chat_id=chat_id,               # لمين؟
    photo=photo_url,               # إيه الصورة؟
    caption=main_text,             # إيه الكلام؟
    parse_mode='HTML',             # إزاي يترجم الكلام؟
    reply_markup=create_main_keyboard(user_id) # فين الأزرار؟
)

# ================= HANDLERS =================

@bot.message_handler(commands=['start'])
@subscription_required
def start_cmd(message):
    user_id = message.from_user.id
    username = message.from_user.username or "بدون يوزر"
    first_name = message.from_user.first_name or "مستخدم"
    
    # التحقق من الحظر
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM bans WHERE user_id=?", (user_id,))
    banned = cursor.fetchone()
    conn.close()
    
    if banned:
        bot.send_message(message.chat.id, "🚫 حسابك محظور من استخدام البوت.")
        return
    
    # تسجيل المستخدم
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO users (id, username, first_name) VALUES (?, ?, ?)", 
                   (user_id, username, first_name))
    conn.commit()
    conn.close()
    
    # التحقق من وجود باراميتر start (للمشاركة في مسابقة)
    if len(message.text.split()) > 1:
        param = message.text.split()[1]
        if param.startswith("contest_"):
            contest_id = int(param.replace("contest_", ""))
            
            # التحقق من وجود المسابقة ونشاطها
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT active, deleted FROM contests WHERE id = ?", (contest_id,))
            contest_status = cursor.fetchone()
            conn.close()
            
            if not contest_status or contest_status[0] == 0 or contest_status[1] == 1:
                bot.send_message(
                    message.chat.id,
                    "❌ هذه المسابقة غير متاحة أو تم حذفها."
                )
                show_main_menu(message.chat.id, user_id, message.from_user.first_name)
                return
            
            # التحقق من اشتراك المستخدم في قناة المسابقة
            subscribed, contest_info = check_contest_channel_subscription(user_id, contest_id)
            if not subscribed:
                # تخزين contest_id في callback data
                channel_username, channel_title = contest_info
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                keyboard.add(types.InlineKeyboardButton(
                    f"📢 اشترك في {channel_title}", 
                    url=f"https://t.me/{channel_username.replace('@', '')}",
                    style="danger"
                ))
                keyboard.add(types.InlineKeyboardButton(
                    "🔄 تحقق من الاشتراك",
                    callback_data=f"check_contest_sub_{contest_id}",
                    style="success"
                ))
                
                bot.send_message(
                    message.chat.id,
                    f"""❌ <b>لم تتم المشاركة!</b>

⚠️ <b>لا يمكنك المشاركة في المسابقة لأنك غير مشترك في القناة.</b>

📢 <b>القناة المطلوبة:</b>
{channel_title}
🔗 @{channel_username.replace('@', '')}

🔴 <b>يجب الاشتراك في القناة أولاً</b>
✅ اشترك ثم اضغط على زر التحقق للمشاركة""",
                    reply_markup=keyboard
                )
                return
            
            # بدأ عملية المشاركة في المسابقة فوراً
            user_states[user_id] = {"action": "join_contest", "contest_id": contest_id}
            bot.send_message(
                message.chat.id,
                f"🎯 <b>المشاركة في المسابقة</b>\n\n⚠️ ملاحظة: لن يتم قبول مشاركتك إذا لم تكن مشتركاً في قناة المسابقة!\n\nأرسل اسمك الآن للمشاركة:",
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("❌ إلغاء", callback_data="cancel", style="primary")
                )
            )
            return
    
    # عرض القائمة الرئيسية
    show_main_menu(message.chat.id, user_id, message.from_user.first_name)

@bot.callback_query_handler(func=lambda call: True)
@subscription_required
def handle_all_callbacks(call):
    user_id = call.from_user.id
    data = call.data
    
    # التحقق من الحظر
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM bans WHERE user_id=?", (user_id,))
    banned = cursor.fetchone()
    conn.close()
    
    if banned:
        bot.answer_callback_query(call.id, "🚫 حسابك محظور من استخدام البوت.", show_alert=True)
        return
    
    try:
        if data == "check_sub_force":
            subscribed, not_subscribed = check_subscription_required(user_id)
            if subscribed:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.answer_callback_query(call.id, "✅ تم التحقق! أنت مشترك في جميع القنوات.", show_alert=True)
                show_main_menu(call.message.chat.id, user_id, call.from_user.first_name)
            else:
                bot.answer_callback_query(call.id, "❌ لم تشترك في جميع القنوات بعد!", show_alert=True)
                
                channels_list = "\n".join([f"• @{username.replace('@', '')}" for _, username in not_subscribed])
                
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                for channel_id, channel_username in not_subscribed:
                    try:
                        chat = bot.get_chat(channel_username)
                        channel_title = chat.title
                        keyboard.add(types.InlineKeyboardButton(
                            f"📢 اشتراك في {channel_title}", 
                            url=f"https://t.me/{channel_username.replace('@', '')}",
                            style="danger"
                        ))
                    except:
                        keyboard.add(types.InlineKeyboardButton(
                            f"📢 اشترك في القناة", 
                            url=f"https://t.me/{channel_username.replace('@', '')}",
                            style="danger"
                        ))
                
                keyboard.add(types.InlineKeyboardButton("🔄 تحقق من الاشتراك", callback_data="check_sub_force", style="success"))
                
                text = f"""❌ <b>⚠️ لم تشترك في جميع القنوات!</b>

🔴 <b>ممنوع منعاً باتاً استخدام البوت بدون اشتراك!</b>

القنوات المطلوبة:
{channels_list}

⚠️ يرجى الاشتراك في <b>جميع</b> القنوات أعلاه ثم اضغط "🔄 تحقق من الاشتراك"."""
                
                try:
                    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
                except:
                    bot.send_message(call.message.chat.id, text, reply_markup=keyboard)
        
        elif data.startswith("check_contest_sub_"):
            contest_id = int(data.replace("check_contest_sub_", ""))
            
            subscribed, contest_info = check_contest_channel_subscription(user_id, contest_id)
            if subscribed:
                bot.answer_callback_query(call.id, "✅ أنت مشترك في قناة المسابقة! يمكنك التصويت/المشاركة الآن.", show_alert=True)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                
                # إذا كان المستخدم يحاول المشاركة
                if user_id in user_states and user_states[user_id].get("action") == "join_contest":
                    bot.send_message(
                        user_id,
                        f"🎯 <b>المشاركة في المسابقة</b>\n\n❌ الاسم يجب أن يكون بين 2 و 50 حرفاً.\n\nأرسل اسمك الآن للمشاركة :",
                        reply_markup=types.InlineKeyboardMarkup().add(
                            types.InlineKeyboardButton("❌ إلغاء", callback_data="cancel", style="primary")
                        )
                    )
            else:
                bot.answer_callback_query(call.id, "❌ لم تشترك في قناة المسابقة بعد!", show_alert=True)
        
        elif data.startswith("vote_"):
            parts = data.split("_")
            contest_id = int(parts[1])
            contestant_id = int(parts[2])
            
            # التحقق من اشتراك المستخدم في قناة المسابقة
            subscribed, contest_info = check_contest_channel_subscription(user_id, contest_id)
            if not subscribed:
                # عرض رسالة في البوت فقط - بدون إرسال أي شيء للقناة
                channel_username, channel_title = contest_info
                
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                keyboard.add(types.InlineKeyboardButton(
                    f"📢 اشترك في {channel_title}", 
                    url=f"https://t.me/{channel_username.replace('@', '')}",
                    style="danger"
                ))
                keyboard.add(types.InlineKeyboardButton(
                    "🔄 تحقق من الاشتراك",
                    callback_data=f"check_contest_sub_{contest_id}",
                    style="success"
                ))
                
                bot.send_message(
                    user_id,
                    f"""❌ <b>لم يتم التصويت!</b>

⚠️ <b>لا يمكنك التصويت لأنك غير مشترك في قناة المسابقة.</b>

📢 <b>القناة المطلوبة:</b>
{channel_title}
🔗 @{channel_username.replace('@', '')}

🔴 <b>يجب الاشتراك في القناة أولاً</b>
✅ اشترك ثم اضغط على زر التحقق للتصويت""",
                    reply_markup=keyboard
                )
                
                bot.answer_callback_query(call.id, "❌ لم يتم التصويت! يجب الاشتراك في قناة المسابقة.", show_alert=True)
                return
            
            # التحقق من أن المصوت ليس هو المتسابق نفسه
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT user_id FROM contestants WHERE id = ?", (contestant_id,))
            result = cursor.fetchone()
            
            if not result:
                conn.close()
                bot.answer_callback_query(call.id, "❌ المشارك غير موجود!", show_alert=True)
                return
                
            contestant_user_id = result[0]
            
            if contestant_user_id == user_id:
                conn.close()
                bot.answer_callback_query(call.id, "🚫 لا يمكنك التصويت لنفسك!", show_alert=True)
                return
            
            # التحقق من أن المستخدم لم يصوت من قبل
            cursor.execute("SELECT id FROM votes WHERE contest_id = ? AND voter_id = ?", (contest_id, user_id))
            existing_vote = cursor.fetchone()
            
            if existing_vote:
                conn.close()
                bot.answer_callback_query(call.id, "❌ لقد قمت بالتصويت في هذه المسابقة من قبل!", show_alert=True)
                return
            
            # تسجيل التصويت
            cursor.execute("INSERT INTO votes (contest_id, contestant_id, voter_id) VALUES (?, ?, ?)",
                          (contest_id, contestant_id, user_id))
            cursor.execute("UPDATE contestants SET votes = votes + 1 WHERE id = ?", (contestant_id,))
            conn.commit()
            
            # الحصول على المعلومات المحدثة
            cursor.execute("""
                SELECT c.post_message_id, co.channel_id, c.votes, co.id, c.id
                FROM contestants c
                JOIN contests co ON c.contest_id = co.id
                WHERE c.id = ?
            """, (contestant_id,))
            post_info = cursor.fetchone()
            conn.close()
            
            bot.answer_callback_query(call.id, "✅ تم التصويت بنجاح!", show_alert=True)
            
            # تحديث عداد التصويت في المنشور
            if post_info and post_info[0]:
                try:
                    message_id = post_info[0]
                    channel_id = post_info[1]
                    votes = post_info[2]
                    contest_id = post_info[3]
                    contestant_id = post_info[4]
                    
                    # تحديث الزرين - تحت بعض
                    keyboard = types.InlineKeyboardMarkup(row_width=1)
                    
                    vote_button = types.InlineKeyboardButton(
                        f"👍 تصويت ({votes})", 
                        callback_data=f"vote_{contest_id}_{contestant_id}",
                        style="success"
                    )
                    
                    bot_username = bot.get_me().username
                    contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
                    join_button = types.InlineKeyboardButton(
                        "🎯 المشاركة في المسابقة",
                        url=contest_link,
                        style="danger"
                    )
                    
                    keyboard.add(vote_button)
                    keyboard.add(join_button)
                    
                    bot.edit_message_reply_markup(int(channel_id), message_id, reply_markup=keyboard)
                except Exception as e:
                    print(f"Error updating vote count: {e}")
        
        elif data == "main_menu":
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            show_main_menu(call.message.chat.id, user_id, call.from_user.first_name)
        
        elif data == "publish_vote_post":
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT id, title FROM contests WHERE owner = ? AND active = 1 AND deleted = 0", (user_id,))
            contests = cursor.fetchall()
            conn.close()
            
            if not contests:
                text = "❌ لا توجد مسابقات نشطة لديك.\n\n🎯 قم بإنشاء مسابقة أولاً من قسم 'إنشاء مسابقة'."
                keyboard = types.InlineKeyboardMarkup()
                keyboard.add(types.InlineKeyboardButton("🎯 إنشاء مسابقة", callback_data="create_contest", style="primary"))
                keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="danger"))
                bot.edit_message_caption(caption=text, chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=keyboard, parse_mode='HTML')
                return
            
            text = "📝 <b>اختر المسابقة:</b>\n\n"
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            
            for contest in contests[:10]:
                contest_id = contest[0]
                title = contest[1]
                keyboard.add(types.InlineKeyboardButton(title[:30], callback_data=f"select_contest_{contest_id}", style="primary"))
            
            keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="danger"))
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
        
        elif data.startswith("select_contest_"):
            contest_id = int(data.replace("select_contest_", ""))
            user_states[user_id] = {"action": "publish_post", "contest_id": contest_id}
            
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT title FROM contests WHERE id = ?", (contest_id,))
            contest_title = cursor.fetchone()[0]
            conn.close()
            
            text = f"📝 <b>مسابقة: {contest_title}</b>\n\nأرسل اسم المشارك الذي تريد نشر منشور التصويت له:"
            keyboard = types.InlineKeyboardMarkup()
            keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="publish_vote_post", style="danger"))
            
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
            bot.register_next_step_handler_by_chat_id(call.message.chat.id, process_participant_name)
        
        elif data == "my_contests":
            first_name = call.from_user.first_name
            
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM contests WHERE owner = ? AND deleted = 0", (user_id,))
            contests_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM contests WHERE owner = ? AND deleted = 1", (user_id,))
            deleted_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT vote_channel FROM settings WHERE owner = ?", (user_id,))
            channel_row = cursor.fetchone()
            conn.close()
            
            channels_count = 1 if channel_row and channel_row[0] else 0
            channel_info = ""
            channel_title = "لا توجد قناة"
            if channel_row and channel_row[0]:
                try:
                    chat = bot.get_chat(channel_row[0])
                    channel_title = chat.title
                    channel_info = f"• {chat.title}"
                except:
                    channel_info = "• قناة غير معروفة"
            else:
                channel_info = "• لا توجد قنوات مضافة"

            text = f"""📊 <b>مسابقاتي</b>

👤 <b>اسمك:</b> . {first_name} .
🎯 <b>المسابقات النشطة:</b> {contests_count}
🗑️ <b>المسابقات المحذوفة:</b> {deleted_count}
📢 <b>عدد القنوات:</b> {channels_count}

📝 <b>لبدء الاستخدام:</b>
1️⃣ اضغط على '📢 تعيين قناة التصويت' أولاً
2️⃣ ثم اضغط على '🎯 إنشاء مسابقة'

📢 <b>قنواتك ({channels_count}):</b>
{channel_info}

⏰ <b>ملاحظة:</b> يتم حذف المسابقات تلقائياً بعد 24 ساعة من إنشائها!"""

            keyboard = types.InlineKeyboardMarkup()
            if channels_count > 0:
                keyboard.row(types.InlineKeyboardButton(f"{channel_title} 📢", callback_data="none", style="primary"))
            keyboard.row(
                types.InlineKeyboardButton("🎯 إنشاء مسابقة", callback_data="create_contest", style="danger"),
                types.InlineKeyboardButton("📢 تعيين قناة التصويت", callback_data="set_vote_channel", style="primary")
            )
            keyboard.row(types.InlineKeyboardButton("👥 نشر منشور التصويت", callback_data="publish_vote_post", style="success"))
            keyboard.row(types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="danger"))
            try:
                bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
            except:
                bot.send_message(call.message.chat.id, text, reply_markup=keyboard)

        elif data == "tutorial":
            text = """📖 <b>شرح استخدام بوت المسابقات:</b>

🚀 <b>الخطوات الأساسية:</b>
1️⃣ ارفع البوت مشرف في قناتك مع كل الصلاحيات
2️⃣ اذهب لقسم "📢 تعيين قناة التصويت" وتأكد أن البوت مشرف ثم أرسل رابط القناة
3️⃣ اذهب لقسم "🎯 إنشاء مسابقة" واختر قناتك ثم أرسل جوائز المسابقة
4️⃣ وبس كده! المسابقة منشورة وجاهزة

⚠️ <b>قوانين صارمة:</b>
• ❌ ممنوع التصويت بدون اشتراك في القناة
• ❌ ممنوع المشاركة بدون اشتراك في القناة
• ❌ ممنوع التصويت لنفسك
• ❌ ممنوع التصويت مرتين

🏆 <b>للمشاركة في مسابقة:</b>
1️⃣ اشترك في قناة المسابقة أولاً (إجباري)
2️⃣ اضغط على زر "🎯 المشاركة في المسابقة" في القناة
3️⃣ هتتحول تلقائياً للبوت
4️⃣ أرسل اسمك (بدون روابط أو كلمات محظورة)
5️⃣ سيتم نشر اسمك في القناة مع زرين: "👍 تصويت" و "🎯 مشاركة جديدة"

📊 <b>للتصويت:</b>
1️⃣ اشترك في قناة المسابقة أولاً (إجباري)
2️⃣ اضغط على زر "👍 تصويت" تحت اسم المشارك
3️⃣ سيصوت مباشرة بدون فتح البوت
4️⃣ يمكن التصويت مرة واحدة فقط

⏰ <b>ميزة جديدة:</b>
• 🗑️ يتم حذف المسابقات تلقائياً بعد 24 ساعة من إنشائها

⚙️ <b>إعدادات البوت:</b>
• حظر/فك حظر أعضاء من المسابقات
• عرض قائمة المحظورين

• <b>مطور البوت: زعيم المصري🫦🎀</b>"""
            
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            
            # مميزات البوت (أزرق)
            keyboard.row(
                types.InlineKeyboardButton("🖨 مميزات البوت", callback_data="features", style="primary")
            )
            
            # إنشاء مسابقة (أزرق) + تعيين قناة التصويت (أخضر)
            keyboard.row(
                types.InlineKeyboardButton("🎯 إنشاء مسابقة", callback_data="create_contest", style="primary"),
                types.InlineKeyboardButton("📢 تعيين قناة التصويت", callback_data="set_vote_channel", style="success")
            )
            
            # نشر منشور التصويت (أزرق)
            keyboard.row(
                types.InlineKeyboardButton("👥 نشر منشور التصويت", callback_data="publish_vote_post", style="primary")
            )
            
            # إعدادات البوت (أخضر)
            keyboard.row(
                types.InlineKeyboardButton("⚙️ إعدادات البوت", callback_data="settings", style="success")
            )
            
            # قناة التحديثات (أخضر) + قناة المطور (أحمر)
            keyboard.row(
                types.InlineKeyboardButton("📢 قناة التحديثات", url=f"https://t.me/{UPDATES_CHANNEL.replace('','')}", style="success"),
                types.InlineKeyboardButton("📢 قناة المطور", url=f"https://t.me/{DEV_CHANNEL.replace('','')}", style="danger")
            )
            
            # مطور البوت (أحمر)
            keyboard.row(
                types.InlineKeyboardButton("🧑‍💻 مطور البوت", url=f"https://t.me/{SUPPORT_USERNAME.replace('','')}", style="danger")
            )
            
            # رجوع (أزرق)
            keyboard.row(
                types.InlineKeyboardButton("🔙 رجوع", callback_data="main_menu", style="primary")
            )
            
            bot.edit_message_caption(caption=text, chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=keyboard, parse_mode='HTML')

        elif data == "features":
            text = """
⚡ <b>مميزات بوت المسابقات:</b>

✅ <b>المميزات الرئيسية:</b>
<blockquote>1️⃣ البوت يدير المسابقة تلقائياً بالكامل</blockquote>
<blockquote>2️⃣ يسجل الأعضاء والمشاركين تلقائياً</blockquote>
<blockquote>3️⃣ منع تسجيل عضو مع رابط أو يوزر أو شتيمة في الاسم</blockquote>
<blockquote>4️⃣ 🔴 <b>اشتراك إجباري صارم في القنوات للتصويت والمشاركة</b></blockquote>
<blockquote>5️⃣ البوت يتحقق تلقائياً من المشتركين</blockquote>
<blockquote>6️⃣ لا يتمكن العضو من التصويت لنفسه</blockquote>
<blockquote>7️⃣ لا يتمكن العضو من التصويت مرتين في المسابقة</blockquote>
<blockquote>8️⃣ منع سحب التصويت من متسابق وإضافته لمتسابق آخر</blockquote>
<blockquote>9️⃣ تسجيل إحصائيات دقيقة للمسابقات</blockquote>
<blockquote>🔟 نظام إشعارات للمسابقات</blockquote>
<blockquote>1️⃣1️⃣ نظام موافقة على المشاركين</blockquote>
<blockquote>1️⃣2️⃣ التحكم الكامل في القنوات</blockquote>
<blockquote>1️⃣3️⃣ إضافة منشورات تصويت يدوية</blockquote>
<blockquote>1️⃣4️⃣ إدارة متقدمة للمستخدمين</blockquote>
<blockquote>1️⃣5️⃣ 🗑️ <b>حذف المسابقات تلقائياً بعد 24 ساعة</b></blockquote>

🔥 <b>تم تطوير البوت بواسطة:</b>
<blockquote><b>زعيم المصري🫦🎀</b></blockquote>
"""
            
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            
            # شرح استخدام البوت (أزرق)
            keyboard.row(
                types.InlineKeyboardButton("📖 شرح استخدام البوت", callback_data="tutorial", style="primary")
            )
            
            # قناة التحديثات (أخضر) + قناة المطور (أحمر)
            keyboard.row(
                types.InlineKeyboardButton("📢 قناة التحديثات", url=f"https://t.me/{UPDATES_CHANNEL.replace('','')}", style="success"),
                types.InlineKeyboardButton("📢 قناة المطور", url=f"https://t.me/{DEV_CHANNEL.replace('','')}", style="danger")
            )
            
            # مطور البوت (أحمر)
            keyboard.row(
                types.InlineKeyboardButton("🧑‍💻 مطور البوت", url=f"https://t.me/{SUPPORT_USERNAME.replace('','')}", style="danger")
            )
            
            # رجوع (أزرق)
            keyboard.row(
                types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="primary")
            )
            
            bot.edit_message_caption(caption=text, chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=keyboard, parse_mode='HTML')
        
        elif data == "create_contest":
            # التحقق من وجود قناة تصويت
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT vote_channel FROM settings WHERE owner = ?", (user_id,))
            channel_row = cursor.fetchone()
            conn.close()
            
            if not channel_row or not channel_row[0]:
                bot.answer_callback_query(call.id, "❌ يجب تعيين قناة التصويت أولاً!", show_alert=True)
                return
            
            text = """🎯 <b>إنشاء مسابقة جديدة</b>

⚠️ <b>تنبيه هام:</b>
• المسابقة ستنتهي تلقائياً بعد 24 ساعة من إنشائها
• سيتم حذف منشور المسابقة من القناة تلقائياً
• سيتم إعلامك عند حذف المسابقة

اختر نوع المسابقة التي تريد إنشاءها:

1️⃣ 🎯 <b>إنشاء مسابقة يدوي</b>
2️⃣ ⚡ <b>إنشاء مسابقة تلقائي</b>

اختر نوع المسابقة:"""
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            keyboard.row(
                types.InlineKeyboardButton("⚡ إنشاء مسابقة تلقائي", callback_data="create_auto_contest", style="primary"),
                types.InlineKeyboardButton("🎯 إنشاء مسابقة يدوي", callback_data="create_manual_contest", style="primary")
            )
            keyboard.row(types.InlineKeyboardButton("📋 عرض جميع المسابقات", callback_data="my_contests", style="primary"))
            keyboard.row(types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="danger"))
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)

        elif data == "create_manual_contest":
            text = """🎯 <b>إنشاء مسابقة يدوي</b>

📝 <b>أرسل وصف المسابقة والجوائز:</b>

مثال:
🎁 الجوائز:
1. شرح توثيق حساب تليجرام
2. شرح استخراج فيزات مشحونة
3. شرح إنشاء أرقام واتساب

✨ يمكنك وضع أي محتوى تريده

⚠️ سيتم حذف المسابقة تلقائياً بعد 24 ساعة

↩️ للرجوع، اضغط على زر رجوع"""
            keyboard = types.InlineKeyboardMarkup()
            keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="create_contest", style="danger"))
            msg = bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
            bot.register_next_step_handler(msg, process_manual_contest_description)

        elif data == "create_auto_contest":
            text = """⚡ <b>إنشاء مسابقة تلقائي</b>

❓ هل تريد الموافقة على الأعضاء تلقائياً أم يدوياً؟

✅ <b>الموافقة تلقائية:</b>
- أي عضو يشارك سيتم قبوله تلقائياً
- الاسم ينشر في القناة مباشرة

❌ <b>الموافقة يدوية:</b>
- كل مشارك جديد يحتاج موافقتك
- ستصلك تنبيه لكل مشارك جديد

⚠️ سيتم حذف المسابقة تلقائياً بعد 24 ساعة

اختر نوع الموافقة:"""
            keyboard = types.InlineKeyboardMarkup(row_width=2)
            keyboard.row(
                types.InlineKeyboardButton("✅ موافقة تلقائية", callback_data="set_approval_auto", style="success"),
                types.InlineKeyboardButton("❌ موافقة يدوية", callback_data="set_approval_manual", style="danger")
            )
            keyboard.row(types.InlineKeyboardButton("↩️ رجوع", callback_data="create_contest", style="danger"))
            bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)

        elif data.startswith("set_approval_"):
            mode = data.replace("set_approval_", "")
            user_states[user_id] = {"approval_mode": mode, "contest_type": "auto"}
            mode_text = "تلقائية" if mode == "auto" else "يدوية"
            bot.answer_callback_query(call.id, f"✅ تم اختيار الموافقة {mode_text}")
            msg = bot.send_message(call.message.chat.id, "🎯 حسناً، أرسل الآن عنوان المسابقة:")
            bot.register_next_step_handler(msg, process_contest_title)

        elif data == "set_vote_channel":
            text = """📢 <b>تعيين قناة التصويت</b>

أرسل رابط القناة أو اليوزر:
مثال:
@channel_username
أو
https://t.me/channel_username

⚠️ يجب أن يكون البوت مشرفاً في القناة
⚠️ يجب أن تكون أنت مشرفاً في القناة

↩️ للرجوع، اضغط على زر رجوع"""
            keyboard = types.InlineKeyboardMarkup()
            keyboard.add(types.InlineKeyboardButton("🔙 رجوع", callback_data="main_menu", style="danger"))
            msg = bot.edit_message_caption(caption=text, chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=keyboard, parse_mode='HTML')
            bot.register_next_step_handler(msg, process_set_channel)

        elif data == "settings":
            settings_menu(call)

        elif data.startswith("toggle_"):
            setting = data.replace("toggle_", "")
            settings_map = {"force_sub": "force_sub", "no_self": "no_self", "one_vote": "one_vote", 
                           "one_join": "one_join", "remove_leave": "remove_leave", "anti_spam": "anti_spam", 
                           "notify": "notify", "no_duplicate": "no_duplicate"}
            if setting in settings_map:
                column = settings_map[setting]
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute(f"UPDATE settings SET {column} = 1 - {column} WHERE owner = ?", (user_id,))
                conn.commit()
                conn.close()
                settings_menu(call)

        elif data == "reset_settings":
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE settings SET force_sub=1, no_self=1, one_vote=1, one_join=1, remove_leave=1, anti_spam=1, notify=1, no_duplicate=1 WHERE owner=?", (user_id,))
            conn.commit()
            conn.close()
            bot.answer_callback_query(call.id, "🔄 تم إعادة تعيين كافة الإعدادات")
            settings_menu(call)

        elif data == "settings_help":
            help_text = """
<b>📊 شرح إعدادات المسابقات:</b>

<blockquote>📢 الاشتراك الإجباري: يجب على المصوت الاشتراك في قناتك ليتم احتساب صوته.</blockquote>
<blockquote>🚫 منع التصويت لنفسك: لا يمكن للمتسابق التصويت لنفسه.</blockquote>
<blockquote>☝️ التصويت مرة واحدة: يمكن لكل مستخدم التصويت مرة واحدة فقط في المسابقة.</blockquote>
<blockquote>🎟 المشاركة مرة واحدة: لا يمكن للمستخدم المشاركة بأكثر من اسم في نفس المسابقة.</blockquote>
<blockquote>🔄 سحب الأصوات: إذا غادر المصوت القناة، يتم خصم صوته تلقائياً.</blockquote>
<blockquote>🛡 حماية الرشق: نظام ذكي لاكتشاف وحظر الحسابات الوهمية.</blockquote>
<blockquote>🔔 التنبيهات: إرسال تنبيه لك عند دخول متسابق جديد أو وصول تصويت.</blockquote>
<blockquote>⛔ منع الأسماء المكررة: لا يمكن لمتسابقين مختلفين المشاركة بنفس الاسم.</blockquote>

<b>⚠️ ملاحظة هامة:</b>
<blockquote>الاشتراك الإجباري في القنوات إلزامي ولا يمكن لأي مستخدم التصويت أو المشاركة بدون اشتراك!</blockquote>
"""
            keyboard = types.InlineKeyboardMarkup()
            keyboard.add(types.InlineKeyboardButton("↩️ رجوع للإعدادات", callback_data="settings", style="primary"))
            bot.edit_message_text(help_text, call.message.chat.id, call.message.message_id, reply_markup=keyboard,parse_mode="HTML")

        elif data == "ban_user_menu":
            msg = bot.send_message(call.message.chat.id, "⛔ أرسل (ID) العضو الذي تريد حظره من المسابقات:")
            bot.register_next_step_handler(msg, process_ban_user)

        elif data == "unban_user_menu":
            msg = bot.send_message(call.message.chat.id, "✅ أرسل (ID) العضو الذي تريد فك الحظر عنه:")
            bot.register_next_step_handler(msg, process_unban_user)

        elif data == "show_banned":
            show_banned_users(call)

        elif data in ["add_votes", "remove_votes"]:
            action_text = "إضافة" if data == "add_votes" else "خصم"
            symbol = "➕" if data == "add_votes" else "➖"
            text = f"{symbol} <b>{action_text} أصوات لمشارك</b>\n\nأرسل رابط المنشور الخاص بالمشارك:\nمثال:\nhttps://t.me/d_svx_2\n\n⚠️ يجب أن تكون صاحب المسابقة\n\n↩️ للرجوع، اضغط على زر رجوع"
            keyboard = types.InlineKeyboardMarkup()
            keyboard.add(types.InlineKeyboardButton("🔙 رجوع", callback_data="main_menu", style="danger"))
            msg = bot.edit_message_caption(caption=text, chat_id=call.message.chat.id, message_id=call.message.message_id, reply_markup=keyboard, parse_mode='HTML')
            bot.register_next_step_handler(msg, process_votes_link, data)
        
        elif data == "admin_panel":
            admin_panel(call)
        
        elif data.startswith("admin_"):
            handle_admin_commands(call)
        
        elif data == "cancel":
            if user_id in user_states:
                del user_states[user_id]
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass
            show_main_menu(call.message.chat.id, user_id, call.from_user.first_name)
    
    except Exception as e:
        print(f"Error in callback: {e}")
        import traceback
        traceback.print_exc()
        bot.answer_callback_query(call.id, "❌ حدث خطأ، يرجى المحاولة مرة أخرى")

# ================= دالة عرض المحظورين =================
def show_banned_users(call):
    """عرض قائمة الأعضاء المحظورين"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT b.user_id, b.reason, b.banned_at, u.username, u.first_name 
        FROM bans b
        LEFT JOIN users u ON b.user_id = u.id
        ORDER BY b.banned_at DESC
        LIMIT 50
    """)
    banned_users = cursor.fetchall()
    conn.close()
    
    if not banned_users:
        text = "📋 <b>قائمة الأعضاء المحظورين:</b>\n\nلا يوجد أعضاء محظورين حالياً. ✅"
    else:
        text = "📋 <b>قائمة الأعضاء المحظورين:</b>\n\n"
        
        for i, row in enumerate(banned_users, 1):
            user_id = row[0]
            reason = row[1]
            banned_at = row[2]
            username = row[3]
            first_name = row[4]
            
            name = f"@{username}" if username else (first_name or f"مستخدم {user_id}")
            text += f"{i}. {name} (<code>{user_id}</code>)\n"
            text += f"   السبب: {reason}\n"
            text += f"   التاريخ: {banned_at[:10] if banned_at else 'غير معروف'}\n\n"
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="settings", style="danger"))
    
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)

# ================= دالة نشر منشور التصويت اليدوي =================
def process_participant_name(message):
    user_id = message.from_user.id
    if user_id not in user_states or user_states[user_id].get("action") != "publish_post":
        return
    
    participant_name = message.text.strip()
    if not participant_name:
        bot.send_message(message.chat.id, "❌ يرجى إرسال اسم صحيح.")
        return
    
    contest_id = user_states[user_id]["contest_id"]
    user_states[user_id]["participant_name"] = participant_name
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT title, channel_id FROM contests WHERE id = ? AND active = 1 AND deleted = 0", (contest_id,))
    contest_info = cursor.fetchone()
    conn.close()
    
    if contest_info:
        contest_title = contest_info[0]
        channel_id = contest_info[1]
        
        try:
            chat = bot.get_chat(int(channel_id))
            bot_username = bot.get_me().username
            contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
            
            post_text = f"""🎯 <b>مسابقة: {contest_title}</b>

👤 <b>المشارك:</b> {participant_name}

👇 للتصويت اضغط على الزر أدناه:"""
            
            keyboard = types.InlineKeyboardMarkup(row_width=1)
            
            vote_button = types.InlineKeyboardButton(
                f"👍 تصويت (0)", 
                callback_data=f"vote_{contest_id}_{user_id}",
                style="success"
            )
            
            join_button = types.InlineKeyboardButton(
                "🎯 المشاركة في المسابقة",
                url=contest_link,
                style="danger"
            )
            
            keyboard.add(vote_button)
            keyboard.add(join_button)
            
            sent_message = bot.send_message(int(channel_id), post_text, reply_markup=keyboard)
            
            post_link = f"https://t.me/{chat.username}/{sent_message.message_id}"
            
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO contestants (contest_id, user_id, name, post_message_id, status) 
                VALUES (?, ?, ?, ?, 'approved')
            """, (contest_id, user_id, participant_name, sent_message.message_id))
            conn.commit()
            conn.close()
            
            bot.send_message(
                message.chat.id,
                f"✅ تم نشر منشور التصويت بنجاح!\n\n📝 <b>المشارك:</b> {participant_name}\n🔗 <b>رابط المنشور:</b> {post_link}",
                disable_web_page_preview=True
            )
            
            show_main_menu(message.chat.id, user_id, message.from_user.first_name)
            
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ حدث خطأ في النشر: {str(e)}")
            import traceback
            traceback.print_exc()
    else:
        bot.send_message(message.chat.id, "❌ لم يتم العثور على المسابقة أو أنها منتهية.")
    
    if user_id in user_states:
        del user_states[user_id]

# ================= دوال إنشاء المسابقات =================
def process_manual_contest_description(message):
    """معالجة وصف المسابقة اليدوية"""
    user_id = message.from_user.id
    
    if message.text == "↩️ رجوع":
        return
    
    user_states[user_id] = {"contest_type": "manual", "description": message.text}
    
    msg = bot.send_message(
        message.chat.id,
        "🎯 حسناً، أرسل الآن عنوان المسابقة:"
    )
    bot.register_next_step_handler(msg, process_manual_contest_title)

def process_manual_contest_title(message):
    """معالجة عنوان المسابقة اليدوية"""
    user_id = message.from_user.id
    
    if user_id not in user_states or user_states[user_id].get("contest_type") != "manual":
        return
    
    title = message.text.strip()
    description = user_states[user_id]["description"]
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT vote_channel FROM settings WHERE owner = ?", (user_id,))
    result = cursor.fetchone()
    
    if not result:
        conn.close()
        bot.send_message(message.chat.id, "❌ لم يتم تعيين قناة تصويت بعد!")
        return
    
    channel_id = result[0]
    conn.close()
    
    try:
        chat = bot.get_chat(int(channel_id))
        channel_username = chat.username
        channel_title = chat.title
        bot_username = bot.get_me().username
        
        # إنشاء المسابقة في قاعدة البيانات
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO contests (owner, title, description, channel_id, channel_username, channel_title, approval_mode, type, scheduled_delete)
            VALUES (?, ?, ?, ?, ?, ?, 'auto', 'manual', 1)
        """, (user_id, title, description, str(channel_id), channel_username, channel_title))
        conn.commit()
        contest_id = cursor.lastrowid
        conn.close()
        
        # إنشاء منشور المسابقة في القناة - زرار واحد بس
        post_text = f"""🎯 <b>مسابقة قناة "{channel_title}" ...</b>

{description}

⚠️ <b>تنبيه:</b> هذه المسابقة ستنتهي تلقائياً بعد 24 ساعة من الآن!"""
        
        contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton("🎯 المشاركة في المسابقة", url=contest_link, style="danger")
        )
        
        sent_message = bot.send_message(int(channel_id), post_text, reply_markup=keyboard)
        
        # حفظ معلومات المنشور
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE contests SET post_message_id = ? WHERE id = ?", 
                      (sent_message.message_id, contest_id))
        conn.commit()
        conn.close()
        
        bot.send_message(
            message.chat.id,
            f"✅ تم إنشاء المسابقة ونشرها في القناة بنجاح!\n\n"
            f"📌 <b>عنوان المسابقة:</b> {title}\n"
            f"🆔 <b>رقم المسابقة:</b> {contest_id}\n"
            f"⏰ <b>سيتم حذف المسابقة تلقائياً بعد 24 ساعة</b>\n\n"
            f"🗓️ <b>تاريخ الإنشاء:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"🗑️ <b>تاريخ الحذف:</b> {(datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')}",
            reply_markup=create_main_keyboard(user_id)
        )
        
        del user_states[user_id]
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ حدث خطأ في إنشاء المسابقة: {str(e)}")
        import traceback
        traceback.print_exc()

def process_contest_title(message):
    """معالجة عنوان المسابقة التلقائية"""
    user_id = message.from_user.id
    
    if user_id not in user_states:
        return
    
    title = message.text.strip()
    approval_mode = user_states[user_id]["approval_mode"]
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT vote_channel FROM settings WHERE owner = ?", (user_id,))
    result = cursor.fetchone()
    
    if not result:
        conn.close()
        bot.send_message(message.chat.id, "❌ لم يتم تعيين قناة تصويت بعد!")
        return
    
    channel_id = result[0]
    conn.close()
    
    try:
        chat = bot.get_chat(int(channel_id))
        channel_username = chat.username
        channel_title = chat.title
        bot_username = bot.get_me().username
        
        # إنشاء المسابقة في قاعدة البيانات
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO contests (owner, title, channel_id, channel_username, channel_title, approval_mode, type, scheduled_delete)
            VALUES (?, ?, ?, ?, ?, ?, 'auto', 1)
        """, (user_id, title, str(channel_id), channel_username, channel_title, approval_mode))
        conn.commit()
        contest_id = cursor.lastrowid
        conn.close()
        
        # إنشاء منشور المسابقة في القناة - زرار واحد بس
        post_text = f"""🎯 <b>مسابقة قناة "{channel_title}" ...</b>

{title}

⚠️ <b>تنبيه:</b> هذه المسابقة ستنتهي تلقائياً بعد 24 ساعة من الآن!"""
        
        contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
        
        keyboard = types.InlineKeyboardMarkup(row_width=1)
        keyboard.add(
            types.InlineKeyboardButton("🎯 المشاركة في المسابقة", url=contest_link, style="danger")
        )
        
        sent_message = bot.send_message(int(channel_id), post_text, reply_markup=keyboard)
        
        # حفظ معلومات المنشور
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE contests SET post_message_id = ? WHERE id = ?", 
                      (sent_message.message_id, contest_id))
        conn.commit()
        conn.close()
        
        bot.send_message(
            message.chat.id,
            f"✅ تم إنشاء المسابقة ونشرها في القناة بنجاح!\n\n"
            f"📌 <b>عنوان المسابقة:</b> {title}\n"
            f"🆔 <b>رقم المسابقة:</b> {contest_id}\n"
            f"⏰ <b>سيتم حذف المسابقة تلقائياً بعد 24 ساعة</b>\n\n"
            f"🗓️ <b>تاريخ الإنشاء:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"🗑️ <b>تاريخ الحذف:</b> {(datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')}",
            reply_markup=create_main_keyboard(user_id)
        )
        
        del user_states[user_id]
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ حدث خطأ في إنشاء المسابقة: {str(e)}")
        import traceback
        traceback.print_exc()

# ================= دالة تعيين قناة التصويت =================
def process_set_channel(message):
    """معالجة تعيين قناة التصويت"""
    if message.text == "🔙 رجوع":
        return
    
    user_id = message.from_user.id
    channel_input = message.text.strip()
    
    if "t.me/" in channel_input:
        channel_username = "@" + channel_input.split("t.me/")[1].split("/")[0]
    else:
        channel_username = channel_input if channel_input.startswith("@") else "@" + channel_input
    
    try:
        chat = bot.get_chat(channel_username)
        
        if chat.type not in ["channel", "supergroup"]:
            bot.send_message(message.chat.id, "❌ يجب أن يكون الرابط لقناة.")
            return
        
        # التحقق من أن البوت مشرف
        bot_member = bot.get_chat_member(chat.id, bot.get_me().id)
        if bot_member.status != "administrator":
            bot.send_message(message.chat.id, "❌ البوت ليس مشرفاً في هذه القناة. يرجى رفعه مشرفاً أولاً.")
            return
        
        # التحقق من أن المستخدم مشرف
        user_member = bot.get_chat_member(chat.id, user_id)
        if user_member.status not in ["administrator", "creator"] and user_id != ADMIN_ID:
            bot.send_message(message.chat.id, "❌ يجب أن تكون أنت مشرفاً في القناة لتعيينها.")
            return
        
        # حفظ القناة في الإعدادات
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT owner FROM settings WHERE owner=?", (user_id,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO settings (owner, vote_channel) VALUES (?, ?)", 
                          (user_id, str(chat.id)))
        else:
            cursor.execute("UPDATE settings SET vote_channel = ? WHERE owner = ?", 
                          (str(chat.id), user_id))
        conn.commit()
        conn.close()
        
        bot.send_message(
            message.chat.id,
            f"✅ تم تعيين القناة بنجاح!\n\n"
            f"📢 <b>القناة:</b> {chat.title}\n"
            f"🆔 <b>ID:</b> <code>{chat.id}</code>",
            reply_markup=create_main_keyboard(user_id)
        )
        
    except Exception as e:
        bot.send_message(
            message.chat.id,
            f"❌ حدث خطأ: تأكد من صحة اليوزر وأن البوت مضاف للقناة.\n\nالخطأ: {str(e)}"
        )

# ================= قائمة الإعدادات =================
def settings_menu(call):
    user_id = call.from_user.id
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM settings WHERE owner=?", (user_id,))
    row = cursor.fetchone()
    
    if not row:
        cursor.execute("INSERT INTO settings (owner) VALUES (?)", (user_id,))
        conn.commit()
        cursor.execute("SELECT * FROM settings WHERE owner=?", (user_id,))
        row = cursor.fetchone()
    
    conn.close()
    
    def s(x): return "✅" if x else "❌"
    
    # دالة لتحديد لون الزر حسب الحالة (أخضر مفعل، أحمر معطل)
    def get_style(value):
        return "success" if value else "danger"
    
    text = f"""⚙️ <b>الإعدادات المتقدمة للمسابقات</b>

📌 كل تغيير يؤثر على مسابقاتك فقط

⚠️ <b>ملاحظة هامة:</b>
• الاشتراك الإجباري في القنوات إلزامي للمستخدمين
• لا يمكن لأي مستخدم التصويت أو المشاركة بدون اشتراك

✨ الإعدادات متاحة في أي وقت
🔄 يمكنك التغيير وقتما تشاء

📊 <b>حالة الإعدادات الحالية:</b>
{s(row[1])} 📢 الاشتراك الإجباري في القنوات (إلزامي)
{s(row[2])} 🚫 منع التصويت لنفس
{s(row[3])} ☝️ التصويت مرة واحدة فقط
{s(row[4])} 🎟 المشاركة مرة واحدة فقط
{s(row[5])} 🔄 سحب الأصوات عند المغادرة
{s(row[6])} 🛡 حماية التصويت من الرشق
{s(row[7])} 🔔 تنبيهات المسابقة
{s(row[8])} ⛔ منع الأسماء المكررة

🔧 <b>اختر الإعداد الذي تريد تعديله:</b>"""
    
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    
    # الصف الأول
    keyboard.row(
        types.InlineKeyboardButton(f"🚫 منع التصويت للنفس {s(row[2])}", callback_data="toggle_no_self", style=get_style(row[2])),
        types.InlineKeyboardButton(f"📢 اشتراك إجباري {s(row[1])}", callback_data="toggle_force_sub", style=get_style(row[1]))
    )
    
    # الصف الثاني
    keyboard.row(
        types.InlineKeyboardButton(f"🎟 مشاركة مرة واحدة {s(row[4])}", callback_data="toggle_one_join", style=get_style(row[4])),
        types.InlineKeyboardButton(f"☝️ تصويت مرة واحدة {s(row[3])}", callback_data="toggle_one_vote", style=get_style(row[3]))
    )
    
    # الصف الثالث
    keyboard.row(
        types.InlineKeyboardButton(f"🛡 حماية من الرشق {s(row[6])}", callback_data="toggle_anti_spam", style=get_style(row[6])),
        types.InlineKeyboardButton(f"🔄 سحب عند المغادرة {s(row[5])}", callback_data="toggle_remove_leave", style=get_style(row[5]))
    )
    
    # الصف الرابع
    keyboard.row(
        types.InlineKeyboardButton(f"⛔ منع تكرار الأسماء {s(row[8])}", callback_data="toggle_no_duplicate", style=get_style(row[8])),
        types.InlineKeyboardButton(f"🔔 تنبيهات المسابقة {s(row[7])}", callback_data="toggle_notify", style=get_style(row[7]))
    )
    
    # الصف الخامس - أزرار إدارة الحظر (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("⛔ حظر عضو", callback_data="ban_user_menu", style="primary"),
        types.InlineKeyboardButton("✅ فك حظر عضو", callback_data="unban_user_menu", style="primary")
    )
    
    # الصف السادس
    keyboard.row(
        types.InlineKeyboardButton("📋 عرض المحظورين", callback_data="show_banned", style="primary")
    )
    
    # الصف السابع
    keyboard.row(
        types.InlineKeyboardButton("📊 شرح الإعدادات", callback_data="settings_help", style="primary"),
        types.InlineKeyboardButton("🔄 إعادة تعيين الكل", callback_data="reset_settings", style="primary")
    )
    
    # الصف الثامن - رجوع (أزرق)
    keyboard.row(
        types.InlineKeyboardButton("↩️ رجوع للقائمة الرئيسية", callback_data="main_menu", style="danger")
    )
    
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)

# ================= دوال الحظر وفك الحظر =================
def process_ban_user(message):
    try:
        user_id = int(message.text)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO bans (user_id, banned_by, reason) VALUES (?, ?, ?)", 
                      (user_id, message.from_user.id, "حظر من قبل مالك المسابقة"))
        conn.commit()
        conn.close()
        bot.send_message(message.chat.id, f"✅ تم حظر العضو {user_id} بنجاح من المسابقات.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط).")

def process_unban_user(message):
    try:
        user_id = int(message.text)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM bans WHERE user_id = ?", (user_id,))
        conn.commit()
        conn.close()
        bot.send_message(message.chat.id, f"✅ تم فك حظر العضو {user_id} بنجاح.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط).")

# ================= دالة إضافة/خصم الأصوات =================
def process_votes_link(message, action):
    if message.text == "🔙 رجوع":
        return
    
    link = message.text.strip()
    
    try:
        parts = link.split('/')
        channel_username = parts[-2]
        message_id = int(parts[-1])
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.id, c.contest_id, c.name, co.owner 
            FROM contestants c
            JOIN contests co ON c.contest_id = co.id
            WHERE c.post_message_id = ? AND co.channel_username = ?
        """, (message_id, channel_username))
        
        contestant = cursor.fetchone()
        conn.close()
        
        if not contestant:
            bot.send_message(message.chat.id, "❌ لم يتم العثور على مشارك بهذا الرابط.")
            return
        
        contestant_id = contestant[0]
        contest_id = contestant[1]
        name = contestant[2]
        contest_owner = contestant[3]
        
        if contest_owner != message.from_user.id:
            bot.send_message(message.chat.id, "⚠️ يجب أن تكون صاحب المسابقة.")
            return
        
        user_states[message.from_user.id] = {
            "action": f"{action}_final",
            "contestant_id": contestant_id,
            "name": name
        }
        
        bot.send_message(
            message.chat.id,
            f"👤 <b>المشارك:</b> {name}\n"
            f"🔢 أرسل عدد الأصوات المراد {'إضافتها' if action == 'add_votes' else 'خصمها'}:"
        )
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ رابط غير صحيح: {str(e)}")

# ================= دالة معالجة المشاركة في المسابقة =================
@bot.message_handler(func=lambda message: message.from_user.id in user_states and 
                     user_states[message.from_user.id].get("action") == "join_contest")
@subscription_required
def handle_join_contest(message):
    """معالجة مشاركة مستخدم في مسابقة"""
    user_id = message.from_user.id
    state = user_states[user_id]
    contest_id = state["contest_id"]
    participant_name = message.text.strip()
    
    # التحقق من وجود المسابقة ونشاطها
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT active, deleted FROM contests WHERE id = ?", (contest_id,))
    contest_status = cursor.fetchone()
    
    if not contest_status or contest_status[0] == 0 or contest_status[1] == 1:
        conn.close()
        bot.send_message(message.chat.id, "❌ هذه المسابقة غير متاحة أو تم حذفها.")
        del user_states[user_id]
        return
    
    # التحقق من صحة الاسم
    if len(participant_name) < 2 or len(participant_name) > 50:
        bot.send_message(message.chat.id, "❌ الاسم يجب أن يكون بين 2 و 50 حرفاً للاسف تم احتسابك ك مشارك..يجب عليك الرجوع لضغط على زر مشاركه واتبع التعليمات .")
        return
    
    if re.search(r'@|http|t\.me|bit\.ly|\.com', participant_name, re.IGNORECASE):
        bot.send_message(message.chat.id, "❌ الاسم لا يمكن أن يحتوي على روابط أو يوزرات.")
        return
    
    try:
        # التحقق من اشتراك المستخدم في قناة المسابقة (إجباري)
        subscribed, contest_info = check_contest_channel_subscription(user_id, contest_id)
        if not subscribed:
            conn.close()
            channel_username, channel_title = contest_info
            
            keyboard = types.InlineKeyboardMarkup(row_width=1)
            keyboard.add(types.InlineKeyboardButton(
                f"📢 اشترك في {channel_title}", 
                url=f"https://t.me/{channel_username.replace('@', '')}",
                style="danger"
            ))
            keyboard.add(types.InlineKeyboardButton(
                "🔄 تحقق من الاشتراك",
                callback_data=f"check_contest_sub_{contest_id}",
                style="success"
            ))
            
            bot.send_message(
                message.chat.id,
                f"""❌ <b>لم تتم المشاركة!</b>

⚠️ <b>لا يمكنك المشاركة في المسابقة لأنك غير مشترك في القناة.</b>

📢 <b>القناة المطلوبة:</b>
{channel_title}
🔗 @{channel_username.replace('@', '')}

🔴 <b>يجب الاشتراك في القناة أولاً</b>
✅ اشترك ثم اضغط على زر التحقق للمشاركة""",
                reply_markup=keyboard
            )
            del user_states[user_id]
            return
        
        # التحقق من أن المستخدم لم يشارك من قبل
        cursor.execute("SELECT id FROM contestants WHERE contest_id = ? AND user_id = ?", (contest_id, user_id))
        if cursor.fetchone():
            conn.close()
            bot.send_message(message.chat.id, "❌ لقد شاركت في هذه المسابقة من قبل!")
            del user_states[user_id]
            return
        
        # جلب معلومات المسابقة
        cursor.execute("""
            SELECT id, title, channel_id, channel_username, channel_title, approval_mode 
            FROM contests 
            WHERE id = ? AND active = 1 AND deleted = 0
        """, (contest_id,))
        contest = cursor.fetchone()
        
        if not contest:
            conn.close()
            bot.send_message(message.chat.id, "❌ المسابقة غير موجودة أو منتهية.")
            del user_states[user_id]
            return
        
        contest_id = contest[0]
        contest_title = contest[1]
        channel_id = contest[2]
        channel_username = contest[3]
        channel_title = contest[4]
        approval_mode = contest[5]
        
        # إضافة المتسابق
        status = "approved" if approval_mode == "auto" else "pending"
        
        cursor.execute("""
            INSERT INTO contestants (contest_id, user_id, name, status)
            VALUES (?, ?, ?, ?)
        """, (contest_id, user_id, participant_name, status))
        conn.commit()
        
        contestant_id = cursor.lastrowid
        conn.close()
        
        # إذا كانت الموافقة تلقائية، نشر المشارك في القناة
        if status == "approved":
            try:
                # إنشاء منشور المشارك - مع زرين تحت بعض
                post_text = f"""🎯 <b>مسابقة قناة "{channel_title}" ...</b>

{participant_name} 🫦🎀

👇 للتصويت اضغط على الزر أدناه:

⚠️ يجب الاشتراك في القناة للتصويت!"""
                
                bot_username = bot.get_me().username
                contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
                
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                
                vote_button = types.InlineKeyboardButton(
                    f"🫦♥ تصويت (0)",
                    callback_data=f"vote_{contest_id}_{contestant_id}",
                    style="success"
                )
                
                join_button = types.InlineKeyboardButton(
                    "🎯 المشاركة في المسابقة",
                    url=contest_link,
                    style="danger"
                )
                
                keyboard.add(vote_button)
                keyboard.add(join_button)
                
                sent_message = bot.send_message(int(channel_id), post_text, reply_markup=keyboard)
                
                # حفظ رابط المنشور
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE contestants SET post_message_id = ? WHERE id = ?", 
                             (sent_message.message_id, contestant_id))
                conn.commit()
                conn.close()
                
                bot.send_message(
                    message.chat.id,
                    f"✅ تمت المشاركة بنجاح!\n\n"
                    f"👤 <b>اسمك:</b> {participant_name}\n"
                    f"📢 <b>تم نشر اسمك في القناة</b>\n\n"
                    f"⚠️ ملاحظة: لن يتم احتساب أي تصويت للمشتركين غير الموجودين في القناة!\n\n"
                    f"👍 شارك الرابط مع أصدقائك ليصوتوا لك!"
                )
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ حدث خطأ في النشر: {str(e)}")
        else:
            # الموافقة يدوية
            bot.send_message(
                message.chat.id,
                f"✅ تم إرسال طلب المشاركة!\n\n"
                f"👤 <b>اسمك:</b> {participant_name}\n"
                f"⏳ في انتظار موافقة صاحب المسابقة."
            )
            
            # إرسال إشعار لصاحب المسابقة
            try:
                owner_keyboard = types.InlineKeyboardMarkup()
                owner_keyboard.row(
                    types.InlineKeyboardButton("✅ قبول", callback_data=f"approve_{contestant_id}", style="success"),
                    types.InlineKeyboardButton("❌ رفض", callback_data=f"reject_{contestant_id}", style="danger")
                )
                
                bot.send_message(
                    contest[0],  # owner_id
                    f"🆕 <b>طلب مشاركة جديد</b>\n\n"
                    f"👤 <b>المستخدم:</b> {participant_name}\n"
                    f"🎯 <b>المسابقة:</b> {contest_title}\n"
                    f"🆔 <b>ID:</b> <code>{user_id}</code>",
                    reply_markup=owner_keyboard
                )
            except:
                pass
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ حدث خطأ: {str(e)}")
        import traceback
        traceback.print_exc()
    
    # تنظيف الحالة
    del user_states[user_id]
    
    # عرض القائمة الرئيسية
    show_main_menu(message.chat.id, user_id, message.from_user.first_name)

# ================= دالة معالجة إضافة/خصم الأصوات =================
@bot.message_handler(func=lambda message: message.from_user.id in user_states and 
                     "_final" in user_states[message.from_user.id].get("action", ""))
def handle_votes_amount(message):
    try:
        amount = int(message.text)
        
        if amount <= 0:
            bot.send_message(message.chat.id, "❌ يرجى إرسال عدد صحيح موجب.")
            return
        
        state = user_states[message.from_user.id]
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if "add" in state["action"]:
            cursor.execute("UPDATE contestants SET votes = votes + ? WHERE id = ?", 
                          (amount, state["contestant_id"]))
            action_text = "إضافة"
        else:
            cursor.execute("UPDATE contestants SET votes = MAX(0, votes - ?) WHERE id = ?", 
                          (amount, state["contestant_id"]))
            action_text = "خصم"
        
        conn.commit()
        
        # الحصول على المعلومات المحدثة
        cursor.execute("""
            SELECT c.post_message_id, co.channel_id, c.votes, co.id, c.id
            FROM contestants c
            JOIN contests co ON c.contest_id = co.id
            WHERE c.id = ?
        """, (state["contestant_id"],))
        
        post_info = cursor.fetchone()
        conn.close()
        
        if post_info and post_info[0]:
            try:
                message_id = post_info[0]
                channel_id = post_info[1]
                votes = post_info[2]
                contest_id = post_info[3]
                contestant_id = post_info[4]
                
                keyboard = types.InlineKeyboardMarkup(row_width=1)
                
                vote_button = types.InlineKeyboardButton(
                    f"👍 تصويت ({votes})", 
                    callback_data=f"vote_{contest_id}_{contestant_id}",
                    style="success"
                )
                
                bot_username = bot.get_me().username
                contest_link = f"https://t.me/{bot_username}?start=contest_{contest_id}"
                join_button = types.InlineKeyboardButton(
                    "🎯 المشاركة في المسابقة",
                    url=contest_link,
                    style="danger"
                )
                
                keyboard.add(vote_button)
                keyboard.add(join_button)
                
                bot.edit_message_reply_markup(int(channel_id), message_id, reply_markup=keyboard)
            except Exception as e:
                print(f"Error updating message: {e}")
        
        bot.send_message(message.chat.id, f"✅ تم {action_text} {amount} صوت بنجاح!")
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال رقم صحيح.")
    
    del user_states[message.from_user.id]
    show_main_menu(message.chat.id, message.from_user.id, message.from_user.first_name)

# ================= لوحة تحكم الأدمن =================
def admin_panel(call):
    user_id = call.from_user.id
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (user_id,))
    is_admin = cursor.fetchone()
    conn.close()
    
    if not is_admin and str(user_id) != str(ADMIN_ID):
        bot.answer_callback_query(call.id, "❌ ليس لديك صلاحية الوصول!")
        return
    
    text = """👑 <b>لوحة التحكم الإدارية</b>

اختر الإدارة التي تريدها:

👤 <b>إدارة الأعضاء:</b>
• عرض معلومات عضو
• حظر/فك حظر أعضاء
• إحصائيات المستخدمين

👨‍💼 <b>إدارة الأدمن:</b>
• إضافة أدمن جديد
• حذف أدمن
• عرض قائمة الأدمن

📢 <b>إدارة القنوات:</b>
• إضافة قناة اشتراك إجباري
• حذف قناة اشتراك
• عرض قنوات الاشتراك

📊 <b>إحصائيات عامة:</b>
• إحصائيات البوت
• إحصائيات المسابقات"""
    
    keyboard = types.InlineKeyboardMarkup(row_width=2)
    
    # الصف الأول - أزرق + أحمر
    keyboard.row(
        types.InlineKeyboardButton("👤 معلومات عضو", callback_data="admin_user_info", style="primary"),
        types.InlineKeyboardButton("⛔ حظر عضو", callback_data="admin_ban_user", style="danger")
    )
    
    # الصف الثاني - أخضر + أزرق
    keyboard.row(
        types.InlineKeyboardButton("✅ فك حظر عضو", callback_data="admin_unban_user", style="success"),
        types.InlineKeyboardButton("📊 إحصائيات الأعضاء", callback_data="admin_users_stats", style="primary")
    )
    
    # الصف الثالث - أزرق + أحمر
    keyboard.row(
        types.InlineKeyboardButton("👨‍💼 إضافة أدمن", callback_data="admin_add_admin", style="primary"),
        types.InlineKeyboardButton("🗑 حذف أدمن", callback_data="admin_remove_admin", style="danger")
    )
    
    # الصف الرابع - أزرق + أخضر
    keyboard.row(
        types.InlineKeyboardButton("📋 عرض الأدمن", callback_data="admin_list_admins", style="primary"),
        types.InlineKeyboardButton("📢 إضافة قناة اشتراك", callback_data="admin_add_channel", style="success")
    )
    
    # الصف الخامس - أحمر + أزرق
    keyboard.row(
        types.InlineKeyboardButton("🗑 حذف قناة اشتراك", callback_data="admin_remove_channel", style="danger"),
        types.InlineKeyboardButton("📋 عرض القنوات", callback_data="admin_list_channels", style="primary")
    )
    
    # الصف السادس - أزرق
    keyboard.row(
        types.InlineKeyboardButton("📊 إحصائيات البوت", callback_data="admin_bot_stats", style="primary")
    )
    
    # الصف السابع - رجوع أحمر
    keyboard.row(
        types.InlineKeyboardButton("↩️ رجوع", callback_data="main_menu", style="danger")
    )
    
    try:
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    except:
        bot.send_message(call.message.chat.id, text, reply_markup=keyboard)

def handle_admin_commands(call):
    user_id = call.from_user.id
    data = call.data
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (user_id,))
    is_admin = cursor.fetchone()
    conn.close()
    
    if not is_admin and str(user_id) != str(ADMIN_ID):
        bot.answer_callback_query(call.id, "❌ ليس لديك صلاحية الوصول!")
        return
    
    if data == "admin_user_info":
        msg = bot.send_message(call.message.chat.id, "👤 أرسل ID العضو لرؤية معلوماته:")
        bot.register_next_step_handler(msg, process_admin_user_info)
    
    elif data == "admin_ban_user":
        msg = bot.send_message(call.message.chat.id, "⛔ أرسل ID العضو لحظره من البوت:")
        bot.register_next_step_handler(msg, process_admin_ban_user)
    
    elif data == "admin_unban_user":
        msg = bot.send_message(call.message.chat.id, "✅ أرسل ID العضو لفك حظره:")
        bot.register_next_step_handler(msg, process_admin_unban_user)
    
    elif data == "admin_users_stats":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM bans")
        banned_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM admins")
        total_admins = cursor.fetchone()[0]
        conn.close()
        
        text = f"""📊 <b>إحصائيات الأعضاء</b>

👥 <b>إجمالي المستخدمين:</b> {total_users}
⛔ <b>المستخدمين المحظورين:</b> {banned_users}
👨‍💼 <b>عدد الأدمن:</b> {total_admins}
✅ <b>المستخدمين النشطين:</b> {total_users - banned_users}"""
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="admin_panel", style="danger"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    
    elif data == "admin_add_admin":
        msg = bot.send_message(call.message.chat.id, "👨‍💼 أرسل ID العضو لإضافته كأدمن:")
        bot.register_next_step_handler(msg, process_add_admin)
    
    elif data == "admin_remove_admin":
        msg = bot.send_message(call.message.chat.id, "🗑 أرسل ID العضو لإزالته من الأدمن:")
        bot.register_next_step_handler(msg, process_remove_admin)
    
    elif data == "admin_list_admins":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.user_id, u.username, u.first_name, a.added_at 
            FROM admins a
            LEFT JOIN users u ON a.user_id = u.id
        """)
        admins = cursor.fetchall()
        conn.close()
        
        if not admins:
            text = "👨‍💼 <b>لا يوجد أدمن حالياً</b>"
        else:
            text = "👨‍💼 <b>قائمة الأدمن:</b>\n\n"
            for admin in admins:
                admin_id = admin[0]
                username = admin[1]
                first_name = admin[2]
                added_at = admin[3]
                name = f"@{username}" if username else (first_name or f"ID: {admin_id}")
                text += f"• {name} | <code>{admin_id}</code>\n"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(
            types.InlineKeyboardButton("➕ إضافة أدمن", callback_data="admin_add_admin", style="success"),
            types.InlineKeyboardButton("🗑 حذف أدمن", callback_data="admin_remove_admin", style="danger")
        )
        keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="admin_panel", style="primary"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    
    elif data == "admin_add_channel":
        msg = bot.send_message(call.message.chat.id, "📢 أرسل رابط القناة لإضافتها كاشتراك إجباري:")
        bot.register_next_step_handler(msg, process_add_force_channel)
    
    elif data == "admin_remove_channel":
        msg = bot.send_message(call.message.chat.id, "🗑 أرسل رابط القناة لحذفها من الاشتراك الإجباري:")
        bot.register_next_step_handler(msg, process_remove_force_channel)
    
    elif data == "admin_list_channels":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT channel_id, channel_username, added_at FROM force_sub_channels")
        channels = cursor.fetchall()
        conn.close()
        
        if not channels:
            text = "📢 <b>لا توجد قنوات اشتراك إجباري</b>"
        else:
            text = "📢 <b>قنوات الاشتراك الإجباري:</b>\n\n"
            for channel in channels:
                channel_id = channel[0]
                channel_username = channel[1]
                added_at = channel[2]
                text += f"• @{channel_username} | <code>{channel_id}</code>\n"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.row(
            types.InlineKeyboardButton("➕ إضافة قناة", callback_data="admin_add_channel", style="success"),
            types.InlineKeyboardButton("🗑 حذف قناة", callback_data="admin_remove_channel", style="danger")
        )
        keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="admin_panel", style="primary"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)
    
    elif data == "admin_bot_stats":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM contests")
        total_contests = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM contests WHERE deleted = 1")
        deleted_contests = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM contestants")
        total_contestants = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM votes")
        total_votes = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM force_sub_channels")
        total_channels = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM bans")
        total_bans = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM admins")
        total_admins = cursor.fetchone()[0]
        conn.close()
        
        text = f"""📊 <b>إحصائيات البوت الكاملة</b>

👥 <b>المستخدمين:</b> {total_users}
🎯 <b>المسابقات:</b> {total_contests}
🗑️ <b>المسابقات المحذوفة:</b> {deleted_contests}
🏆 <b>المتسابقين:</b> {total_contestants}
👍 <b>التصويتات:</b> {total_votes}
📢 <b>قنوات الاشتراك:</b> {total_channels}
⛔ <b>المحظورين:</b> {total_bans}
👑 <b>الأدمن:</b> {total_admins}

⚡ <b>زعيم المصري🫦🎀</b>
🗑️ <b>خاصية الحذف التلقائي:</b> مفعلة (24 ساعة)"""
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton("↩️ رجوع", callback_data="admin_panel", style="danger"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=keyboard)

# ================= دوال إدارة الأدمن =================
def process_admin_user_info(message):
    try:
        user_id = int(message.text)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT username, first_name, join_date FROM users WHERE id=?", (user_id,))
        user_info = cursor.fetchone()
        
        cursor.execute("SELECT reason, banned_at FROM bans WHERE user_id=?", (user_id,))
        ban_info = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) FROM contests WHERE owner=?", (user_id,))
        contests_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM contestants WHERE user_id=?", (user_id,))
        contestant_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM votes WHERE voter_id=?", (user_id,))
        votes_cast = cursor.fetchone()[0]
        conn.close()
        
        if user_info:
            username = user_info[0]
            first_name = user_info[1]
            join_date = user_info[2]
            text = f"""👤 <b>معلومات العضو</b>

🆔 <b>ID:</b> <code>{user_id}</code>
👤 <b>اليوزر:</b> @{username if username else 'لا يوجد'}
📛 <b>الاسم:</b> {first_name if first_name else 'لا يوجد'}
📅 <b>تاريخ الانضمام:</b> {join_date if join_date else 'غير معروف'}

📊 <b>الإحصائيات:</b>
🎯 <b>عدد المسابقات:</b> {contests_count}
🏆 <b>عدد المشاركات:</b> {contestant_count}
👍 <b>عدد التصويتات:</b> {votes_cast}
"""
            if ban_info:
                reason = ban_info[0]
                banned_at = ban_info[1]
                text += f"\n🚫 <b>الحالة:</b> محظور\n⚖️ <b>السبب:</b> {reason}\n📅 <b>تاريخ الحظر:</b> {banned_at}"
            else:
                text += "\n✅ <b>الحالة:</b> غير محظور"
        else:
            text = f"❌ لم يتم العثور على عضو بهذا ID: {user_id}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton("↩️ رجوع للوحة التحكم", callback_data="admin_panel", style="primary"))
        
        bot.send_message(message.chat.id, text, reply_markup=keyboard)
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط)")

def process_admin_ban_user(message):
    try:
        user_id = int(message.text)
        target_user_id = user_id
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (target_user_id,))
        if cursor.fetchone():
            conn.close()
            bot.send_message(message.chat.id, "❌ لا يمكن حظر أدمن!")
            return
        conn.close()
        
        user_states[message.from_user.id] = {"action": "admin_ban_reason", "target_user": target_user_id}
        bot.send_message(message.chat.id, "📝 أرسل سبب الحظر:")
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط)")

@bot.message_handler(func=lambda m: m.from_user.id in user_states and 
                     user_states[m.from_user.id].get("action") == "admin_ban_reason")
def process_admin_ban_reason(message):
    user_id = message.from_user.id
    state = user_states[user_id]
    target_user = state["target_user"]
    reason = message.text
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO bans (user_id, banned_by, reason) VALUES (?, ?, ?)", 
                  (target_user, user_id, reason))
    conn.commit()
    conn.close()
    
    bot.send_message(message.chat.id, f"✅ تم حظر العضو <code>{target_user}</code> بنجاح.\n📝 السبب: {reason}")
    
    del user_states[user_id]

def process_admin_unban_user(message):
    try:
        user_id = int(message.text)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM bans WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        
        bot.send_message(message.chat.id, f"✅ تم فك حظر العضو <code>{user_id}</code> بنجاح.")
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط)")

def process_add_admin(message):
    try:
        user_id = int(message.text)
        
        try:
            user = bot.get_chat(user_id)
            username = user.username
            first_name = user.first_name
            
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO admins (user_id, username, added_by) VALUES (?, ?, ?)", 
                          (user_id, username, message.from_user.id))
            conn.commit()
            
            cursor.execute("INSERT OR IGNORE INTO users (id, username, first_name) VALUES (?, ?, ?)",
                          (user_id, username, first_name))
            conn.commit()
            conn.close()
            
            bot.send_message(message.chat.id, f"✅ تم إضافة {first_name} (@{username}) كأدمن بنجاح!")
            
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ حدث خطأ: {str(e)}")
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط)")

def process_remove_admin(message):
    try:
        user_id = int(message.text)
        
        if str(user_id) == str(ADMIN_ID):
            bot.send_message(message.chat.id, "❌ لا يمكن حذف المطور الرئيسي من الأدمن!")
            return
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM admins WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        
        bot.send_message(message.chat.id, f"✅ تم حذف العضو <code>{user_id}</code> من قائمة الأدمن.")
        
    except ValueError:
        bot.send_message(message.chat.id, "❌ يرجى إرسال ID صحيح (أرقام فقط)")

def process_add_force_channel(message):
    channel_input = message.text.strip()
    
    try:
        if "t.me/" in channel_input:
            channel_username = "@" + channel_input.split("t.me/")[1].split("/")[0]
        else:
            channel_username = channel_input if channel_input.startswith("@") else "@" + channel_input
        
        chat = bot.get_chat(channel_username)
        
        try:
            bot_member = bot.get_chat_member(chat.id, bot.get_me().id)
            if bot_member.status != "administrator":
                bot.send_message(message.chat.id, "❌ البوت ليس مشرفاً في هذه القناة. يرجى رفعه مشرفاً أولاً.")
                return
        except:
            bot.send_message(message.chat.id, "❌ البوت ليس مشرفاً في هذه القناة أو لا يمكن الوصول إليها.")
            return
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO force_sub_channels (channel_id, channel_username, added_by) VALUES (?, ?, ?)",
                      (str(chat.id), chat.username, message.from_user.id))
        conn.commit()
        conn.close()
        
        bot.send_message(message.chat.id, f"✅ تم إضافة القناة @{chat.username} إلى قنوات الاشتراك الإجباري.\n\n⚠️ ملاحظة: جميع المستخدمين يجب عليهم الاشتراك في هذه القناة لاستخدام البوت!")
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ حدث خطأ: {str(e)}")

def process_remove_force_channel(message):
    channel_input = message.text.strip()
    
    try:
        if "t.me/" in channel_input:
            channel_username = "@" + channel_input.split("t.me/")[1].split("/")[0]
        else:
            channel_username = channel_input if channel_input.startswith("@") else "@" + channel_input
        
        chat = bot.get_chat(channel_username)
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM force_sub_channels WHERE channel_id = ?", (str(chat.id),))
        conn.commit()
        conn.close()
        
        bot.send_message(message.chat.id, f"✅ تم حذف القناة @{chat.username} من قنوات الاشتراك الإجباري.")
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ حدث خطأ: {str(e)}")

# ================= MAIN =================
if __name__ == "__main__":
    print("🚀 البوت يعمل الآن بنظام المسابقات المتكامل...")
    print("✅ تم إنشاء قاعدة البيانات من جديد مع كل الأعمدة المطلوبة")
    print("🔴 تنبيه: لا يمكن لأي مستخدم التصويت أو المشاركة بدون اشتراك في القنوات الإجبارية!")
    print("🔴 تنبيه: لا يمكن لأي مستخدم التصويت في مسابقة بدون اشتراك في قناة المسابقة!")
    print("🔴 تنبيه: جميع رسائل رفض التصويت تصل للمستخدم في البوت فقط - لا يتم إرسال أي شيء للقناة!")
    print("🗑️ تم تفعيل خاصية الحذف التلقائي للمسابقات بعد 24 ساعة")
    print("🎯 المسابقة الرئيسية: زرار واحد '🎯 المشاركة في المسابقة'")
    print("تم التشغيل")
    print("تم التشغيل")
    print("🔄 تم إصلاح مشكلة قاعدة البيانات نهائياً")
    print("✅ تم تفعيل الاشتراك الإجباري الإلزامي للتصويت والمشاركة")
    print("✅ تم إزالة أي رسالة تصل للقناة عند رفض التصويت - الرد يكون في البوت فقط")
    
    try:
        bot.infinity_polling(timeout=60, long_polling_timeout=60)
    except Exception as e:
        print(f"❌ حدث خطأ في البوت: {e}")
        print("🔄 إعادة تشغيل البوت...")
        time.sleep(3)
        bot.infinity_polling(timeout=60, long_polling_timeout=60)